import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  MapPin, 
  ShieldCheck, 
  Lock, 
  Building, 
  Layers, 
  Trophy, 
  AlertCircle, 
  Sparkles, 
  User, 
  UserPlus, 
  KeyRound, 
  CheckCircle,
  Eye,
  EyeOff
} from "lucide-react";
import { Language } from "../types";

interface LoginLandingPageProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  onLoginSuccess: (role: "citizen" | "officer", username: string, name?: string, jurisdiction?: string) => void;
  onCitizenEnter: (name?: string) => void;
  onOfficialLogin: (username: string, pass: string) => boolean;
  redirectReason: string | null;
}

// 12 Tehsils of Chhindwara District
const CHHINDWARA_TEHSILS = [
  { id: "Chhindwara", name_en: "Chhindwara Town", name_hi: "छिंदवाड़ा शहर" },
  { id: "Parasia", name_en: "Parasia", name_hi: "परासिया" },
  { id: "Tamia", name_en: "Tamia", name_hi: "तामिया" },
  { id: "Amarwara", name_en: "Amarwara", name_hi: "अमरवाड़ा" },
  { id: "Jamai (Junnardeo)", name_en: "Junnardeo (Jamai)", name_hi: "जुन्नारदेव" },
  { id: "Chourai", name_en: "Chourai", name_hi: "चौरई" },
  { id: "Sausar", name_en: "Sausar", name_hi: "सौसर" },
  { id: "Mohkhed", name_en: "Mohkhed", name_hi: "मोहखेड़" },
  { id: "Harrai", name_en: "Harrai", name_hi: "हर्रई" },
  { id: "Bichhua", name_en: "Bichhua", name_hi: "बिछुआ" },
  { id: "Umreth", name_en: "Umreth", name_hi: "उमरेठ" },
  { id: "Chand", name_en: "Chand", name_hi: "चांद" }
];

export default function LoginLandingPage({
  language,
  setLanguage,
  onLoginSuccess,
  onCitizenEnter,
  onOfficialLogin,
  redirectReason
}: LoginLandingPageProps) {
  const [activeTab, setActiveTab] = useState<"citizen" | "official">("citizen");
  
  // Citizen modes: 'guest' (traditional optional name) or 'account' (secure credentials)
  const [citizenMode, setCitizenMode] = useState<"guest" | "account">("guest");
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");

  // Input states
  const [citizenName, setCitizenName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [selectedTehsil, setSelectedTehsil] = useState("Parasia");

  // Security toggles
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const resetFormStates = () => {
    setUsername("");
    setPassword("");
    setDisplayName("");
    setErrorMsg("");
    setSuccessMsg("");
  };

  const handleCitizenGuestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCitizenEnter(citizenName.trim() || undefined);
  };

  const handleAccountSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");

    if (!username.trim() || !password) {
      setErrorMsg(
        language === "en" 
          ? "Please provide both a username and a password." 
          : "कृपया यूजरनेम और पासवर्ड दोनों प्रदान करें।"
      );
      return;
    }

    setLoading(true);

    try {
      const endpoint = authMode === "signup" ? "/api/auth/signup" : "/api/auth/signin";
      const payload: any = {
        username: username.trim(),
        password: password,
        role: activeTab === "citizen" ? "citizen" : "officer"
      };

      if (authMode === "signup") {
        payload.name = displayName.trim() || username.trim();
        if (activeTab === "official") {
          payload.jurisdiction = selectedTehsil === "all" 
            ? "Chhindwara District" 
            : `Tehsil: ${selectedTehsil}, District: Chhindwara`;
        }
      }

      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || "Authentication failed");
      }

      setSuccessMsg(
        authMode === "signup"
          ? (language === "en" ? "Registration successful! Loading portal..." : "पंजीकरण सफल! पोर्टल लोड हो रहा है...")
          : (language === "en" ? "Authentication successful! Loading..." : "प्रमाणीकरण सफल! लोड हो रहा है...")
      );

      setTimeout(() => {
        onLoginSuccess(
          result.user.role, 
          result.user.username, 
          result.user.name, 
          result.user.jurisdiction
        );
        setLoading(false);
      }, 1000);

    } catch (err: any) {
      setLoading(false);
      // Fallback for demo official credentials if server returns error and it's the static config
      if (activeTab === "official" && authMode === "signin") {
        const localSuccess = onOfficialLogin(username.trim(), password);
        if (localSuccess) {
          return;
        }
      }
      setErrorMsg(err.message || "An unexpected error occurred.");
    }
  };

  return (
    <div className="min-h-screen w-full bg-slate-50 text-slate-900 flex flex-col justify-between overflow-x-hidden relative select-none">
      {/* Background Graphic Accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-50 rounded-full blur-3xl -z-10 opacity-60"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-amber-50/40 rounded-full blur-3xl -z-10 opacity-50"></div>

      {/* Header */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-slate-200 bg-white/80 backdrop-blur-md z-10 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-700 rounded-lg flex items-center justify-center text-white font-extrabold text-xl shadow-md shadow-indigo-150">
            स
          </div>
          <div>
            <h1 className="text-base font-black text-indigo-950 tracking-tight leading-tight">
              {language === "en" ? "SETUBANDHAM" : "सेतुबंधम"}
            </h1>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              {language === "en" ? "Madhya Pradesh Civic Portal" : "मध्य प्रदेश नागरिक पोर्टल"}
            </p>
          </div>
        </div>

        {/* Language Selection Toggle */}
        <div className="flex bg-slate-100 rounded-full p-1 border border-slate-200">
          <button
            onClick={() => setLanguage("en")}
            className={`px-3 py-1 rounded-full text-[10px] font-extrabold uppercase transition-all duration-200 ${
              language === "en"
                ? "bg-indigo-700 text-white shadow-sm animate-none"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            English
          </button>
          <button
            onClick={() => setLanguage("hi")}
            className={`px-3 py-1 rounded-full text-[10px] font-extrabold transition-all duration-200 ${
              language === "hi"
                ? "bg-indigo-700 text-white shadow-sm animate-none"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            हिन्दी
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-5xl mx-auto px-6 py-8 flex flex-col justify-center items-center z-10 w-full">
        
        {/* Redirect Warning Message if unauthorized */}
        {redirectReason && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold rounded-lg flex items-center gap-2 max-w-md text-center shadow-xs"
          >
            <AlertCircle className="w-4 h-4 text-rose-500 flex-shrink-0" />
            <span>{redirectReason}</span>
          </motion.div>
        )}

        {/* Unified Central Login Card */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-white border border-slate-200 rounded-2xl shadow-xl p-6 sm:p-8 max-w-md w-full relative overflow-visible"
        >
          {/* Subtle color top-accent */}
          <div className={`absolute top-0 left-0 right-0 h-1.5 transition-colors duration-300 rounded-t-2xl ${
            activeTab === "citizen" ? "bg-indigo-600" : "bg-amber-500"
          }`}></div>

          {/* Heading */}
          <div className="text-center mb-6 pt-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-black uppercase tracking-wider mb-3">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              {language === "en" ? "Civic Collaboration" : "नागरिक सहयोग मंच"}
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight leading-tight">
              Welcome to Setubandham
            </h2>
            <h2 className="text-base sm:text-lg font-black text-indigo-900 tracking-tight leading-tight mt-1">
              सेतुबंधम में आपका स्वागत है
            </h2>
          </div>

          {/* Role selection toggle */}
          <div className="grid grid-cols-2 gap-1 bg-slate-100 rounded-xl p-1 border border-slate-200 mb-6">
            <button
              type="button"
              onClick={() => {
                setActiveTab("citizen");
                resetFormStates();
              }}
              className={`py-2 rounded-lg text-[11px] sm:text-xs font-black transition-all duration-300 flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                activeTab === "citizen"
                  ? "bg-indigo-600 text-white shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <span>Citizen Portal</span>
              <span className="text-[9px] opacity-90">नागरिक पोर्टल</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab("official");
                resetFormStates();
                setAuthMode("signin"); // Always start with signin for officials
              }}
              className={`py-2 rounded-lg text-[11px] sm:text-xs font-black transition-all duration-300 flex flex-col items-center justify-center gap-0.5 cursor-pointer ${
                activeTab === "official"
                  ? "bg-amber-500 text-slate-950 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <span>Official Login</span>
              <span className="text-[9px] opacity-90">अधिकारी लॉगिन</span>
            </button>
          </div>

          {/* Sub-modes for Citizens (Guest/Quick vs Registered Account) */}
          {activeTab === "citizen" && (
            <div className="flex gap-2 mb-4 border-b border-slate-100 pb-3">
              <button
                type="button"
                onClick={() => {
                  setCitizenMode("guest");
                  resetFormStates();
                }}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] font-bold text-center border cursor-pointer transition-all ${
                  citizenMode === "guest"
                    ? "bg-indigo-50 border-indigo-200 text-indigo-800 shadow-2xs"
                    : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-700"
                }`}
              >
                {language === "en" ? "Guest Quick Access" : "त्वरित अतिथि प्रवेश"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setCitizenMode("account");
                  resetFormStates();
                }}
                className={`flex-1 py-1.5 px-2 rounded-lg text-[10px] font-bold text-center border cursor-pointer transition-all ${
                  citizenMode === "account"
                    ? "bg-indigo-50 border-indigo-200 text-indigo-800 shadow-2xs"
                    : "bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-700"
                }`}
              >
                {language === "en" ? "Registered Account" : "पंजीकृत खाता"}
              </button>
            </div>
          )}

          {/* Sign In vs Sign Up toggle for accounts */}
          {((activeTab === "citizen" && citizenMode === "account") || activeTab === "official") && (
            <div className="flex bg-slate-50 rounded-lg p-0.5 border border-slate-150 mb-5 max-w-[200px] mx-auto">
              <button
                type="button"
                onClick={() => {
                  setAuthMode("signin");
                  setErrorMsg("");
                  setSuccessMsg("");
                }}
                className={`flex-1 py-1 px-3 text-[10px] font-black rounded-md transition-all cursor-pointer ${
                  authMode === "signin"
                    ? "bg-white text-slate-900 shadow-2xs border border-slate-200"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                {language === "en" ? "Sign In" : "साइन इन"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode("signup");
                  setErrorMsg("");
                  setSuccessMsg("");
                }}
                className={`flex-1 py-1 px-3 text-[10px] font-black rounded-md transition-all cursor-pointer ${
                  authMode === "signup"
                    ? "bg-white text-slate-900 shadow-2xs border border-slate-200"
                    : "text-slate-400 hover:text-slate-600"
                }`}
              >
                {language === "en" ? "Sign Up" : "साइन अप"}
              </button>
            </div>
          )}

          {/* Form Content */}
          <AnimatePresence mode="wait">
            {activeTab === "citizen" && citizenMode === "guest" ? (
              <motion.form
                key="citizen-guest-form"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 10 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleCitizenGuestSubmit}
                className="space-y-4"
              >
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">
                    {language === "en" ? "Enter Your Name (Optional)" : "अपना नाम दर्ज करें (वैकल्पिक)"}
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                    <input
                      type="text"
                      value={citizenName}
                      onChange={(e) => setCitizenName(e.target.value)}
                      placeholder={language === "en" ? "e.g. Rahul Sharma" : "जैसे: राहुल शर्मा"}
                      className="w-full text-xs h-9 pl-9 pr-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:bg-white font-medium"
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 leading-snug">
                    {language === "en"
                      ? "Entering a name logs your reports under your handle and ranks you on the gamified district leaderboard."
                      : "नाम दर्ज करने पर आपकी शिकायतें आपके हैंडल से दर्ज होंगी और आप जिला लीडरबोर्ड में भाग ले सकेंगे।"}
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full h-11 bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-extrabold rounded-lg flex items-center justify-center gap-1.5 shadow-sm hover:shadow-md hover:shadow-indigo-150 transition-all cursor-pointer mt-4"
                >
                  <MapPin className="w-4 h-4 text-white" />
                  <span>
                    {language === "en" ? "Enter Citizen Portal" : "नागरिक पोर्टल में प्रवेश करें"}
                  </span>
                  <span className="text-sm">→</span>
                </button>
              </motion.form>
            ) : (
              <motion.form
                key="account-form"
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -10 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleAccountSubmit}
                className="space-y-4"
              >
                {authMode === "signup" && (
                  <div>
                    <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1">
                      {language === "en" ? "Display Name" : "प्रदर्शन नाम"}
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        required
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder={language === "en" ? "e.g. Rahul Sharma" : "जैसे: राहुल शर्मा"}
                        className="w-full text-xs h-9 pl-9 pr-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:bg-white font-medium"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1">
                    {language === "en" ? "Username" : "यूजरनेम"}
                  </label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder={language === "en" ? "Choose a unique username" : "एक अनूठा यूजरनेम चुनें"}
                    className="w-full text-xs h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:bg-white font-medium"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1">
                    {language === "en" ? "Password" : "पासवर्ड"}
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full text-xs h-9 pl-3 pr-10 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:bg-white font-medium"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {activeTab === "official" && authMode === "signup" && (
                  <div>
                    <label className="block text-[10px] font-extrabold text-slate-400 uppercase tracking-wider mb-1">
                      {language === "en" ? "Official Jurisdiction Unit" : "आधिकारिक क्षेत्राधिकार इकाई"}
                    </label>
                    <select
                      value={selectedTehsil}
                      onChange={(e) => setSelectedTehsil(e.target.value)}
                      className="w-full text-xs h-9 px-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:bg-white font-bold text-slate-700"
                    >
                      <option value="all">{language === "en" ? "Chhindwara District (All)" : "छिंदवाड़ा जिला (सभी)"}</option>
                      {CHHINDWARA_TEHSILS.map(t => (
                        <option key={t.id} value={t.id}>
                          {language === "en" ? t.name_en : t.name_hi}
                        </option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Live testing credentials banner for Sign In only */}
                {activeTab === "official" && authMode === "signin" && (
                  <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[10px] leading-relaxed text-amber-900 font-bold flex items-start gap-2">
                    <Building className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <span className="block font-black text-amber-950">
                        {language === "en" ? "Testing Credentials:" : "परीक्षण क्रेडेंशियल्स:"}
                      </span>
                      <span className="block text-slate-700">
                        {language === "en"
                          ? "Username: officer_parasia • Password: mp_admin"
                          : "यूजरनेम: officer_parasia • पासवर्ड: mp_admin"}
                      </span>
                    </div>
                  </div>
                )}

                {errorMsg && (
                  <div className="text-[10px] text-rose-600 font-extrabold flex items-center gap-1.5 pt-1">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="text-[10px] text-emerald-600 font-extrabold flex items-center gap-1.5 pt-1">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                    <span>{successMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full h-11 text-xs font-extrabold rounded-lg flex items-center justify-center gap-1.5 shadow-sm transition-all cursor-pointer ${
                    activeTab === "citizen" 
                      ? "bg-indigo-700 hover:bg-indigo-800 text-white hover:shadow-md hover:shadow-indigo-150" 
                      : "bg-slate-900 hover:bg-black text-white hover:shadow-md"
                  } disabled:opacity-50`}
                >
                  {authMode === "signup" ? <UserPlus className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  <span>
                    {loading ? (
                      language === "en" ? "Processing..." : "प्रक्रिया चल रही है..."
                    ) : authMode === "signup" ? (
                      activeTab === "citizen" 
                        ? (language === "en" ? "Create Citizen Account & Login" : "नागरिक खाता बनाएं और लॉगिन करें")
                        : (language === "en" ? "Register Official Account" : "अधिकारी खाता पंजीकृत करें")
                    ) : (
                      activeTab === "citizen" 
                        ? (language === "en" ? "Sign In & Enter Portal" : "साइन इन करें और पोर्टल में प्रवेश करें")
                        : (language === "en" ? "Authenticate Official Portal" : "अधिकारी पोर्टल सत्यापित करें")
                    )}
                  </span>
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Feature Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full max-w-3xl mt-12 text-center">
          <div className="p-4 bg-white/40 border border-slate-200/50 rounded-xl">
            <Layers className="w-5 h-5 text-indigo-600 mx-auto mb-2" />
            <h4 className="text-xs font-extrabold text-slate-800">
              {language === "en" ? "Multi-Agent Triage" : "मल्टी-एजेंट ट्राइएज"}
            </h4>
            <p className="text-[10px] text-slate-500 mt-1 leading-normal">
              {language === "en"
                ? "Bilingual routing & deep technical synthesis logs."
                : "द्विभाषी प्रेषण और तकनीकी विश्लेषण प्रणालियाँ।"}
            </p>
          </div>
          <div className="p-4 bg-white/40 border border-slate-200/50 rounded-xl">
            <Trophy className="w-5 h-5 text-amber-500 mx-auto mb-2" />
            <h4 className="text-xs font-extrabold text-slate-800">
              {language === "en" ? "Civic Leaderboard" : "नागरिक लीडरबोर्ड"}
            </h4>
            <p className="text-[10px] text-slate-500 mt-1 leading-normal">
              {language === "en"
                ? "Compete with other ward reps to verify issues."
                : "शिकायत समाधान और सत्यापन में अंक अर्जित करें।"}
            </p>
          </div>
          <div className="p-4 bg-white/40 border border-slate-200/50 rounded-xl">
            <ShieldCheck className="w-5 h-5 text-emerald-600 mx-auto mb-2" />
            <h4 className="text-xs font-extrabold text-slate-800">
              {language === "en" ? "Official Control" : "विभागीय नियंत्रण"}
            </h4>
            <p className="text-[10px] text-slate-500 mt-1 leading-normal">
              {language === "en"
                ? "Full Kanban status pipelines & digital materials dispatch."
                : "पूर्ण कमान बोर्ड एवं सामग्रियों के प्रेषण लॉग।"}
            </p>
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="py-6 border-t border-slate-200 bg-white/45 text-center text-[10px] font-bold text-slate-400">
        <div className="max-w-5xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>
            © {new Date().getFullYear()} {language === "en" ? "Government of Madhya Pradesh • National Informatics Centre (NIC)" : "मध्य प्रदेश सरकार • राष्ट्रीय सूचना विज्ञान केंद्र (NIC)"}
          </p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-indigo-600 transition-colors">
              {language === "en" ? "Terms of Service" : "सेवा की शर्तें"}
            </a>
            <span>•</span>
            <a href="#" className="hover:text-indigo-600 transition-colors">
              {language === "en" ? "Privacy Policy" : "गोपनीयता नीति"}
            </a>
          </div>
        </div>
        <div className="mt-4 pt-4 border-t border-slate-100 max-w-5xl mx-auto px-6 text-center">
          <p className="text-sm text-gray-500 font-medium">
            Built with ❤️ by Yash Dixit
          </p>
        </div>
      </footer>
    </div>
  );
}
