import React, { useState, useMemo } from "react";
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin 
} from "@vis.gl/react-google-maps";
import { 
  MapPin, 
  Search, 
  Plus, 
  Compass, 
  Info, 
  CheckCircle2, 
  AlertTriangle, 
  Clock,
  Sparkles,
  HelpCircle,
  X
} from "lucide-react";
import { Language, Report, Translations } from "../types";

// Create a placeholder string in the code for REACT_APP_GOOGLE_MAPS_API_KEY so the user can paste their real API key in later.
const REACT_APP_GOOGLE_MAPS_API_KEY: string = "AIzaSyC-EBycRTZilfifqbVjLh0HLE9McO7BQs8";

// Check process.env (AI Studio secrets) or local placeholder
const API_KEY =
  process.env.GOOGLE_MAPS_PLATFORM_KEY && process.env.GOOGLE_MAPS_PLATFORM_KEY !== "YOUR_API_KEY"
    ? process.env.GOOGLE_MAPS_PLATFORM_KEY
    : REACT_APP_GOOGLE_MAPS_API_KEY !== "YOUR_REAL_API_KEY_HERE" && REACT_APP_GOOGLE_MAPS_API_KEY !== ""
      ? REACT_APP_GOOGLE_MAPS_API_KEY
      : "";

const hasValidKey = Boolean(API_KEY) && API_KEY.trim() !== "" && API_KEY !== "YOUR_API_KEY" && API_KEY !== "YOUR_REAL_API_KEY_HERE";

interface LiveMapDashboardProps {
  reports: Report[];
  selectedLanguage: Language;
  t: Translations;
  onReportClick: (report: Report) => void;
  onOpenReportForm: (prefilledCoords?: { lat: number; lng: number }, prefilledAddress?: string) => void;
  selectedReportId: string | null;
  onSelectReportId: (id: string | null) => void;
  activeCategoryFilter: string;
  activeSeverityFilter: string;
  currentUser: string;
  onVerifyReport: (reportId: string) => void;
  isDemoMode?: boolean;
  activeTehsilFilter?: string;
  setFormLat?: (lat: number) => void;
  setFormLng?: (lng: number) => void;
  setFormSpecificAddress?: (address: string) => void;
}

export default function LiveMapDashboard({
  reports,
  selectedLanguage,
  t,
  onReportClick,
  onOpenReportForm,
  selectedReportId,
  onSelectReportId,
  activeCategoryFilter,
  activeSeverityFilter,
  currentUser,
  onVerifyReport,
  isDemoMode = false,
  activeTehsilFilter = "all",
  setFormLat,
  setFormLng,
  setFormSpecificAddress,
}: LiveMapDashboardProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [tempPin, setTempPin] = useState<{ lat: number; lng: number } | null>(null);
  const [tempPinAddress, setTempPinAddress] = useState<string>("");
  const [locating, setLocating] = useState<boolean>(false);
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({ lat: 22.0574, lng: 78.9382 });
  const [mapZoom, setMapZoom] = useState<number>(11);
  const [geocodingAuthError, setGeocodingAuthError] = useState<boolean>(false);

  // Helper to reverse geocode Lat/Lng to street address
  const reverseGeocode = (lat: number, lng: number) => {
    if (typeof window === "undefined" || !window.google || !window.google.maps) {
      console.warn("Google Maps JavaScript API not loaded yet.");
      const fallbackAddress = `Chhindwara Area (Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)})`;
      setTempPinAddress(fallbackAddress);
      if (setFormSpecificAddress) {
        setFormSpecificAddress(fallbackAddress);
      }
      return;
    }
    try {
      const geocoder = new window.google.maps.Geocoder();
      geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        if (status === "OK" && results && results[0]) {
          const address = results[0].formatted_address;
          setTempPinAddress(address);
          if (setFormSpecificAddress) {
            setFormSpecificAddress(address);
          }
          setGeocodingAuthError(false);
        } else {
          if (status === "REQUEST_DENIED" || status === "OVER_QUERY_LIMIT") {
            setGeocodingAuthError(true);
          }
          const fallbackAddress = `Chhindwara Area (Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)})`;
          setTempPinAddress(fallbackAddress);
          if (setFormSpecificAddress) {
            setFormSpecificAddress(fallbackAddress);
          }
          console.warn("Geocoder did not return OK status:", status);
        }
      });
    } catch (error) {
      const fallbackAddress = `Chhindwara Area (Lat: ${lat.toFixed(4)}, Lng: ${lng.toFixed(4)})`;
      setTempPinAddress(fallbackAddress);
      if (setFormSpecificAddress) {
        setFormSpecificAddress(fallbackAddress);
      }
      console.warn("Error in reverseGeocode:", error);
    }
  };

  // Geolocation trigger
  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser.");
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setLocating(false);
        setMapCenter({ lat: latitude, lng: longitude });
        setMapZoom(15);
        setTempPin({ lat: latitude, lng: longitude });

        if (setFormLat && setFormLng) {
          setFormLat(latitude);
          setFormLng(longitude);
        }
        reverseGeocode(latitude, longitude);
      },
      (error) => {
        setLocating(false);
        console.warn("Geolocation error:", error);
        
        // Fallback: Drop marker in center of Chhindwara (Madhyapradesh)
        const fallbackLat = 22.0574;
        const fallbackLng = 78.9382;
        setMapCenter({ lat: fallbackLat, lng: fallbackLng });
        setMapZoom(13);
        setTempPin({ lat: fallbackLat, lng: fallbackLng });
        if (setFormLat && setFormLng) {
          setFormLat(fallbackLat);
          setFormLng(fallbackLng);
        }
        reverseGeocode(fallbackLat, fallbackLng);
        alert(selectedLanguage === "en" ? "Unable to retrieve your location. Falling back to Chhindwara Center." : "आपका स्थान खोजने में असमर्थ। छिंदवाड़ा केंद्र पर वापस जा रहे हैं।");
      },
      { enableHighAccuracy: false, timeout: 5000, maximumAge: 60000 }
    );
  };

  // Helper to convert mock coords (0-100) to real Chhindwara, Madhya Pradesh coords
  const convertCoords = (mockLat: number, mockLng: number) => {
    // If coordinates are already in real-world range around Madhya Pradesh
    if (mockLat > 20 && mockLat < 24 && mockLng > 77 && mockLng < 81) {
      return { lat: mockLat, lng: mockLng };
    }
    // Scale mock relative grid coordinates nicely around Chhindwara Town (22.0574, 78.9382)
    const baseLat = 22.0574;
    const baseLng = 78.9382;
    return {
      lat: baseLat + (mockLat - 35) * 0.004,
      lng: baseLng + (mockLng - 35) * 0.004,
    };
  };

  // Convert and filter reports to display
  const reportsWithRealCoords = useMemo(() => {
    return reports.map(r => {
      const real = convertCoords(r.lat, r.lng);
      return {
        ...r,
        realLat: real.lat,
        realLng: real.lng
      };
    });
  }, [reports]);

  const filteredReports = useMemo(() => {
    return reportsWithRealCoords.filter((report) => {
      const matchCat = activeCategoryFilter === "all" || report.category === activeCategoryFilter;
      const matchSev = activeSeverityFilter === "all" || report.severity.toString() === activeSeverityFilter;
      const matchTehsil = activeTehsilFilter === "all" || report.tehsil === activeTehsilFilter;
      const matchSearch =
        searchQuery === "" ||
        report.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        report.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        report.reporter.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSev && matchTehsil && matchSearch;
    });
  }, [reportsWithRealCoords, activeCategoryFilter, activeSeverityFilter, activeTehsilFilter, searchQuery]);

  const selectedReport = useMemo(() => {
    return filteredReports.find((r) => r.id === selectedReportId) || null;
  }, [filteredReports, selectedReportId]);

  // Handle map click to place pin and update form coordinates state
  const handleMapClick = (e: any) => {
    const latLng = e.detail?.latLng || e.latLng;
    if (!latLng) return;

    const clickedLat = typeof latLng.lat === "function" ? latLng.lat() : latLng.lat;
    const clickedLng = typeof latLng.lng === "function" ? latLng.lng() : latLng.lng;

    setTempPin({ lat: clickedLat, lng: clickedLng });

    // Update parent form's coordinates state immediately
    if (setFormLat && setFormLng) {
      setFormLat(clickedLat);
      setFormLng(clickedLng);
    }

    reverseGeocode(clickedLat, clickedLng);
  };

  // Colors for pins based on severity
  const getSeverityColor = (sev: number) => {
    if (sev >= 5) return "bg-rose-600 text-white border-rose-800 ring-rose-400";
    if (sev >= 4) return "bg-orange-500 text-white border-orange-700 ring-orange-300";
    if (sev >= 3) return "bg-amber-500 text-slate-900 border-amber-600 ring-amber-300";
    if (sev >= 2) return "bg-yellow-400 text-slate-900 border-yellow-500 ring-yellow-200";
    return "bg-emerald-500 text-white border-emerald-600 ring-emerald-300";
  };

  const getPinThemeColor = (sev: number, status?: string) => {
    if (status === "resolved") return "#10b981"; // green
    if (sev >= 5) return "#e11d48"; // rose-600
    if (sev >= 4) return "#f97316"; // orange-500
    if (sev >= 3) return "#f59e0b"; // amber-500
    return "#3b82f6"; // blue
  };

  // If no valid API key is present, render the beautiful, custom setup splash screen
  if (!hasValidKey) {
    return (
      <div id="maps-setup-required-screen" className="relative w-full h-[600px] bg-slate-950 rounded-2xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col items-center justify-center p-6 text-center select-none font-sans">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-900/10 rounded-full blur-3xl -z-10"></div>
        
        <div className="max-w-md bg-slate-900/80 border border-slate-800 backdrop-blur-md p-6 sm:p-8 rounded-2xl shadow-2xl space-y-6">
          <div className="mx-auto w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <MapPin className="w-6 h-6 animate-bounce" />
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-black text-white tracking-tight">
              Google Maps API Key Required
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              To display the real-world map, Setubandham needs a valid Google Maps Platform API Key.
            </p>
          </div>

          <div className="text-left space-y-4 bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300">
            <div>
              <p className="font-extrabold text-white text-[11px] uppercase tracking-wider mb-1">
                Option A: Use AI Studio Secrets (Recommended)
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-400 pl-1 text-[11px]">
                <li>Open <strong className="text-indigo-400">Settings</strong> (⚙️ gear icon, top-right)</li>
                <li>Go to <strong className="text-indigo-400">Secrets</strong></li>
                <li>Add <code className="text-amber-400 bg-slate-900 px-1 py-0.5 rounded">GOOGLE_MAPS_PLATFORM_KEY</code></li>
                <li>Paste your key and press Enter. The app will auto-rebuild.</li>
              </ol>
            </div>

            <div className="border-t border-slate-900 pt-3">
              <p className="font-extrabold text-white text-[11px] uppercase tracking-wider mb-1">
                Option B: Paste API Key directly in Code
              </p>
              <p className="text-[11px] text-slate-400 leading-normal">
                Open <code className="text-indigo-400 bg-slate-900 px-1 py-0.5 rounded">src/components/LiveMapDashboard.tsx</code> and replace the value of <code className="text-amber-400 bg-slate-900 px-1 py-0.5 rounded">REACT_APP_GOOGLE_MAPS_API_KEY</code> with your real key.
              </p>
            </div>
          </div>

          <div className="pt-2">
            <a
              href="https://console.cloud.google.com/google/maps-apis/start?utm_campaign=gmp-code-assist-ais"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-indigo-700 hover:bg-indigo-600 text-white font-extrabold text-xs px-5 py-2.5 rounded-lg shadow-lg hover:shadow-indigo-900/30 transition-all cursor-pointer"
            >
              Get a Google Maps API Key
              <span>→</span>
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <APIProvider apiKey={API_KEY} version="weekly">
      <div className="relative w-full h-[600px] bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col md:flex-row font-sans">
        
        {/* Left absolute area for HUD & Search */}
        <div className="absolute top-4 left-4 z-10 w-full max-w-[340px] pointer-events-none flex flex-col gap-3">
          
          {/* Search Bar */}
          <div className="bg-slate-900/95 backdrop-blur-md p-2 rounded-xl shadow-xl border border-slate-700/80 pointer-events-auto flex items-center gap-2">
            <Search className="w-4 h-4 text-slate-400 ml-1 flex-shrink-0" />
            <input
              type="text"
              className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-400 focus:outline-none"
              placeholder={t.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="text-xs text-slate-400 hover:text-slate-200 px-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {geocodingAuthError && (
            <div className="bg-amber-950/95 backdrop-blur-md p-3.5 rounded-xl shadow-xl border border-amber-500/50 pointer-events-auto text-amber-100 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-1.5">
                <div className="flex gap-2">
                  <AlertTriangle className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-bold text-xs text-white">
                      {selectedLanguage === "en" ? "Geocoding API Needs Authorization" : "जियोकोडिंग API को अनुमति चाहिए"}
                    </h4>
                    <p className="text-[11px] text-amber-300 leading-normal mt-0.5">
                      {selectedLanguage === "en" 
                        ? "Your key works for the Map, but Geocoding is restricted. A beautiful coordinate-based address has been auto-filled as fallback!"
                        : "आपकी कुंजी मानचित्र के लिए काम करती है, लेकिन जियोकोडिंग प्रतिबंधित है। वैकल्पिक रूप से निर्देशांक पता स्वचालित रूप से भरा गया है!"}
                    </p>
                  </div>
                </div>
                <button 
                  onClick={() => setGeocodingAuthError(false)}
                  className="text-amber-400 hover:text-amber-200 cursor-pointer p-0.5"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
              <div className="text-[10px] bg-amber-900/40 p-2 rounded border border-amber-800/40 text-slate-200">
                <p className="font-semibold text-white mb-1">
                  {selectedLanguage === "en" ? "How to authorize this key:" : "इस कुंजी को कैसे अधिकृत करें:"}
                </p>
                <ol className="list-decimal list-inside space-y-1 text-slate-300">
                  <li>Go to <a href="https://console.cloud.google.com/google/maps-apis/credentials" target="_blank" rel="noopener noreferrer" className="text-amber-400 underline font-semibold">Google Cloud Credentials</a></li>
                  <li>Click your key & under <strong>API restrictions</strong>, check/enable <strong>Geocoding API</strong></li>
                  <li>Or select <strong>Don't restrict key</strong> and save</li>
                </ol>
              </div>
            </div>
          )}

          {/* Interactive Dropped Pin HUD */}
          {tempPin && (
            <div className="bg-emerald-950/95 backdrop-blur-md p-3.5 rounded-xl shadow-xl border border-emerald-500/50 pointer-events-auto text-emerald-100 flex flex-col gap-2">
              <div className="flex items-start gap-2.5">
                <MapPin className="w-5 h-5 text-emerald-400 animate-bounce mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-bold text-sm text-white">{t.pinnedLocation}</h4>
                  <p className="text-xs text-emerald-300 font-mono">
                    Lat {tempPin.lat.toFixed(5)}, Lng {tempPin.lng.toFixed(5)}
                  </p>
                  {tempPinAddress && (
                    <p className="text-xs text-slate-200 mt-1.5 font-semibold bg-emerald-900/40 p-1.5 rounded border border-emerald-800/50 leading-relaxed">
                      {tempPinAddress}
                    </p>
                  )}
                  <p className="text-[11px] text-emerald-400 mt-1 leading-normal">
                    {selectedLanguage === "en" 
                      ? "Interactive pin saved to the reporting form! Click below to file details for this spot." 
                      : "इंटरएक्टिव पिन रिपोर्टिंग फॉर्म में सहेज ली गई है! इस स्थान के लिए विवरण भरने के लिए नीचे क्लिक करें।"}
                  </p>
                </div>
              </div>
              <div className="flex gap-2 mt-1">
                <button
                  onClick={() => onOpenReportForm({ lat: tempPin.lat, lng: tempPin.lng }, tempPinAddress)}
                  className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black py-1.5 px-3 rounded-lg text-xs transition-colors shadow-lg cursor-pointer text-center"
                >
                  {t.reportIssueButton.split("/")[selectedLanguage === "en" ? 0 : 1].trim()}
                </button>
                <button
                  onClick={() => {
                    setTempPin(null);
                    setTempPinAddress("");
                  }}
                  className="bg-slate-850 hover:bg-slate-750 text-slate-300 font-bold py-1.5 px-2.5 rounded-lg text-xs transition-colors cursor-pointer"
                >
                  {t.btnCancel}
                </button>
              </div>
            </div>
          )}

          {/* Tooltip guidance */}
          {!tempPin && !selectedReport && (
            <div className="bg-slate-900/90 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 pointer-events-auto text-[11px] text-slate-400 flex items-start gap-2 shadow-lg">
              <Info className="w-4 h-4 text-indigo-400 mt-0.5 flex-shrink-0" />
              <p className="leading-snug">
                {selectedLanguage === "en" 
                  ? "Click anywhere on the map to drop a red pin and instantly save coordinates to your new issue report." 
                  : "पिन लगाने और समस्या रिपोर्ट में निर्देशांक सहेजने के लिए मानचित्र पर कहीं भी क्लिक करें।"}
              </p>
            </div>
          )}
        </div>

        {/* Real Google Map Instance */}
        <div className="flex-1 w-full h-full relative">
          <Map
            center={mapCenter}
            zoom={mapZoom}
            onCenterChanged={(e) => {
              if (e.detail.center) {
                setMapCenter(e.detail.center);
              }
            }}
            onZoomChanged={(e) => {
              if (e.detail.zoom !== undefined) {
                setMapZoom(e.detail.zoom);
              }
            }}
            mapId="DEMO_MAP_ID"
            onClick={handleMapClick}
            internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
            style={{ width: "100%", height: "100%" }}
            gestureHandling="greedy"
            disableDefaultUI={false}
          >
            {/* Active Reports Markers */}
            {filteredReports.map((report) => (
              <AdvancedMarker
                key={report.id}
                position={{ lat: report.realLat, lng: report.realLng }}
                onClick={(e) => {
                  onSelectReportId(report.id);
                  onReportClick(report);
                }}
              >
                <Pin 
                  background={getPinThemeColor(report.severity, report.status)} 
                  borderColor="#ffffff" 
                  glyphColor="#ffffff"
                  scale={selectedReportId === report.id ? 1.25 : 1.0}
                />
              </AdvancedMarker>
            ))}

            {/* User Dropped Pin Marker */}
            {tempPin && (
              <AdvancedMarker 
                position={tempPin}
                draggable={true}
                onDragEnd={(e: any) => {
                  const latLng = e.latLng;
                  if (!latLng) return;
                  const dragLat = typeof latLng.lat === "function" ? latLng.lat() : latLng.lat;
                  const dragLng = typeof latLng.lng === "function" ? latLng.lng() : latLng.lng;
                  setTempPin({ lat: dragLat, lng: dragLng });
                  if (setFormLat && setFormLng) {
                    setFormLat(dragLat);
                    setFormLng(dragLng);
                  }
                  reverseGeocode(dragLat, dragLng);
                }}
              >
                <Pin 
                  background="#ef4444" 
                  borderColor="#ffffff" 
                  glyphColor="#ffffff" 
                  scale={1.3}
                />
              </AdvancedMarker>
            )}
          </Map>

          {/* Map Legend (Bottom-Left) */}
          <div className="absolute bottom-4 left-4 z-10 bg-slate-900/95 backdrop-blur-md px-3 py-2.5 rounded-xl border border-slate-800 shadow-xl max-w-[220px] pointer-events-auto text-xs flex flex-col gap-1.5">
            <div className="font-bold text-slate-300 border-b border-slate-850 pb-1 mb-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>{selectedLanguage === "en" ? "Live GIS Legend" : "लाइव जीआईएस संकेत"}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-600 block flex-shrink-0 border border-rose-800"></span>
              <span className="text-[10px] text-slate-300 font-medium">
                {selectedLanguage === "en" ? "Critical / Emergency (4-5★)" : "गंभीर / आपातकालीन (4-5★)"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block flex-shrink-0 border border-amber-700"></span>
              <span className="text-[10px] text-slate-300 font-medium">
                {selectedLanguage === "en" ? "Moderate Warning (3★)" : "मध्यम चेतावनी (3★)"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 block flex-shrink-0 border border-blue-700"></span>
              <span className="text-[10px] text-slate-300 font-medium">
                {selectedLanguage === "en" ? "Minor / Active (1-2★)" : "मामूली / सक्रिय (1-2★)"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 block flex-shrink-0 border border-emerald-700"></span>
              <span className="text-[10px] text-slate-300 font-medium">
                {selectedLanguage === "en" ? "Resolved Issues" : "समाधान हो चुके मामले"}
              </span>
            </div>
          </div>

          {/* Floating Report & Geolocation Buttons (Top-Right) */}
          <div className="absolute top-4 right-4 z-10 pointer-events-auto flex flex-col gap-2">
            <button
              onClick={() => onOpenReportForm()}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-full shadow-2xl border border-slate-900 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4 text-slate-950 stroke-[3]" />
              <span className="text-xs uppercase tracking-wide">
                {t.reportIssueButton.split("/")[selectedLanguage === "en" ? 0 : 1].trim()}
              </span>
            </button>

            {/* Geolocation 'Locate Me / मेरा स्थान खोजें' button */}
            <button
              onClick={handleLocateMe}
              disabled={locating}
              className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-indigo-850 text-white font-black px-4 py-2.5 rounded-full shadow-2xl border border-slate-900 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer self-end"
            >
              <Compass className={`w-4 h-4 text-white ${locating ? "animate-spin" : ""}`} />
              <span className="text-xs uppercase tracking-wide">
                {locating 
                  ? (selectedLanguage === "en" ? "Locating..." : "खोज रहे हैं...") 
                  : "Locate Me / मेरा स्थान खोजें"}
              </span>
            </button>
          </div>
        </div>

        {/* Detailed card overlay for selected report */}
        {selectedReport && (
          <div className="absolute inset-x-4 bottom-4 md:inset-x-auto md:right-4 md:bottom-4 z-20 max-w-full md:w-80 bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-800 shadow-2xl overflow-hidden pointer-events-auto animate-in fade-in slide-in-from-bottom-4 duration-300 flex flex-col">
            <div className="relative h-28 bg-slate-850">
              <img
                src={selectedReport.media}
                alt={selectedReport.category}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <button
                onClick={() => onSelectReportId(null)}
                className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white text-xs font-bold cursor-pointer"
              >
                ×
              </button>
              <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-slate-950/70 backdrop-blur-sm text-[9px] font-black text-slate-300 uppercase tracking-wider">
                {selectedReport.id}
              </div>
              <div className="absolute bottom-2 right-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-black tracking-wider flex items-center gap-1 ${getSeverityColor(selectedReport.severity)}`}>
                  {selectedReport.severity} ★
                </span>
              </div>
            </div>

            <div className="p-4 flex flex-col gap-2">
              <div>
                <span className="text-[10px] font-black uppercase tracking-wider text-amber-500">
                  {t.categories[selectedReport.category as keyof typeof t.categories] || selectedReport.category}
                </span>
                <h3 className="font-extrabold text-sm text-slate-100 mt-0.5 leading-tight line-clamp-1">
                  {selectedReport.location.split("/")[selectedLanguage === "en" ? 0 : 1]?.trim() || selectedReport.location}
                </h3>
              </div>

              <p className="text-xs text-slate-300 leading-normal line-clamp-2">
                {selectedReport.description.split("/")[selectedLanguage === "en" ? 0 : 1]?.trim() || selectedReport.description || "No description."}
              </p>

              <div className="border-t border-slate-800 pt-2 flex flex-col gap-1 text-[11px] text-slate-400">
                <div className="flex justify-between">
                  <span>{t.reporter}:</span>
                  <span className="font-semibold text-slate-200">{selectedReport.reporter}</span>
                </div>
                <div className="flex justify-between items-center mt-1 pt-1 border-t border-slate-855">
                  <span>Status:</span>
                  <span className="flex items-center gap-1 font-bold">
                    {selectedReport.status === "resolved" ? (
                      <span className="text-emerald-400 flex items-center gap-0.5">
                        <CheckCircle2 className="w-3 h-3" /> {t.statusResolved}
                      </span>
                    ) : selectedReport.status === "in_progress" ? (
                      <span className="text-amber-400 flex items-center gap-0.5 animate-pulse">
                        <Clock className="w-3 h-3" /> {t.statusInProgress}
                      </span>
                    ) : selectedReport.status === "awaiting_verification" ? (
                      <span className="text-indigo-400 flex items-center gap-0.5">
                        <AlertTriangle className="w-3 h-3 text-indigo-400" />
                        {selectedLanguage === "en" ? "Awaiting Verification" : "सत्यापन की प्रतीक्षा"}
                      </span>
                    ) : (
                      <span className="text-rose-400 flex items-center gap-0.5">
                        <AlertTriangle className="w-3 h-3" /> {t.statusPending}
                      </span>
                    )}
                  </span>
                </div>
              </div>

              {/* Upvote/Verify Button */}
              {selectedReport.status !== "resolved" && (
                <button
                  type="button"
                  disabled={selectedReport.verificationVotes?.includes(currentUser)}
                  onClick={(e) => {
                    e.stopPropagation();
                    onVerifyReport(selectedReport.id);
                  }}
                  className={`w-full font-bold py-1.5 px-3 rounded-lg text-xs transition-all flex items-center justify-center gap-1.5 mt-1 cursor-pointer ${
                    selectedReport.verificationVotes?.includes(currentUser)
                      ? "bg-emerald-950/60 text-emerald-400 border border-emerald-800/60 cursor-not-allowed"
                      : "bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-500 shadow-md shadow-indigo-900/20"
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                  {selectedReport.verificationVotes?.includes(currentUser)
                    ? (selectedLanguage === "en" ? "✓ Verified by You" : "✓ आपके द्वारा सत्यापित")
                    : (selectedLanguage === "en" ? "Verify / Upvote" : "सत्यापित करें / अपवोट")}
                  {selectedReport.verificationVotes && selectedReport.verificationVotes.length > 0 && (
                    <span className="bg-indigo-950 text-[10px] px-1.5 py-0.5 rounded ml-1 font-mono text-indigo-300">
                      {selectedReport.verificationVotes.length}
                    </span>
                  )}
                </button>
              )}

              <button
                onClick={() => onReportClick(selectedReport)}
                className="w-full bg-slate-800 hover:bg-slate-750 text-slate-200 font-bold py-1.5 rounded-lg text-xs transition-colors border border-slate-750 flex items-center justify-center gap-1 cursor-pointer"
              >
                <Info className="w-3.5 h-3.5 text-amber-500" />
                {selectedLanguage === "en" ? "Inspect Full Issue & Actions" : "पूर्ण समस्या और कार्रवाई जांचें"}
              </button>
            </div>
          </div>
        )}
      </div>
    </APIProvider>
  );
}
