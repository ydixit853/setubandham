import React, { useState, useMemo, useEffect } from "react";
import { MapPin, Search, Plus, Navigation, ZoomIn, ZoomOut, Compass, Info, CheckCircle2, AlertTriangle, Clock } from "lucide-react";
import { Language, Report, Translations } from "../types";

interface InteractiveMapProps {
  reports: Report[];
  selectedLanguage: Language;
  t: Translations;
  onReportClick: (report: Report) => void;
  onOpenReportForm: (prefilledCoords?: { lat: number; lng: number }) => void;
  selectedReportId: string | null;
  onSelectReportId: (id: string | null) => void;
  activeCategoryFilter: string;
  activeSeverityFilter: string;
  currentUser: string;
  onVerifyReport: (reportId: string) => void;
  isDemoMode?: boolean;
  activeTehsilFilter?: string;
}

export default function InteractiveMap({
  reports,
  selectedLanguage,
  t,
  onReportClick,
  onOpenReportForm,
  selectedReportId,
  onSelectReportId,
  activeCategoryFilter,
  activeSeverityFilter,
  currentUser,
  onVerifyReport,
  isDemoMode = false,
  activeTehsilFilter = "all",
}: InteractiveMapProps) {
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [tempPin, setTempPin] = useState<{ lat: number; lng: number } | null>(null);

  // Auto-pan/zoom to Chhindwara on Demo Mode toggle
  useEffect(() => {
    if (isDemoMode) {
      // Zoom and center around the coordinates of Chhindwara mock reports (lat ~40, lng ~40)
      setZoom(1.6);
      setPan({ x: -20, y: -5 });
    } else {
      setZoom(1);
      setPan({ x: 0, y: 0 });
    }
  }, [isDemoMode]);

  // Filtered reports to show on the map
  const filteredReports = useMemo(() => {
    return reports.filter((report) => {
      const matchCat = activeCategoryFilter === "all" || report.category === activeCategoryFilter;
      const matchSev = activeSeverityFilter === "all" || report.severity.toString() === activeSeverityFilter;
      const matchTehsil = activeTehsilFilter === "all" || report.tehsil === activeTehsilFilter;
      const matchSearch =
        searchQuery === "" ||
        report.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        report.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        report.reporter.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSev && matchTehsil && matchSearch;
    });
  }, [reports, activeCategoryFilter, activeSeverityFilter, activeTehsilFilter, searchQuery]);

  // Handle zooming
  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 2.5));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.75));
  const handleResetMap = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
    setTempPin(null);
  };

  // Map mouse/touch actions for panning
  const handleMouseDown = (e: React.MouseEvent<SVGSVGElement>) => {
    const target = e.target as SVGElement;
    if (target.closest(".interactive-pin") || target.closest(".map-controls")) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  // Map clicking to place custom temporary pin
  const handleMapClick = (e: React.MouseEvent<SVGSVGElement>) => {
    const target = e.target as SVGElement;
    // Do not place pin if clicking on buttons or existing pins
    if (
      target.closest(".interactive-pin") ||
      target.closest(".map-controls") ||
      isDragging
    ) {
      return;
    }

    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Convert relative click position into coordinates between 5 and 95
    const lat = Math.round(((clickY / rect.height) * 100));
    const lng = Math.round(((clickX / rect.width) * 100));

    setTempPin({ lat, lng });
  };

  // Get color for category/severity
  const getSeverityColor = (sev: number) => {
    if (sev >= 5) return "bg-rose-600 text-white border-rose-800 ring-rose-400";
    if (sev >= 4) return "bg-orange-500 text-white border-orange-700 ring-orange-300";
    if (sev >= 3) return "bg-amber-500 text-slate-900 border-amber-600 ring-amber-300";
    if (sev >= 2) return "bg-yellow-400 text-slate-900 border-yellow-500 ring-yellow-200";
    return "bg-emerald-500 text-white border-emerald-600 ring-emerald-300";
  };

  const getPinColorSVG = (sev: number, isSelected: boolean, status?: string) => {
    if (status === "resolved" || status === "Resolved / समाधान हो गया") {
      return "#10b981"; // Emerald green for resolved
    }
    if (isSelected) return "#ef4444"; // Highlight selected in bright red
    if (sev >= 5) return "#dc2626"; // rose-600
    if (sev >= 4) return "#f97316"; // orange-500
    if (sev >= 3) return "#f59e0b"; // amber-500
    if (sev >= 2) return "#eab308"; // yellow-500
    return "#10b981"; // emerald-500
  };

  const selectedReport = useMemo(() => {
    return reports.find((r) => r.id === selectedReportId) || null;
  }, [reports, selectedReportId]);

  return (
    <div className="relative w-full h-[600px] bg-slate-950 rounded-2xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col md:flex-row">
      
      {/* Sidebar for Selected Pin / Navigation Assistance */}
      <div className="absolute top-4 left-4 z-10 w-full max-w-[340px] pointer-events-none flex flex-col gap-3">
        {/* Search Bar inside map */}
        <div className="bg-slate-900/95 backdrop-blur-md p-2 rounded-xl shadow-xl border border-slate-700/80 pointer-events-auto flex items-center gap-2">
          <Search className="w-4 h-4 text-slate-400 ml-1 flex-shrink-0" />
          <input
            type="text"
            className="w-full bg-transparent text-sm text-slate-100 placeholder-slate-400 focus:outline-none"
            placeholder={t.searchPlaceholder}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="text-xs text-slate-400 hover:text-slate-200 px-1"
            >
              ×
            </button>
          )}
        </div>

        {/* Current Pin Status Information */}
        {tempPin && (
          <div className="bg-emerald-950/95 backdrop-blur-md p-3.5 rounded-xl shadow-xl border border-emerald-500/50 pointer-events-auto text-emerald-100 flex flex-col gap-2">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-5 h-5 text-emerald-400 animate-bounce mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-bold text-sm text-white">{t.pinnedLocation}</h4>
                <p className="text-xs text-emerald-300">
                  {t.coordinates}: Lat {tempPin.lat}, Lng {tempPin.lng}
                </p>
                <p className="text-[11px] text-emerald-400 mt-1">
                  {selectedLanguage === "en" 
                    ? "Click 'Report Issue' to submit details for this spot." 
                    : "इस स्थान का विवरण सबमिट करने के लिए 'रिपोर्ट समस्या' पर क्लिक करें।"}
                </p>
              </div>
            </div>
            <div className="flex gap-2 mt-1">
              <button
                onClick={() => onOpenReportForm({ lat: tempPin.lat, lng: tempPin.lng })}
                className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-1.5 px-3 rounded-lg text-xs transition-colors shadow-lg"
              >
                {t.reportIssueButton.split("/")[selectedLanguage === "en" ? 0 : 1].trim()}
              </button>
              <button
                onClick={() => setTempPin(null)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 py-1.5 px-2.5 rounded-lg text-xs transition-colors"
              >
                {t.btnCancel}
              </button>
            </div>
          </div>
        )}

        {/* Info Notification Tooltip */}
        {!tempPin && !selectedReport && (
          <div className="bg-slate-900/90 backdrop-blur-md p-2.5 rounded-xl border border-slate-800/80 pointer-events-auto text-[11px] text-slate-400 flex items-start gap-2">
            <Info className="w-3.5 h-3.5 text-blue-400 mt-0.5 flex-shrink-0" />
            <p>{t.clickToPin}</p>
          </div>
        )}
      </div>

      {/* Main Canvas SVG Map view */}
      <div className="relative flex-1 w-full h-full cursor-grab active:cursor-grabbing overflow-hidden">
        <svg
          className="w-full h-full select-none bg-slate-950"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onClick={handleMapClick}
          viewBox="0 0 100 100"
          preserveAspectRatio="none"
        >
          {/* Group for panning and zooming */}
          <g
            transform={`translate(${pan.x / 5}, ${pan.y / 5}) scale(${zoom})`}
            transformOrigin="50 50"
            className="transition-transform duration-200 ease-out"
          >
            {/* WARD GRIDS - 4 quadrants representing municipal divisions */}
            {isDemoMode && (
              <g className="animate-pulse">
                {/* Highlighted special jurisdiction region */}
                <rect x="18" y="22" width="46" height="42" rx="4" fill="#4f46e5" fillOpacity="0.08" stroke="#818cf8" strokeWidth="0.4" strokeDasharray="1.5 1" />
                <rect x="20" y="24" width="42" height="4.5" rx="1" fill="#312e81" fillOpacity="0.85" />
                <text x="41" y="27.2" fill="#c7d2fe" fontSize="2.2" fontWeight="black" textAnchor="middle" letterSpacing="0.1">
                  {selectedLanguage === "en" ? "CHHINDWARA SPECIAL GIS DISTRICT" : "छिंदवाड़ा जीआईएस जिला प्रभाग"}
                </text>
              </g>
            )}

            {/* North Ward (Sector 4) */}
            <rect x="2" y="2" width="46" height="46" rx="2" fill="#1e293b" fillOpacity="0.15" stroke="#334155" strokeWidth="0.2" strokeDasharray="1 1" />
            <text x="5" y="6" fill="#64748b" fontSize="2" fontWeight="bold" opacity="0.8">
              {t.mockWard1}
            </text>

            {/* East Ward */}
            <rect x="52" y="2" width="46" height="46" rx="2" fill="#1e293b" fillOpacity="0.15" stroke="#334155" strokeWidth="0.2" strokeDasharray="1 1" />
            <text x="55" y="6" fill="#64748b" fontSize="2" fontWeight="bold" opacity="0.8">
              {t.mockWard3}
            </text>

            {/* West Ward */}
            <rect x="2" y="52" width="46" height="46" rx="2" fill="#1e293b" fillOpacity="0.15" stroke="#334155" strokeWidth="0.2" strokeDasharray="1 1" />
            <text x="5" y="56" fill="#64748b" fontSize="2" fontWeight="bold" opacity="0.8">
              {t.mockWard4}
            </text>

            {/* South Ward */}
            <rect x="52" y="52" width="46" height="46" rx="2" fill="#1e293b" fillOpacity="0.15" stroke="#334155" strokeWidth="0.2" strokeDasharray="1 1" />
            <text x="55" y="56" fill="#64748b" fontSize="2" fontWeight="bold" opacity="0.8">
              {t.mockWard2}
            </text>

            {/* THEMATIC CIVIC MAP GEOMETRY */}
            {/* Blue River (Flowing through town diagonally from top-left to bottom-right) */}
            <path
              d="M -10,35 Q 25,40 40,50 T 110,65"
              fill="none"
              stroke="#1e3a8a"
              strokeWidth="5"
              opacity="0.4"
            />
            <path
              d="M -10,35 Q 25,40 40,50 T 110,65"
              fill="none"
              stroke="#2563eb"
              strokeWidth="2"
              opacity="0.7"
            />
            {/* River label */}
            <text x="18" y="42" fill="#3b82f6" fontSize="1.5" fontStyle="italic" opacity="0.6" transform="rotate(7 18 42)">
              {selectedLanguage === "en" ? "Ganga Tributary" : "गंगा सहायक नदी"}
            </text>

            {/* MAIN SECTIONS/LANES (Grid Roads) */}
            {/* Horizontal Expressways */}
            <line x1="-10" y1="20" x2="110" y2="20" stroke="#334155" strokeWidth="1.5" opacity="0.5" />
            <line x1="-10" y1="20" x2="110" y2="20" stroke="#475569" strokeWidth="0.6" />

            <line x1="-10" y1="80" x2="110" y2="80" stroke="#334155" strokeWidth="1.5" opacity="0.5" />
            <line x1="-10" y1="80" x2="110" y2="80" stroke="#475569" strokeWidth="0.6" />

            {/* Vertical Expressways */}
            <line x1="25" y1="-10" x2="25" y2="110" stroke="#334155" strokeWidth="1.5" opacity="0.5" />
            <line x1="25" y1="-10" x2="25" y2="110" stroke="#475569" strokeWidth="0.6" />

            <line x1="75" y1="-10" x2="75" y2="110" stroke="#334155" strokeWidth="1.5" opacity="0.5" />
            <line x1="75" y1="-10" x2="75" y2="110" stroke="#475569" strokeWidth="0.6" />

            {/* Diagonal Bypass Ring */}
            <path d="M 5,20 C 15,35 30,35 48,47 L 52,53 C 70,65 85,65 95,80" fill="none" stroke="#475569" strokeWidth="1" strokeDasharray="2 1" opacity="0.6" />

            {/* THE BRIDGES (SETUBANDHAM) - Highlighted Crossing over the blue river */}
            {/* Bridge 1 (Main Sector-4 Bridge) */}
            <g opacity="0.95">
              {/* Bridge outline shadow */}
              <rect x="36" y="45" width="8" height="6" rx="1" fill="#475569" transform="rotate(18 40 48)" />
              {/* Bridge structure lines */}
              <rect x="37" y="46" width="6" height="4" rx="0.5" fill="#f59e0b" stroke="#d97706" strokeWidth="0.3" transform="rotate(18 40 48)" />
              {/* Bridge inner tracks */}
              <line x1="36.5" y1="48" x2="43.5" y2="48" stroke="#1e293b" strokeWidth="0.6" transform="rotate(18 40 48)" />
              <text x="36" y="52" fill="#fbbf24" fontSize="1.2" fontWeight="bold">SETU 1</text>
            </g>

            {/* Secondary Bridge 2 */}
            <g opacity="0.8">
              <rect x="71" y="54" width="8" height="5" rx="1" fill="#475569" transform="rotate(12 75 56.5)" />
              <rect x="72" y="54.5" width="6" height="3.5" rx="0.5" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="0.3" transform="rotate(12 75 56.5)" />
              <line x1="71.5" y1="56" x2="78.5" y2="56" stroke="#1e293b" strokeWidth="0.6" transform="rotate(12 75 56.5)" />
              <text x="73" y="60.5" fill="#cbd5e1" fontSize="1">SETU 2</text>
            </g>

            {/* Local parks/Greens */}
            <rect x="8" y="24" width="12" height="10" rx="2" fill="#065f46" fillOpacity="0.2" stroke="#059669" strokeWidth="0.1" />
            <circle cx="14" cy="29" r="2" fill="#059669" fillOpacity="0.1" />
            <text x="10" y="30" fill="#34d399" fontSize="1.5" opacity="0.5">Park</text>

            <rect x="80" y="60" width="14" height="12" rx="2" fill="#065f46" fillOpacity="0.2" stroke="#059669" strokeWidth="0.1" />
            <text x="82" y="67" fill="#34d399" fontSize="1.5" opacity="0.5">Reserve</text>

            {/* SUBMITTED REPORTS PINS */}
            {filteredReports.map((report) => {
              const isSelected = report.id === selectedReportId;
              const color = getPinColorSVG(report.severity, isSelected, report.status);

              return (
                <g
                  key={report.id}
                  className="interactive-pin cursor-pointer"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectReportId(report.id);
                    onReportClick(report);
                  }}
                >
                  {/* Outer pulsating wave for critical severity items */}
                  {report.severity >= 4 && report.status !== "resolved" && (
                    <circle
                      cx={report.lng}
                      cy={report.lat}
                      r={isSelected ? 4.5 : 3}
                      fill={color}
                      opacity="0.3"
                    >
                      <animate
                        attributeName="r"
                        values={`${isSelected ? 4 : 2.5};${isSelected ? 8 : 6};${isSelected ? 4 : 2.5}`}
                        dur="2s"
                        repeatCount="indefinite"
                      />
                      <animate
                        attributeName="opacity"
                        values="0.4;0.0;0.4"
                        dur="2s"
                        repeatCount="indefinite"
                      />
                    </circle>
                  )}

                  {/* Pin Base Pointer */}
                  <path
                    d={`M ${report.lng} ${report.lat} C ${report.lng - 1.5} ${report.lat - 3} ${report.lng - 2.5} ${report.lat - 5} ${report.lng} ${report.lat - 6} C ${report.lng + 2.5} ${report.lat - 5} ${report.lng + 1.5} ${report.lat - 3} ${report.lng} ${report.lat}`}
                    fill={color}
                    stroke={isSelected ? "#ffffff" : "#1e293b"}
                    strokeWidth={isSelected ? 0.6 : 0.3}
                  />

                  {/* Inner Pin Dot */}
                  <circle
                    cx={report.lng}
                    cy={report.lat - 4.5}
                    r="0.8"
                    fill={report.status === "resolved" ? "#ffffff" : "#0f172a"}
                  />

                  {/* Text indicator for Severity */}
                  <text
                    x={report.lng}
                    y={report.lat - 7}
                    fill="#cbd5e1"
                    fontSize="1.5"
                    fontWeight="bold"
                    textAnchor="middle"
                    className="bg-slate-900 px-1 py-0.5 rounded"
                    opacity={isSelected ? 1 : 0.75}
                  >
                    {report.severity}★
                  </text>
                </g>
              );
            })}

            {/* Custom Interactive Temporary Pin Indicator */}
            {tempPin && (
              <g className="map-controls">
                <circle cx={tempPin.lng} cy={tempPin.lat} r="5" fill="none" stroke="#10b981" strokeWidth="0.4" strokeDasharray="1 1" className="animate-spin" />
                
                {/* Pointer Target */}
                <line x1={tempPin.lng - 4} y1={tempPin.lat} x2={tempPin.lng + 4} y2={tempPin.lat} stroke="#10b981" strokeWidth="0.3" />
                <line x1={tempPin.lng} y1={tempPin.lat - 4} x2={tempPin.lng} y2={tempPin.lat + 4} stroke="#10b981" strokeWidth="0.3" />

                {/* Animated MapPin Pin */}
                <path
                  d={`M ${tempPin.lng} ${tempPin.lat} C ${tempPin.lng - 1.5} ${tempPin.lat - 3.5} ${tempPin.lng - 2} ${tempPin.lat - 6} ${tempPin.lng} ${tempPin.lat - 7.5} C ${tempPin.lng + 2} ${tempPin.lat - 6} ${tempPin.lng + 1.5} ${tempPin.lat - 3.5} ${tempPin.lng} ${tempPin.lat}`}
                  fill="#10b981"
                  stroke="#ffffff"
                  strokeWidth="0.5"
                />
                <circle cx={tempPin.lng} cy={tempPin.lat - 5.5} r="1" fill="#ffffff" />
              </g>
            )}
          </g>
        </svg>

        {/* Dynamic Map Legend Overlay */}
        <div className="absolute bottom-4 left-4 z-10 bg-slate-900/90 backdrop-blur-md px-3 py-2.5 rounded-xl border border-slate-800 shadow-xl max-w-[210px] pointer-events-auto text-xs flex flex-col gap-1.5">
          <div className="font-bold text-slate-300 border-b border-slate-800 pb-1 mb-1">
            {selectedLanguage === "en" ? "Map Legend" : "नक्शा संकेत"}
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600 block flex-shrink-0 border border-rose-800"></span>
            <span className="text-[11px] text-slate-300">{selectedLanguage === "en" ? "Critical / High Danger (4-5★)" : "गंभीर / उच्च खतरा (4-5★)"}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 block flex-shrink-0 border border-amber-700"></span>
            <span className="text-[11px] text-slate-300">{selectedLanguage === "en" ? "Moderate Warning (3★)" : "मध्यम चेतावनी (3★)"}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 block flex-shrink-0 border border-emerald-700"></span>
            <span className="text-[11px] text-slate-300">{selectedLanguage === "en" ? "Minor / Local (1-2★)" : "मामूली / स्थानीय (1-2★)"}</span>
          </div>
          <div className="flex items-center gap-2 border-t border-slate-800 pt-1 mt-1 text-[10px] text-slate-400">
            <div className="font-semibold text-amber-500">{selectedLanguage === "en" ? "Setubandham (Setu)" : "सेतुबंधम (सेतु)"}:</div>
            <div>{selectedLanguage === "en" ? "Active River Bridges" : "सक्रिय नदी पुल"}</div>
          </div>
        </div>

        {/* Floating Utility Controls (Zoom, Reset, Compass) */}
        <div className="absolute bottom-4 right-4 z-10 flex flex-col gap-2 pointer-events-auto map-controls">
          <button
            onClick={handleZoomIn}
            title={selectedLanguage === "en" ? "Zoom In" : "ज़ूम इन"}
            className="w-10 h-10 rounded-xl bg-slate-900/95 hover:bg-slate-800 border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleZoomOut}
            title={selectedLanguage === "en" ? "Zoom Out" : "ज़ूम आउट"}
            className="w-10 h-10 rounded-xl bg-slate-900/95 hover:bg-slate-800 border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={handleResetMap}
            title={selectedLanguage === "en" ? "Reset View" : "नक्शा रीसेट करें"}
            className="w-10 h-10 rounded-xl bg-slate-900/95 hover:bg-slate-800 border border-slate-700 shadow-xl flex items-center justify-center text-slate-200 transition-colors"
          >
            <Compass className="w-4 h-4 text-amber-400 animate-pulse" />
          </button>
        </div>

        {/* Floating "Report Issue / रिपोर्ट समस्या" action button inside map */}
        <div className="absolute top-4 right-4 z-10 pointer-events-auto">
          <button
            id="map-fab-report"
            onClick={() => onOpenReportForm()}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-3 rounded-full shadow-2xl border-2 border-slate-900 hover:scale-105 active:scale-95 transition-all flex items-center gap-2"
          >
            <Plus className="w-5 h-5 text-slate-950 stroke-[3]" />
            <span className="text-sm font-black tracking-wide uppercase">
              {t.reportIssueButton}
            </span>
          </button>
        </div>
      </div>

      {/* Floating Detailed Overlay for Selected Report on Map */}
      {selectedReport && (
        <div className="absolute inset-x-4 bottom-4 md:inset-x-auto md:right-4 md:bottom-20 z-20 max-w-full md:w-80 bg-slate-900/95 backdrop-blur-md rounded-2xl border border-slate-800 shadow-2xl overflow-hidden pointer-events-auto animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="relative h-28 bg-slate-850">
            <img
              src={selectedReport.media}
              alt={selectedReport.category}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <button
              onClick={() => onSelectReportId(null)}
              className="absolute top-2 right-2 w-6 h-6 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white text-xs font-bold"
            >
              ×
            </button>
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-slate-950/70 backdrop-blur-sm text-[10px] font-bold text-slate-300 uppercase">
              {selectedReport.id}
            </div>
            
            {/* Severity Indicator Badge overlay */}
            <div className="absolute bottom-2 right-2">
              <span className={`px-2 py-0.5 rounded text-[10px] font-black tracking-wider flex items-center gap-1 ${getSeverityColor(selectedReport.severity)}`}>
                {selectedReport.severity} ★
              </span>
            </div>
          </div>

          <div className="p-4 flex flex-col gap-2">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-500">
                {t.categories[selectedReport.category as keyof typeof t.categories] || selectedReport.category}
              </span>
              <h3 className="font-bold text-sm text-slate-100 mt-0.5 leading-snug line-clamp-1">
                {selectedReport.location.split("/")[selectedLanguage === "en" ? 0 : 1]?.trim() || selectedReport.location}
              </h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
              {selectedReport.description.split("/")[selectedLanguage === "en" ? 0 : 1]?.trim() || selectedReport.description || "No additional description / कोई अतिरिक्त विवरण नहीं"}
            </p>

            <div className="border-t border-slate-800 pt-2.5 mt-1 flex flex-col gap-1 text-[11px] text-slate-400">
              <div className="flex justify-between">
                <span>{t.reporter}:</span>
                <span className="font-semibold text-slate-200">{selectedReport.reporter}</span>
              </div>
              <div className="flex justify-between">
                <span>{t.reportedOn}:</span>
                <span className="text-slate-300">
                  {new Date(selectedReport.createdAt).toLocaleDateString(selectedLanguage === "en" ? "en-US" : "hi-IN", {
                    month: "short",
                    day: "numeric",
                    year: "numeric"
                  })}
                </span>
              </div>
              <div className="flex justify-between items-center mt-1 pt-1 border-t border-slate-800/50">
                <span>Status:</span>
                <span className="flex items-center gap-1 font-bold">
                  {selectedReport.status === "resolved" ? (
                    <span className="text-emerald-400 flex items-center gap-0.5">
                      <CheckCircle2 className="w-3 h-3" /> {t.statusResolved}
                    </span>
                  ) : selectedReport.status === "in_progress" ? (
                    <span className="text-amber-400 flex items-center gap-0.5 animate-pulse">
                      <Clock className="w-3 h-3" /> {t.statusInProgress}
                    </span>
                  ) : selectedReport.status === "awaiting_verification" ? (
                    <span className="text-indigo-400 flex items-center gap-0.5">
                      <AlertTriangle className="w-3 h-3 animate-pulse text-indigo-400" />
                      {selectedLanguage === "en" ? "Awaiting Verification" : "सत्यापन की प्रतीक्षा"}
                    </span>
                  ) : (
                    <span className="text-rose-400 flex items-center gap-0.5">
                      <AlertTriangle className="w-3 h-3" /> {t.statusPending}
                    </span>
                  )}
                </span>
              </div>
            </div>

            {/* Community Verification / Upvoting CTA */}
            {selectedReport.status !== "resolved" && (
              <button
                type="button"
                disabled={selectedReport.verificationVotes?.includes(currentUser)}
                onClick={(e) => {
                  e.stopPropagation();
                  onVerifyReport(selectedReport.id);
                }}
                className={`w-full font-bold py-1.5 px-3 rounded-lg text-xs transition-all flex items-center justify-center gap-1.5 mt-1 ${
                  selectedReport.verificationVotes?.includes(currentUser)
                    ? "bg-emerald-950/60 text-emerald-400 border border-emerald-800/60 cursor-not-allowed"
                    : "bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-500 shadow-md shadow-indigo-900/20"
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
                {selectedReport.verificationVotes?.includes(currentUser)
                  ? (selectedLanguage === "en" ? "✓ Verified by You" : "✓ आपके द्वारा सत्यापित")
                  : (selectedLanguage === "en" ? "Verify / Upvote" : "सत्यापित करें / अपवोट")}
                {selectedReport.verificationVotes && selectedReport.verificationVotes.length > 0 && (
                  <span className="bg-indigo-950 text-[10px] px-1.5 py-0.5 rounded ml-1 font-mono text-indigo-300">
                    {selectedReport.verificationVotes.length}
                  </span>
                )}
              </button>
            )}

            {/* CTA action to center or view report details */}
            <button
              onClick={() => onReportClick(selectedReport)}
              className="mt-2 w-full bg-slate-800 hover:bg-slate-750 text-slate-200 font-bold py-1.5 rounded-lg text-xs transition-colors border border-slate-700 flex items-center justify-center gap-1"
            >
              <Info className="w-3.5 h-3.5 text-amber-500" />
              {selectedLanguage === "en" ? "Inspect Full Issue & Actions" : "पूर्ण समस्या और कार्रवाई जांचें"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
