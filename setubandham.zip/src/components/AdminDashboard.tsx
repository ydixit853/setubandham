import React, { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  MapPin,
  Building,
  Clock,
  AlertOctagon,
  CheckCircle,
  Activity,
  LogOut,
  Layers,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Copy,
  Check,
  FileText,
  Printer,
  Users,
  Search,
  Filter,
  ArrowUpDown,
  LayoutGrid,
  Table,
  List,
  X,
  Calendar,
  ThumbsUp,
  AlertTriangle,
  Wrench,
  Mail,
  FileImage
} from "lucide-react";
import { Report, Language } from "../types";
import LiveMapDashboard from "./LiveMapDashboard";

const adminTranslations = {
  en: {
    dashboardTitle: "SETUBANDHAM COMMAND CENTRE",
    subTitle: "Madhya Pradesh Municipal Administration • Protected Portal",
    activeJurisdiction: "Active Jurisdiction",
    chhindwaraDistrict: "Chhindwara District",
    exit: "Exit Portal",
    totalGrievances: "Total Grievances",
    loggedPending: "New / Logged",
    awaitingVerification: "Under Verification",
    dispatchedActive: "Work In Progress",
    resolvedClosed: "Resolved & Closed",
    searchPlaceholder: "Search by address, report ID, reporter name, summary...",
    allCategories: "All Categories",
    allTehsils: "All Tehsils",
    allStatuses: "All Statuses",
    noReportsFound: "No official reports found matching the criteria.",
    adjustFilters: "Try adjusting filters or searching another keyword.",
    statusFilterLabel: "Filter by Status",
    categoryFilterLabel: "Filter by Category",
    tehsilFilterLabel: "Filter by Tehsil",
    evidenceMedia: "Evidence Media",
    noPhoto: "No Photo Uploaded",
    communityUpvotes: "Community Upvotes",
    aiTriageLog: "AI MULTI-AGENT TRIAGE LOG",
    category: "Category",
    engineeringPriority: "Engineering Priority",
    requiredMaterials: "Required Materials",
    technicalSummary: "Technical Summary",
    agentExecution: "Multi-Agent System Execution",
    bilingualDraft: "Bilingual Official Complaint Draft",
    copied: "Copied!",
    copy: "Copy Draft",
    print: "Print / Dispatch",
    statusControls: "MUNICIPAL OFFICE STATUS DISPATCH CONTROLS",
    verifyStatus: "Verify Status",
    setLogged: "Set Logged",
    dispatchTeam: "Dispatch Team",
    resolveClosed: "Resolve Closed",
    gisMapTitle: "REAL-TIME GIS HOTSPOT AUDIT MAP",
    gisLiveFeed: "GIS Live Feed",
    officialGuidelines: "Official Command Guidelines",
    guidelineText: "This command board manages active grievances across Chhindwara District. Please audit technical summaries, update ticket statuses, copy or print official dispatch drafts, and deploy municipal taskforces directly.",
    viewMode: "View Layout",
    tableView: "Table View (Sortable)",
    kanbanView: "Kanban Board",
    interactiveFeed: "Interactive Queue",
    colId: "ID",
    colIssueType: "Issue Type",
    colTehsil: "Tehsil",
    colSeverity: "Severity",
    colUpvotes: "Upvotes",
    colStatus: "Status",
    colActions: "Actions",
    viewDetails: "View Details",
    modalTitle: "Grievance Dispatch File #",
    reporterName: "Reporter Name",
    reportedOn: "Reported On",
    address: "Location Address",
    coordinates: "GPS Coordinates",
    changeStatus: "Change Grievance Status",
    closeModal: "Close File",
    unassigned: "Unassigned",
  },
  hi: {
    dashboardTitle: "सेतुबंधम कमान केंद्र",
    subTitle: "मध्य प्रदेश नगर पालिक प्रशासन • अधिकारी पोर्टल",
    activeJurisdiction: "सक्रिय कार्यक्षेत्र",
    chhindwaraDistrict: "छिंदवाड़ा जिला",
    exit: "लॉगआउट",
    totalGrievances: "कुल शिकायतें",
    loggedPending: "नया / लंबित",
    awaitingVerification: "सत्यापन प्रक्रिया",
    dispatchedActive: "प्रगति पर है",
    resolvedClosed: "समाधान संपन्न",
    searchPlaceholder: "पता, रिपोर्ट आईडी, शिकायतकर्ता, या सारांश से खोजें...",
    allCategories: "सभी श्रेणियां",
    allTehsils: "सभी तहसील",
    allStatuses: "सभी स्थितियाँ",
    noReportsFound: "इस मापदंड में कोई शिकायत नहीं मिली।",
    adjustFilters: "फ़िल्टर बदलें या किसी अन्य कीवर्ड से खोजें।",
    statusFilterLabel: "स्थिति से फ़िल्टर करें",
    categoryFilterLabel: "श्रेणी से फ़िल्टर करें",
    tehsilFilterLabel: "तहसील से फ़िल्टर करें",
    evidenceMedia: "साक्ष्य तस्वीर",
    noPhoto: "कोई फोटो नहीं है",
    communityUpvotes: "नागरिक समर्थन",
    aiTriageLog: "एॉई मल्टी-एजेंट कमान लॉग",
    category: "श्रेणी",
    engineeringPriority: "प्राथमिकता ग्रेड",
    requiredMaterials: "निवारण सामग्री",
    technicalSummary: "तकनीकी विवरण सारांश",
    agentExecution: "एजेंट निष्पादन प्रणाली लॉग",
    bilingualDraft: "द्विभाषी शासकीय प्रेषण प्रारूप",
    copied: "कॉपी किया गया!",
    copy: "प्रारूप कॉपी करें",
    print: "प्रिंट / भेजें",
    statusControls: "नगर पालिका नियंत्रण प्रभाग प्रेषण कमांड",
    verifyStatus: "सत्यापन करें",
    setLogged: "लंबित दर्ज करें",
    dispatchTeam: "टीम प्रेषित करें",
    resolveClosed: "समाधान पूर्ण",
    gisMapTitle: "वास्तविक समय जीआईएस हॉटस्पॉट ऑडिट मैप",
    gisLiveFeed: "जीआईएस लाइव फ़ीड",
    officialGuidelines: "आधिकारिक दिशा-निर्देश",
    guidelineText: "यह कमान बोर्ड छिंदवाड़ा जिले में शिकायतों का प्रबंधन करता है। तकनीकी विवरणों का परीक्षण करें, टिकट की स्थिति बदलें, शासकीय प्रेषण पत्रों को प्रिंट करें और काम पूरा करें।",
    viewMode: "दृश्य मोड",
    tableView: "तालिका व्यू (सॉर्टेबल)",
    kanbanView: "कानबन बोर्ड",
    interactiveFeed: "इंटरैक्टिव कतार",
    colId: "आईडी",
    colIssueType: "शिकायत का प्रकार",
    colTehsil: "तहसील",
    colSeverity: "गंभीरता",
    colUpvotes: "नागरिक समर्थन",
    colStatus: "स्थिति",
    colActions: "कार्रवाई",
    viewDetails: "विवरण देखें",
    modalTitle: "शिकायत प्रेषण फ़ाइल #",
    reporterName: "शिकायतकर्ता",
    reportedOn: "रिपोर्ट तिथि",
    address: "घटना का पता",
    coordinates: "जीपीएस निर्देशांक",
    changeStatus: "शिकायत की स्थिति बदलें",
    closeModal: "फ़ाइल बंद करें",
    unassigned: "अनिर्धारित",
  }
};

interface AdminDashboardProps {
  language: Language;
  setLanguage: (lang: Language) => void;
  reports: Report[];
  onUpdateStatus: (id: string, nextStatus: "pending" | "in_progress" | "resolved" | "awaiting_verification", proofOfFix?: string) => void;
  onLogout: () => void;
  t: any;
  onVerifyReport?: (id: string) => void;
  userJurisdiction?: string;
}

export default function AdminDashboard({
  language,
  setLanguage,
  reports,
  onUpdateStatus,
  onLogout,
  t,
  onVerifyReport,
  userJurisdiction
}: AdminDashboardProps) {
  const isParasiaOfficer = userJurisdiction && userJurisdiction.includes("Parasia");

  const [selectedTehsil, setSelectedTehsil] = useState<string>(() => {
    if (userJurisdiction && userJurisdiction.includes("Parasia")) {
      return "Parasia";
    }
    return "all";
  });
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"table" | "kanban" | "feed">("table");
  const [sortField, setSortField] = useState<string>("id");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);
  const [expandedReportId, setExpandedReportId] = useState<string | null>(null);
  const [letterLangTab, setLetterLangTab] = useState<"en" | "hi">("en");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>("");

  const [loadingEstimate, setLoadingEstimate] = useState<boolean>(false);
  const [estimatedResources, setEstimatedResources] = useState<string>("");
  const [loadingDraft, setLoadingDraft] = useState<boolean>(false);
  const [draftReply, setDraftReply] = useState<string>("");
  const [proofOfFixPhoto, setProofOfFixPhoto] = useState<string>("");
  const [uploadingProof, setUploadingProof] = useState<boolean>(false);
  const [modalStatus, setModalStatus] = useState<any>("");

  const d = adminTranslations[language];

  const activeReport = useMemo(() => {
    return reports.find(r => r.id === selectedReportId) || null;
  }, [reports, selectedReportId]);

  useEffect(() => {
    if (!selectedReportId || !activeReport) {
      setEstimatedResources("");
      setDraftReply("");
      setProofOfFixPhoto("");
      setModalStatus("");
      return;
    }

    setEstimatedResources(activeReport.estimatedResources || "");
    setDraftReply(activeReport.draftCitizenUpdate || "");
    setProofOfFixPhoto(activeReport.proofOfFix || "");
    setModalStatus(activeReport.status);

    if (!activeReport.estimatedResources) {
      setLoadingEstimate(true);
      fetch("/api/ai/estimate-resources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          primary_issue_type: activeReport.aiTriage?.primary_issue_type || activeReport.category,
          technical_summary: activeReport.aiTriage?.technical_summary || activeReport.description,
          id: activeReport.id
        })
      })
        .then(res => res.json())
        .then(data => {
          if (data.estimatedResources) {
            setEstimatedResources(data.estimatedResources);
            activeReport.estimatedResources = data.estimatedResources;
          }
        })
        .catch(err => console.warn("Error fetching resource estimate:", err))
        .finally(() => setLoadingEstimate(false));
    }
  }, [selectedReportId, activeReport]);

  const handleGenerateDraft = async () => {
    if (!activeReport) return;
    setLoadingDraft(true);
    try {
      const res = await fetch("/api/ai/draft-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: activeReport.category,
          status: modalStatus || activeReport.status,
          technical_summary: activeReport.aiTriage?.technical_summary || activeReport.description,
          location: activeReport.location,
          estimatedResources: estimatedResources || activeReport.estimatedResources,
          id: activeReport.id
        })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.draftCitizenUpdate) {
          setDraftReply(data.draftCitizenUpdate);
          activeReport.draftCitizenUpdate = data.draftCitizenUpdate;
        }
      }
    } catch (err) {
      console.warn("Error drafting citizen update:", err);
    } finally {
      setLoadingDraft(false);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDropProof = (e: React.DragEvent) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processProofFile(files[0]);
    }
  };

  const handleFileChangeProof = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processProofFile(files[0]);
    }
  };

  const processProofFile = (file: File) => {
    setUploadingProof(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setProofOfFixPhoto(event.target.result as string);
      }
      setUploadingProof(false);
    };
    reader.readAsDataURL(file);
  };

  // 12 Tehsils of Chhindwara District
  const CHHINDWARA_TEHSILS = [
    { id: "Chhindwara", name_en: "Chhindwara Town", name_hi: "छिंदवाड़ा शहर" },
    { id: "Parasia", name_en: "Parasia", name_hi: "परासिया" },
    { id: "Tamia", name_en: "Tamia", name_hi: "तामिया" },
    { id: "Amarwara", name_en: "Amarwara", name_hi: "अमरवाड़ा" },
    { id: "Jamai (Junnardeo)", name_en: "Junnardeo (Jamai)", name_hi: "जुन्नारदेव" },
    { id: "Chourai", name_en: "Chourai", name_hi: "चौरई" },
    { id: "Sausar", name_en: "Sausar", name_hi: "सौसर" },
    { id: "Mohkhed", name_en: "Mohkhed", name_hi: "मोहखेड़" },
    { id: "Harrai", name_en: "Harrai", name_hi: "हर्रई" },
    { id: "Bichhua", name_en: "Bichhua", name_hi: "बिछुआ" },
    { id: "Umreth", name_en: "Umreth", name_hi: "उमरेठ" },
    { id: "Chand", name_en: "Chand", name_hi: "चांद" }
  ];

  const categoriesList = [
    { id: "pothole", name: language === "en" ? "Potholes" : "सड़क गड्ढे" },
    { id: "streetlight", name: language === "en" ? "Streetlights" : "स्ट्रीट लाइट" },
    { id: "garbage", name: language === "en" ? "Sanitation" : "साफ-सफाई" },
    { id: "water_leak", name: language === "en" ? "Water Leaks" : "जल रिसाव" },
    { id: "drainage", name: language === "en" ? "Drainage" : "जल निकासी" }
  ];

  // Officer Filter Hook: Fetches and filters collection for Parasia officer
  const chhindwaraReports = useMemo(() => {
    let result = reports.filter(r => r.district === "Chhindwara" || r.district === "Chhindwara District" || !r.district);
    if (isParasiaOfficer) {
      result = result.filter(r => r.tehsil === "Parasia");
    }
    return result;
  }, [reports, isParasiaOfficer]);

  // Compute metrics for active view of Chhindwara
  const metrics = useMemo(() => {
    const total = chhindwaraReports.length;
    const pending = chhindwaraReports.filter(r => r.status === "pending").length;
    const verifying = chhindwaraReports.filter(r => r.status === "awaiting_verification").length;
    const active = chhindwaraReports.filter(r => r.status === "in_progress").length;
    const resolved = chhindwaraReports.filter(r => r.status === "resolved").length;
    return { total, pending, verifying, active, resolved };
  }, [chhindwaraReports]);

  // Filtered reports list for official table/cards
  const filteredReports = useMemo(() => {
    return chhindwaraReports.filter(r => {
      if (selectedTehsil !== "all" && r.tehsil !== selectedTehsil) return false;
      if (selectedCategory !== "all" && r.category !== selectedCategory) return false;
      if (selectedStatus !== "all" && r.status !== selectedStatus) return false;
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesLocation = r.location.toLowerCase().includes(query);
        const matchesId = r.id.toLowerCase().includes(query);
        const matchesReporter = r.reporter.toLowerCase().includes(query);
        const matchesSummary = r.aiTriage?.technical_summary?.toLowerCase().includes(query);
        return matchesLocation || matchesId || matchesReporter || matchesSummary;
      }
      return true;
    });
  }, [chhindwaraReports, selectedTehsil, selectedCategory, selectedStatus, searchQuery]);

  // Sorted reports for the data table
  const sortedReports = useMemo(() => {
    const sorted = [...filteredReports];
    sorted.sort((a, b) => {
      let valA: any = "";
      let valB: any = "";

      if (sortField === "id") {
        valA = a.id;
        valB = b.id;
      } else if (sortField === "category") {
        valA = a.category;
        valB = b.category;
      } else if (sortField === "tehsil") {
        valA = a.tehsil || "";
        valB = b.tehsil || "";
      } else if (sortField === "severity") {
        valA = a.aiTriage?.severity_score ?? a.severity;
        valB = b.aiTriage?.severity_score ?? b.severity;
      } else if (sortField === "upvotes") {
        valA = a.verificationVotes?.length ?? 0;
        valB = b.verificationVotes?.length ?? 0;
      } else if (sortField === "status") {
        valA = a.status;
        valB = b.status;
      }

      if (valA < valB) return sortDirection === "asc" ? -1 : 1;
      if (valA > valB) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });
    return sorted;
  }, [filteredReports, sortField, sortDirection]);

  // Count active issues per Tehsil to display on the quick filters
  const tehsilCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    chhindwaraReports.forEach(r => {
      if (r.tehsil) {
        counts[r.tehsil] = (counts[r.tehsil] || 0) + 1;
      }
    });
    return counts;
  }, [chhindwaraReports]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handlePrint = (report: Report) => {
    const letterText = letterLangTab === "en" 
      ? report.complaintLetters?.english 
      : report.complaintLetters?.hindi;

    if (!letterText) return;

    const printWindow = window.open("", "_blank");
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Setubandham Dispatch - ${report.id}</title>
            <style>
              body { font-family: 'Inter', sans-serif; padding: 40px; color: #1e293b; line-height: 1.6; }
              .header { border-bottom: 2px solid #4f46e5; padding-bottom: 15px; margin-bottom: 30px; }
              .title { font-size: 24px; font-weight: bold; color: #1e1b4b; }
              .metadata { background: #f8fafc; padding: 15px; border-radius: 8px; margin-bottom: 30px; font-size: 12px; }
              .content { font-size: 14px; white-space: pre-wrap; font-family: monospace; background: #fafafa; padding: 20px; border: 1px solid #e2e8f0; border-radius: 6px; }
              @media print { body { padding: 0; } }
            </style>
          </head>
          <body>
            <div class="header">
              <div class="title">सेतुबंधम / SETUBANDHAM OFFICIAL CIVIC REPORT DISPATCH</div>
              <p>Government of Madhya Pradesh • Municipal Command Center</p>
            </div>
            <div class="metadata">
              <strong>Report ID:</strong> ${report.id} | <strong>Reporter:</strong> ${report.reporter} | <strong>Date:</strong> ${new Date(report.createdAt).toLocaleString()}<br/>
              <strong>Location:</strong> ${report.location}<br/>
              <strong>AI Triage Classification:</strong> ${report.aiTriage?.primary_issue_type || "N/A"} (Severity: ${report.aiTriage?.severity_score || report.severity}/5)
            </div>
            <div class="content">${letterText}</div>
            <script>window.onload = function() { window.print(); }</script>
          </body>
        </html>
      `);
      printWindow.document.close();
    }
  };

  const reportsByColumn = useMemo(() => {
    const groups: Record<string, Report[]> = {
      pending: [],
      awaiting_verification: [],
      in_progress: [],
      resolved: []
    };
    filteredReports.forEach(r => {
      if (groups[r.status]) {
        groups[r.status].push(r);
      } else {
        groups.pending.push(r);
      }
    });
    return groups;
  }, [filteredReports]);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(prev => prev === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const getStatusBadge = (status: string) => {
    const classes = {
      pending: "bg-amber-100 text-amber-800 border-amber-200",
      awaiting_verification: "bg-indigo-100 text-indigo-800 border-indigo-200",
      in_progress: "bg-sky-150 text-sky-800 border-sky-350 animate-pulse",
      resolved: "bg-emerald-100 text-emerald-800 border-emerald-200"
    }[status] || "bg-slate-100 text-slate-800";

    const label = {
      pending: d.loggedPending,
      awaiting_verification: d.awaitingVerification,
      in_progress: d.dispatchedActive,
      resolved: d.resolvedClosed
    }[status] || status;

    return (
      <span className={`px-2 py-0.5 border rounded-full text-[9px] font-black uppercase leading-none tracking-wide ${classes}`}>
        {label}
      </span>
    );
  };

  return (
    <div className="h-screen w-full bg-slate-100 font-sans text-slate-900 flex flex-col overflow-hidden">
      
      {/* 1. OFFICIAL COMPACT HEAD BAR */}
      <nav className="h-16 flex-shrink-0 bg-indigo-950 text-white px-6 flex items-center justify-between z-50 shadow-md">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-amber-500 rounded-lg flex items-center justify-center text-slate-950 font-black text-xl shadow-md shadow-amber-500/20">
            क
          </div>
          <div>
            <h1 className="text-sm md:text-base font-black tracking-tight flex items-center gap-2">
              <span>{language === "en" ? "SETUBANDHAM COMMAND CENTRE" : "सेतुबंधम कमान केंद्र"}</span>
              <span className="bg-rose-600 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full animate-pulse">
                {language === "en" ? "OFFICIAL PORTAL" : "अधिकारी पोर्टल"}
              </span>
            </h1>
            <p className="text-[10px] font-bold text-indigo-300 uppercase tracking-widest leading-none mt-0.5">
              {language === "en" ? "Madhya Pradesh Municipal Administration" : "मध्य प्रदेश नगर पालिक प्रशासन"}
            </p>
          </div>
        </div>

        {/* Action Center in navbar */}
        <div className="flex items-center gap-4">
          
          {/* Active Jurisdiction Block */}
          <div className="hidden md:flex items-center gap-2 bg-indigo-900/60 border border-indigo-800/80 px-3.5 py-1.5 rounded-lg">
            <Building className="w-4 h-4 text-amber-400" />
            <div className="text-left">
              <span className="text-[9px] font-extrabold text-indigo-300 block uppercase tracking-wider leading-none">
                {language === "en" ? "Active Jurisdiction" : "सक्रिय कार्यक्षेत्र"}
              </span>
              <span className="text-xs font-black text-white">
                {userJurisdiction || (language === "en" ? "Chhindwara District" : "छिंदवाड़ा जिला")}
              </span>
            </div>
          </div>

          {/* Bilingual Toggle Button */}
          <div className="flex bg-indigo-900 rounded-lg p-0.5 border border-indigo-800">
            <button
              onClick={() => setLanguage("en")}
              className={`px-3 py-1 rounded text-[10px] font-black uppercase transition-all ${
                language === "en" ? "bg-amber-500 text-slate-950" : "text-indigo-200 hover:text-white"
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage("hi")}
              className={`px-3 py-1 rounded text-[10px] font-black transition-all ${
                language === "hi" ? "bg-amber-500 text-slate-950" : "text-indigo-200 hover:text-white"
              }`}
            >
              हिन्दी
            </button>
          </div>

          {/* Logout Action */}
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 h-9 bg-rose-600 hover:bg-rose-700 text-white px-3 py-1.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer shadow-sm shadow-rose-900/10"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">{language === "en" ? "Exit" : "लॉगआउट"}</span>
          </button>
        </div>
      </nav>

      {/* 2. MAIN LAYOUT CONTAINER */}
      <main className="flex-1 overflow-hidden grid grid-cols-1 xl:grid-cols-12 gap-0 relative">
        
        {/* LEFT COMPONENT: Grievance Task Queue (Official Inbox) (7 Cols) */}
        <section className={`${isParasiaOfficer ? 'xl:col-span-12' : 'xl:col-span-7'} h-full flex flex-col overflow-hidden bg-slate-50 border-r border-slate-200`}>
          
          {/* Metric Overview Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 px-6 py-4 bg-white border-b border-slate-200">
            <div className="bg-indigo-50 border border-indigo-100 p-2.5 rounded-xl text-center shadow-2xs">
              <span className="text-[9px] font-bold text-indigo-400 block uppercase leading-none">{language === "en" ? "Total Grievances" : "कुल शिकायतें"}</span>
              <span className="text-xl font-black text-indigo-950 block mt-1">{metrics.total}</span>
            </div>
            <div className="bg-amber-50 border border-amber-100 p-2.5 rounded-xl text-center shadow-2xs">
              <span className="text-[9px] font-bold text-amber-500 block uppercase leading-none">{language === "en" ? "Logged Pending" : "लंबित समीक्षा"}</span>
              <span className="text-xl font-black text-amber-950 block mt-1">{metrics.pending}</span>
            </div>
            <div className="bg-violet-50 border border-violet-100 p-2.5 rounded-xl text-center shadow-2xs">
              <span className="text-[9px] font-bold text-violet-500 block uppercase leading-none">{language === "en" ? "Awaiting Verification" : "सत्यापन प्रक्रिया"}</span>
              <span className="text-xl font-black text-violet-950 block mt-1">{metrics.verifying}</span>
            </div>
            <div className="bg-sky-50 border border-sky-100 p-2.5 rounded-xl text-center shadow-2xs">
              <span className="text-[9px] font-bold text-sky-500 block uppercase leading-none">{language === "en" ? "Dispatched Active" : "प्रगति पर"}</span>
              <span className="text-xl font-black text-sky-950 block mt-1">{metrics.active}</span>
            </div>
            <div className="bg-emerald-50 border border-emerald-100 p-2.5 rounded-xl text-center col-span-2 sm:col-span-1 shadow-2xs">
              <span className="text-[9px] font-bold text-emerald-500 block uppercase leading-none">{language === "en" ? "Resolved Closed" : "सफलतापूर्वक बंद"}</span>
              <span className="text-xl font-black text-emerald-950 block mt-1">{metrics.resolved}</span>
            </div>
          </div>

          {/* Search, Filter, and Tehsil Hub */}
          <div className="px-6 py-4 bg-white border-b border-slate-200 space-y-3 shadow-2xs">
            {/* View Mode Switcher and Status Filter row */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-1 border-b border-slate-100">
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
                <button
                  onClick={() => setViewMode("table")}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                    viewMode === "table" ? "bg-white text-indigo-950 shadow-2xs border border-slate-200/50" : "text-slate-500 hover:text-slate-900"
                  }`}
                >
                  <Table className="w-3.5 h-3.5" />
                  <span>{d.tableView}</span>
                </button>
                <button
                  onClick={() => setViewMode("kanban")}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                    viewMode === "kanban" ? "bg-white text-indigo-950 shadow-2xs border border-slate-200/50" : "text-slate-500 hover:text-slate-900"
                  }`}
                >
                  <LayoutGrid className="w-3.5 h-3.5" />
                  <span>{d.kanbanView}</span>
                </button>
                <button
                  onClick={() => setViewMode("feed")}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition-all cursor-pointer ${
                    viewMode === "feed" ? "bg-white text-indigo-950 shadow-2xs border border-slate-200/50" : "text-slate-500 hover:text-slate-900"
                  }`}
                >
                  <List className="w-3.5 h-3.5" />
                  <span>{d.interactiveFeed}</span>
                </button>
              </div>

              <div className="text-[10px] text-slate-400 font-bold flex items-center gap-2">
                <span>{language === "en" ? "Showing:" : "दिखा रहा है:"}</span>
                <span className="bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-full font-black text-xs">
                  {filteredReports.length} / {chhindwaraReports.length}
                </span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2">
              
              {/* Search box */}
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={d.searchPlaceholder}
                  className="w-full h-9 pl-9 pr-4 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold focus:outline-none focus:border-indigo-500 focus:bg-white"
                />
              </div>

              {/* Status Filter */}
              <div className="w-full sm:w-44">
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">{d.allStatuses}</option>
                  <option value="pending">{d.loggedPending}</option>
                  <option value="awaiting_verification">{d.awaitingVerification}</option>
                  <option value="in_progress">{d.dispatchedActive}</option>
                  <option value="resolved">{d.resolvedClosed}</option>
                </select>
              </div>

              {/* Category Filter */}
              <div className="w-full sm:w-44">
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full h-9 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold focus:outline-none focus:border-indigo-500"
                >
                  <option value="all">{d.allCategories}</option>
                  {categoriesList.map(cat => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Scrolling Tehsil Quick Dispatch filters */}
            <div className="space-y-1">
              <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">
                {language === "en" ? "Filter by Administrative Tehsil Unit" : "प्रशासनिक तहसील इकाई द्वारा फ़िल्टर करें"}
              </span>
              <div className="flex gap-1.5 overflow-x-auto pb-1 pt-1 scrollbar-thin max-w-full">
                {!isParasiaOfficer && (
                  <button
                    onClick={() => setSelectedTehsil("all")}
                    className={`px-3 py-1.5 text-[10px] font-black rounded-lg border transition-all flex-shrink-0 cursor-pointer ${
                      selectedTehsil === "all"
                        ? "bg-indigo-700 text-white border-indigo-800 shadow-2xs"
                        : "bg-slate-50 text-slate-600 border-slate-250 hover:bg-slate-100"
                    }`}
                  >
                    {language === "en" ? "All Tehsils" : "सभी तहसील"} ({chhindwaraReports.length})
                  </button>
                )}
                {CHHINDWARA_TEHSILS.filter(teh => !isParasiaOfficer || teh.id === "Parasia").map(teh => {
                  const count = tehsilCounts[teh.id] || 0;
                  return (
                    <button
                      key={teh.id}
                      onClick={() => setSelectedTehsil(teh.id)}
                      className={`px-3 py-1.5 text-[10px] font-black rounded-lg border transition-all flex-shrink-0 cursor-pointer flex items-center gap-1 ${
                        selectedTehsil === teh.id
                          ? "bg-indigo-700 text-white border-indigo-800 shadow-2xs"
                          : "bg-slate-50 text-slate-600 border-slate-250 hover:bg-slate-100"
                      }`}
                    >
                      <span>{language === "en" ? teh.name_en : teh.name_hi}</span>
                      <span className={`px-1.5 py-0.2 rounded-full text-[8px] font-extrabold ${
                        selectedTehsil === teh.id ? "bg-indigo-900 text-amber-400" : "bg-slate-200 text-slate-700"
                      }`}>
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Grievance List Container */}
          <div className="flex-1 overflow-y-auto p-6 scrollbar-thin">
            <AnimatePresence mode="wait">
              {filteredReports.length === 0 ? (
                <motion.div
                  key="empty-state"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="p-12 text-center bg-white rounded-2xl border border-slate-200 text-slate-400"
                >
                  <AlertOctagon className="w-12 h-12 mx-auto text-slate-300 mb-3 animate-bounce" />
                  <p className="text-xs font-extrabold">{d.noReportsFound}</p>
                  <p className="text-[10px] mt-1 font-semibold">{d.adjustFilters}</p>
                </motion.div>
              ) : viewMode === "table" ? (
                <motion.div
                  key="table-view"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="overflow-x-auto border border-slate-200 rounded-xl bg-white shadow-2xs"
                >
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-black text-[10px] uppercase tracking-wider select-none">
                        <th className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort("id")}>
                          <div className="flex items-center gap-1">
                            <span>{d.colId}</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort("category")}>
                          <div className="flex items-center gap-1">
                            <span>{d.colIssueType}</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort("tehsil")}>
                          <div className="flex items-center gap-1">
                            <span>{d.colTehsil}</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort("severity")}>
                          <div className="flex items-center gap-1">
                            <span>{d.colSeverity}</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort("upvotes")}>
                          <div className="flex items-center gap-1">
                            <span>{d.colUpvotes}</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3 px-4 cursor-pointer hover:bg-slate-100 transition-colors" onClick={() => handleSort("status")}>
                          <div className="flex items-center gap-1">
                            <span>{d.colStatus}</span>
                            <ArrowUpDown className="w-3 h-3 text-slate-400" />
                          </div>
                        </th>
                        <th className="py-3 px-4 font-black text-[10px] uppercase tracking-wider text-right">
                          {d.colActions}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs font-semibold text-slate-700">
                      {sortedReports.map(report => (
                        <tr
                          key={report.id}
                          onClick={() => setSelectedReportId(report.id)}
                          className={`hover:bg-slate-50/80 transition-colors cursor-pointer ${
                            selectedReportId === report.id ? "bg-indigo-50/50" : ""
                          }`}
                        >
                          <td className="py-3 px-4 font-mono text-[10px] text-indigo-950 font-extrabold">
                            {report.id}
                          </td>
                          <td className="py-3 px-4 font-extrabold text-slate-900">
                            {report.aiTriage?.primary_issue_type || report.category}
                          </td>
                          <td className="py-3 px-4">
                            <span className="bg-slate-100 border border-slate-200 text-slate-600 px-2 py-0.5 rounded text-[9px] uppercase font-black">
                              {CHHINDWARA_TEHSILS.find(t => t.id === report.tehsil)?.name_en || report.tehsil || d.unassigned}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <div className="flex gap-0.5">
                              {Array.from({ length: 5 }, (_, idx) => (
                                <svg
                                  key={idx}
                                  className={`w-3 h-3 ${
                                    idx + 1 <= (report.aiTriage?.severity_score || report.severity)
                                      ? "text-rose-500 fill-rose-500"
                                      : "text-slate-200"
                                  }`}
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              ))}
                            </div>
                          </td>
                          <td className="py-3 px-4 font-black text-slate-600">
                            {report.verificationVotes?.length || 0}
                          </td>
                          <td className="py-3 px-4">
                            {getStatusBadge(report.status)}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedReportId(report.id);
                              }}
                              className="text-indigo-600 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded text-[10px] font-black transition-all cursor-pointer"
                            >
                              {d.viewDetails}
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </motion.div>
              ) : viewMode === "kanban" ? (
                <motion.div
                  key="kanban-view"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="grid grid-cols-1 md:grid-cols-4 gap-4 h-full"
                >
                  {[
                    { id: "pending", title: d.loggedPending, bg: "bg-amber-50/40 border-amber-100 text-amber-800" },
                    { id: "awaiting_verification", title: d.awaitingVerification, bg: "bg-indigo-50/40 border-indigo-100 text-indigo-800" },
                    { id: "in_progress", title: d.dispatchedActive, bg: "bg-sky-50/40 border-sky-100 text-sky-800" },
                    { id: "resolved", title: d.resolvedClosed, bg: "bg-emerald-50/40 border-emerald-100 text-emerald-800" }
                  ].map(column => {
                    const groupReports = reportsByColumn[column.id] || [];
                    return (
                      <div key={column.id} className="flex flex-col bg-slate-100/50 rounded-xl border border-slate-200/60 p-3 h-full min-h-[400px]">
                        <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-200">
                          <span className="text-[10px] font-black uppercase tracking-wider text-slate-600">
                            {column.title}
                          </span>
                          <span className={`px-2 py-0.5 rounded-full text-[9px] font-black ${column.bg}`}>
                            {groupReports.length}
                          </span>
                        </div>

                        <div className="flex-1 space-y-2 overflow-y-auto scrollbar-none">
                          {groupReports.map(report => (
                            <div
                              key={report.id}
                              onClick={() => setSelectedReportId(report.id)}
                              className="bg-white border border-slate-200 rounded-lg p-3 hover:border-indigo-500 hover:shadow-xs transition-all cursor-pointer space-y-2 relative"
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-mono text-[9px] text-slate-400 font-extrabold">{report.id}</span>
                                <span className="text-[9px] font-black bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded">
                                  {CHHINDWARA_TEHSILS.find(t => t.id === report.tehsil)?.name_en || report.tehsil || d.unassigned}
                                </span>
                              </div>

                              <h5 className="text-[11px] font-extrabold text-slate-800 line-clamp-1 leading-tight">
                                {report.aiTriage?.primary_issue_type || report.category}
                              </h5>

                              <p className="text-[10px] text-slate-500 font-medium line-clamp-2">
                                {report.location.split("/")[language === "en" ? 0 : 1]?.trim() || report.location}
                              </p>

                              <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[9px] text-slate-400 font-bold">
                                <span className="flex items-center gap-1">
                                  <ThumbsUp className="w-3 h-3 text-slate-400" />
                                  <span>{report.verificationVotes?.length || 0}</span>
                                </span>
                                <div className="flex gap-0.5">
                                  {Array.from({ length: (report.aiTriage?.severity_score || report.severity) }).map((_, i) => (
                                    <span key={i} className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                                  ))}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </motion.div>
              ) : (
                <motion.div
                  key="feed-view"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-4"
                >
                  {filteredReports.map(report => {
                    const isExpanded = expandedReportId === report.id;
                    const severityStars = Array.from({ length: 5 }, (_, idx) => idx + 1);

                    return (
                      <motion.div
                        layout
                        key={report.id}
                        onClick={() => setSelectedReportId(report.id)}
                        className={`bg-white border rounded-xl overflow-hidden transition-all duration-300 ${
                          selectedReportId === report.id 
                            ? "border-indigo-600 shadow-md ring-1 ring-indigo-500/25" 
                            : "border-slate-200 hover:border-slate-300 shadow-2xs"
                        }`}
                      >
                        {/* Compact Header Bar */}
                        <div className="p-4 flex items-start justify-between gap-3 cursor-pointer select-none">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[10px] font-extrabold text-slate-400">
                                {report.id}
                              </span>
                              {getStatusBadge(report.status)}
                              {report.tehsil && (
                                <span className="text-[9px] font-black bg-slate-100 text-slate-600 border border-slate-200 px-1.5 py-0.5 rounded uppercase tracking-wider">
                                  {CHHINDWARA_TEHSILS.find(t => t.id === report.tehsil)?.name_en || report.tehsil}
                                </span>
                              )}
                            </div>
                            
                            <h4 className="text-xs font-black text-slate-900 leading-snug">
                              {report.location.split("/")[language === "en" ? 0 : 1]?.trim() || report.location}
                            </h4>
                            
                            <p className="text-[10px] font-semibold text-slate-500 flex items-center gap-1.5">
                              <Users className="w-3 h-3 text-slate-400" />
                              <span>{language === "en" ? "Reporter" : "शिकायतकर्ता"}: {report.reporter}</span>
                              <span className="text-slate-300">•</span>
                              <span>{new Date(report.createdAt).toLocaleDateString()}</span>
                            </p>
                          </div>

                          {/* Expand & Star Trigger Column */}
                          <div className="flex flex-col items-end gap-2">
                            <div className="flex gap-0.5">
                              {severityStars.map(star => (
                                <svg
                                  key={star}
                                  className={`w-3.5 h-3.5 ${
                                    star <= (report.aiTriage?.severity_score || report.severity)
                                      ? "text-rose-500 fill-rose-500"
                                      : "text-slate-200"
                                  }`}
                                  fill="currentColor"
                                  viewBox="0 0 20 20"
                                >
                                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                                </svg>
                              ))}
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setExpandedReportId(isExpanded ? null : report.id);
                              }}
                              className="p-1 hover:bg-slate-100 rounded text-slate-500 transition-colors"
                            >
                              {isExpanded ? (
                                <ChevronDown className="w-5 h-5 text-indigo-600" />
                              ) : (
                                <ChevronRight className="w-5 h-5" />
                              )}
                            </button>
                          </div>
                        </div>

                        {/* Detail Accordion Panel */}
                        <AnimatePresence initial={false}>
                          {isExpanded && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.25 }}
                              className="border-t border-slate-150 bg-slate-50/70 p-4 space-y-4 text-xs select-text"
                            >
                              
                              {/* Visual Grid for analysis */}
                              <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                                
                                {/* Left column: Evidence Photo (4 Cols) */}
                                <div className="md:col-span-4 space-y-2">
                                  <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">
                                    {language === "en" ? "Evidence Media" : "साक्ष्य तस्वीर"}
                                  </span>
                                  {report.media ? (
                                    <img
                                      src={report.media}
                                      alt="civic defect report"
                                      className="w-full h-32 object-cover rounded-lg border border-slate-200 shadow-2xs"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <div className="w-full h-32 bg-slate-200 rounded-lg flex items-center justify-center text-slate-400">
                                      {language === "en" ? "No Photo Uploaded" : "कोई फोटो नहीं है"}
                                    </div>
                                  )}
                                  <div className="p-2 bg-white rounded border border-slate-200 flex items-center justify-between text-[10px] text-slate-600 font-bold">
                                    <span>{language === "en" ? "Community Upvotes" : "नागरिक समर्थन"}</span>
                                    <span className="bg-indigo-50 px-1.5 py-0.5 rounded text-indigo-700 font-extrabold shadow-3xs">
                                      {report.verificationVotes?.length || 0}
                                    </span>
                                  </div>
                                </div>

                                {/* Middle Column: Multi-Agent Triage (8 Cols) */}
                                <div className="md:col-span-8 space-y-3">
                                  
                                  {/* Triage Stats Block */}
                                  <div className="bg-slate-900 text-slate-200 rounded-xl p-4 border border-slate-800 space-y-2.5 shadow-sm relative overflow-hidden">
                                    <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl"></div>
                                    <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1.5">
                                      <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                                      <span className="text-[9px] font-black uppercase tracking-widest text-indigo-300">
                                        {language === "en" ? "AI MULTI-AGENT TRIAGE LOG" : "एआई मल्टी-एजेंट कमान लॉग"}
                                      </span>
                                    </div>

                                    <div className="grid grid-cols-2 gap-3 text-[11px] leading-tight text-slate-300 font-bold">
                                      <div>
                                        <span className="text-[9px] text-indigo-400 block uppercase font-extrabold tracking-wider">{language === "en" ? "Category" : "वर्गीकरण"}</span>
                                        <span className="text-white block mt-0.5">{report.aiTriage?.primary_issue_type || report.category}</span>
                                      </div>
                                      <div>
                                        <span className="text-[9px] text-indigo-400 block uppercase font-extrabold tracking-wider">{language === "en" ? "Engineering Priority" : "प्राथमिकता ग्रेड"}</span>
                                        <span className="text-amber-400 block mt-0.5">{report.aiTriage?.severity_score || report.severity} / 5</span>
                                      </div>
                                    </div>

                                    <div>
                                      <span className="text-[9px] text-indigo-400 block uppercase font-extrabold tracking-wider">{language === "en" ? "Required Dispatch Materials" : "आवश्यक निवारण सामग्री"}</span>
                                      <span className="text-slate-100 block mt-0.5 font-extrabold">{report.aiTriage?.required_materials || "Municipal dispatch crew & barricades"}</span>
                                    </div>

                                    <div className="bg-slate-950/70 p-2.5 rounded border border-slate-850 text-[11px] text-slate-300 leading-relaxed font-semibold shadow-inner">
                                      <span className="text-[9px] text-indigo-400 block uppercase font-extrabold tracking-wider mb-0.5">{language === "en" ? "Technical Summary" : "तकनीकी विवरण सारांश"}</span>
                                      {report.aiTriage?.technical_summary || report.description}
                                    </div>

                                    {/* Agent logs */}
                                    {report.agentWorkflowLogs && report.agentWorkflowLogs.length > 0 && (
                                      <div className="space-y-1 pt-1.5 border-t border-slate-800">
                                        <span className="text-[9px] text-indigo-400 block uppercase font-extrabold tracking-wider">
                                          {language === "en" ? "Multi-Agent System Execution" : "एजेंट निष्पादन प्रणाली लॉग"}
                                        </span>
                                        <div className="bg-slate-950 p-2 rounded border border-slate-900 max-h-24 overflow-y-auto font-mono text-[9px] text-emerald-400 space-y-1 scrollbar-thin select-all leading-normal">
                                          {report.agentWorkflowLogs.map((log, lidx) => (
                                            <div key={lidx} className="flex gap-1">
                                              <span className="text-indigo-400 font-black flex-shrink-0">{`>`}</span>
                                              <span>{log}</span>
                                            </div>
                                          ))}
                                        </div>
                                      </div>
                                    )}
                                  </div>

                                </div>
                              </div>

                              {/* Section: Bilingual complaint letters */}
                              {report.complaintLetters && (
                                <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-2xs">
                                  <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                                    <div className="flex items-center gap-2">
                                      <FileText className="w-4 h-4 text-indigo-600" />
                                      <span className="text-[10px] font-black text-slate-700 uppercase tracking-wider">
                                        {language === "en" ? "Bilingual Official Complaint Draft" : "द्विभाषी शासकीय प्रेषण प्रारूप"}
                                      </span>
                                    </div>
                                    
                                    {/* Copy, Language and Print controls */}
                                    <div className="flex items-center gap-2">
                                      <div className="flex bg-slate-150 p-0.5 rounded-lg border border-slate-200">
                                        <button
                                          type="button"
                                          onClick={() => setLetterLangTab("en")}
                                          className={`px-2 py-0.5 rounded text-[8px] font-black uppercase transition-all ${
                                            letterLangTab === "en"
                                              ? "bg-indigo-600 text-white shadow-xs"
                                              : "text-slate-500 hover:text-slate-800"
                                          }`}
                                        >
                                          EN
                                        </button>
                                        <button
                                          type="button"
                                          onClick={() => setLetterLangTab("hi")}
                                          className={`px-2 py-0.5 rounded text-[8px] font-black transition-all ${
                                            letterLangTab === "hi"
                                              ? "bg-indigo-600 text-white shadow-xs"
                                              : "text-slate-500 hover:text-slate-800"
                                          }`}
                                        >
                                          HI
                                        </button>
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => handleCopy(
                                          letterLangTab === "en" ? report.complaintLetters!.english : report.complaintLetters!.hindi,
                                          report.id
                                        )}
                                        className="p-1.5 hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-500 hover:text-slate-850 flex items-center gap-1 text-[9px] font-extrabold transition-all cursor-pointer"
                                        title="Copy official draft letter"
                                      >
                                        {copiedId === report.id ? (
                                          <>
                                            <Check className="w-3 h-3 text-emerald-600" />
                                            <span className="text-emerald-600">{language === "en" ? "Copied" : "कॉपी किया"}</span>
                                          </>
                                        ) : (
                                          <>
                                            <Copy className="w-3 h-3" />
                                            <span>{language === "en" ? "Copy" : "कॉपी"}</span>
                                          </>
                                        )}
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => handlePrint(report)}
                                        className="p-1.5 hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-500 hover:text-slate-850 flex items-center gap-1 text-[9px] font-extrabold transition-all cursor-pointer"
                                        title="Print/Download Dispatch document"
                                      >
                                        <Printer className="w-3 h-3" />
                                        <span>{language === "en" ? "Print" : "प्रिंट"}</span>
                                      </button>
                                    </div>
                                  </div>

                                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-150 font-mono text-[10px] text-slate-800 leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto scrollbar-thin select-all">
                                    {letterLangTab === "en" 
                                      ? report.complaintLetters.english 
                                      : report.complaintLetters.hindi}
                                  </div>
                                </div>
                              )}

                              {/* Dispatch and Command Action Center */}
                              <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-4 space-y-3 shadow-3xs">
                                <span className="block text-[10px] font-black text-indigo-900 uppercase tracking-widest leading-none">
                                  {language === "en" ? "MUNICIPAL OFFICE STATUS DISPATCH CONTROLS" : "नगर पालिका नियंत्रण प्रभाग प्रेषण कमांड"}
                                </span>
                                
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                  <button
                                    onClick={() => onUpdateStatus(report.id, "awaiting_verification")}
                                    disabled={report.status === "awaiting_verification"}
                                    className="bg-white hover:bg-slate-50 text-indigo-700 border border-indigo-200 disabled:opacity-40 text-[10px] font-extrabold py-2 px-3 rounded-lg transition-all shadow-3xs cursor-pointer flex items-center justify-center gap-1"
                                  >
                                    <Clock className="w-3.5 h-3.5" />
                                    <span>{language === "en" ? "Verify Status" : "सत्यापन करें"}</span>
                                  </button>
                                  
                                  <button
                                    onClick={() => onUpdateStatus(report.id, "pending")}
                                    disabled={report.status === "pending"}
                                    className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-250 disabled:opacity-40 text-[10px] font-extrabold py-2 px-3 rounded-lg transition-all shadow-3xs cursor-pointer flex items-center justify-center gap-1"
                                  >
                                    <AlertOctagon className="w-3.5 h-3.5" />
                                    <span>{language === "en" ? "Set Logged" : "लंबित दर्ज"}</span>
                                  </button>

                                  <button
                                    onClick={() => onUpdateStatus(report.id, "in_progress")}
                                    disabled={report.status === "in_progress"}
                                    className="bg-sky-600 hover:bg-sky-700 text-white disabled:opacity-40 text-[10px] font-extrabold py-2 px-3 rounded-lg transition-all shadow-3xs cursor-pointer flex items-center justify-center gap-1"
                                  >
                                    <Activity className="w-3.5 h-3.5 animate-pulse" />
                                    <span>{language === "en" ? "Dispatch Team" : "टीम प्रेषित"}</span>
                                  </button>

                                  <button
                                    onClick={() => onUpdateStatus(report.id, "resolved")}
                                    disabled={report.status === "resolved"}
                                    className="bg-emerald-600 hover:bg-emerald-700 text-white disabled:opacity-40 text-[10px] font-extrabold py-2 px-3 rounded-lg transition-all shadow-3xs cursor-pointer flex items-center justify-center gap-1"
                                  >
                                    <CheckCircle className="w-3.5 h-3.5" />
                                    <span>{language === "en" ? "Resolve Closed" : "समाधान पूर्ण"}</span>
                                  </button>
                                </div>
                              </div>

                            </motion.div>
                          )}
                        </AnimatePresence>

                      </motion.div>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </section>

        {/* RIGHT COMPONENT: Spatial GIS Map Preview & Statistics (5 Cols) */}
        {!isParasiaOfficer && (
          <section className="xl:col-span-5 h-full flex flex-col overflow-hidden bg-slate-100 border-l border-slate-200">
            
            <div className="h-10 bg-white border-b border-slate-200 px-6 flex items-center justify-between flex-shrink-0 shadow-2xs">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-600" />
                <span>{language === "en" ? "REAL-TIME GIS HOTSPOT AUDIT MAP" : "वास्तविक समय जीआईएस हॉटस्पॉट ऑडिट मैप"}</span>
              </span>
              <span className="text-[9px] font-black text-emerald-600 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                {language === "en" ? "GIS Live Feed" : "जीआईएस लाइव फ़ीड"}
              </span>
            </div>

            {/* Map Viewer */}
            <div className="flex-1 relative bg-slate-200 border-b border-slate-200 overflow-hidden">
              <LiveMapDashboard
                reports={chhindwaraReports}
                selectedLanguage={language}
                t={t}
                onReportClick={(rep) => {
                  setSelectedReportId(rep.id);
                  setExpandedReportId(rep.id);
                }}
                selectedReportId={selectedReportId}
                onSelectReportId={setSelectedReportId}
                onOpenReportForm={() => {}}
                activeCategoryFilter="all"
                activeSeverityFilter="all"
                currentUser="Officer Chhindwara"
                onVerifyReport={onVerifyReport || (() => {})}
                isDemoMode={true}
                activeTehsilFilter={selectedTehsil}
              />
            </div>

            {/* Quick Informational / Help panel at the bottom */}
            <div className="p-4 bg-white border-t border-slate-200 space-y-2 flex-shrink-0">
              <span className="block text-[10px] font-black text-slate-400 uppercase tracking-wider">
                {language === "en" ? "Official Guidelines" : "आधिकारिक दिशा-निर्देश"}
              </span>
              <p className="text-[10px] leading-relaxed text-slate-500 font-medium">
                {language === "en"
                  ? "This command board manages active grievances across the 12 tehsils of Chhindwara District. The system automatically performs multi-agent triage based on submitted photos. Please audit the technical summaries, copy or print the generated official dispatch drafts, and deploy municipal taskforces directly."
                  : "यह कमान बोर्ड छिंदवाड़ा जिले की 12 तहसीलों में सक्रिय शिकायतों का प्रबंधन करता है। सिस्टम सबमिट की गई तस्वीरों के आधार पर मल्टी-एजेंट ट्राइएज संचालित करता है। तकनीकी विवरणों का परीक्षण करें, शासकीय प्रेषण पत्रों को प्रिंट करें और काम पूरा करें।"}
              </p>
            </div>

          </section>
        )}

      </main>

      {/* 4. HIGH-FIDELITY OFFICIAL DETAIL ACTION MODAL */}
      <AnimatePresence>
        {activeReport && viewMode !== "feed" && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl border border-slate-200 w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col"
            >
              {/* Modal Header */}
              <div className="bg-slate-50 border-b border-slate-200 p-4 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] font-extrabold text-slate-400">{activeReport.id}</span>
                    {getStatusBadge(activeReport.status)}
                  </div>
                  <h3 className="text-xs font-black text-slate-900 mt-1">
                    {activeReport.aiTriage?.primary_issue_type || activeReport.category}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedReportId(null)}
                  className="p-1.5 hover:bg-slate-200 rounded-full transition-all cursor-pointer text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="flex-1 overflow-y-auto p-5 space-y-4 scrollbar-thin text-xs">
                {/* Location & Reporter info */}
                <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3 rounded-lg border border-slate-150">
                  <div>
                    <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">{language === "en" ? "Location / Ward" : "स्थान / वार्ड"}</span>
                    <span className="font-extrabold text-slate-850 block mt-0.5">
                      {activeReport.location.split("/")[language === "en" ? 0 : 1]?.trim() || activeReport.location}
                    </span>
                  </div>
                  <div>
                    <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">{language === "en" ? "Administrative Tehsil" : "प्रशासनिक तहसील"}</span>
                    <span className="font-black text-indigo-700 block mt-0.5">
                      {CHHINDWARA_TEHSILS.find(t => t.id === activeReport.tehsil)?.name_en || activeReport.tehsil || d.unassigned}
                    </span>
                  </div>
                </div>

                {/* Media & Summary Grid */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                  {/* Photo Column */}
                  <div className="md:col-span-4 space-y-2">
                    <span className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">{language === "en" ? "Evidence Media" : "साक्ष्य तस्वीर"}</span>
                    {activeReport.media ? (
                      <img
                        src={activeReport.media}
                        alt="civic defect report"
                        className="w-full h-32 object-cover rounded-lg border border-slate-200 shadow-2xs"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-32 bg-slate-200 rounded-lg flex items-center justify-center text-slate-400">
                        {language === "en" ? "No Photo Uploaded" : "कोई फोटो नहीं है"}
                      </div>
                    )}
                  </div>

                  {/* Triage Summary Column */}
                  <div className="md:col-span-8 space-y-2">
                    <div className="bg-slate-900 text-slate-200 p-3 rounded-xl border border-slate-800 space-y-2 shadow-sm">
                      <div className="flex items-center gap-1.5 border-b border-slate-800 pb-1">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                        <span className="text-[9px] font-black uppercase tracking-widest text-indigo-300">
                          {language === "en" ? "AI MULTI-AGENT TRIAGE" : "एआई मल्टी-एजेंट कमान लॉग"}
                        </span>
                      </div>
                      <p className="text-[10.5px] leading-relaxed text-slate-300 font-semibold">
                        {activeReport.aiTriage?.technical_summary || activeReport.description}
                      </p>
                      <div className="text-[10px] text-slate-400">
                        <strong>{language === "en" ? "Required Dispatch Materials: " : "आवश्यक निवारण सामग्री: "}</strong>
                        <span className="text-white">{activeReport.aiTriage?.required_materials || "Municipal dispatch crew"}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* GEMINI AI ASSISTANT PANEL */}
                <div className="bg-gradient-to-br from-indigo-50 to-violet-50 border border-indigo-200 rounded-xl p-4 space-y-3.5 shadow-xs">
                  <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
                      <span className="text-[10px] font-black text-indigo-950 uppercase tracking-widest">
                        {language === "en" ? "Gemini-Powered Officer Assistant" : "जेमिनी एआई सहायक प्रभाग"}
                      </span>
                    </div>
                    <span className="text-[9px] bg-indigo-600 text-white font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wide font-mono">
                      {language === "en" ? "Gemini 3.5 Flash" : "जेमिनी ३.५ फ़्लैश"}
                    </span>
                  </div>

                  {/* Resource Estimator Section */}
                  <div className="space-y-1">
                    <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">
                      {language === "en" ? "AI Suggested Resource Requirements" : "एआई सुझाई गई निवारण संसाधन आवश्यकताएं"}
                    </span>
                    {loadingEstimate ? (
                      <div className="flex items-center gap-2 py-2 text-indigo-600">
                        <div className="w-3.5 h-3.5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                        <span className="text-[10px] font-bold animate-pulse">
                          {language === "en" ? "Analyzing technical data..." : "तकनीकी डेटा का विश्लेषण..."}
                        </span>
                      </div>
                    ) : (
                      <div className="bg-white p-2.5 rounded-lg border border-indigo-100 font-mono text-[10.5px] text-slate-800 flex items-start gap-2 shadow-3xs">
                        <Wrench className="w-4 h-4 text-indigo-500 flex-shrink-0 mt-0.5" />
                        <div>
                          <strong>{language === "en" ? "Estimate: " : "अनुमान: "}</strong>
                          <span className="text-indigo-950 font-bold">{estimatedResources || (language === "en" ? "Awaiting data extraction..." : "डेटा निष्कर्षण की प्रतीक्षा...")}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Auto-Reply Draft Section */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">
                        {language === "en" ? "Bilingual Citizen Communication Draft" : "नागरिकों हेतु द्विभाषी संदेश प्रारूप"}
                      </span>
                      <button
                        onClick={handleGenerateDraft}
                        disabled={loadingDraft}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-extrabold py-1 px-2.5 rounded-md transition-all shadow-3xs flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <Mail className="w-3 h-3" />
                        {loadingDraft 
                          ? (language === "en" ? "Drafting..." : "तैयार किया जा रहा है...")
                          : (language === "en" ? "Draft Citizen Update" : "नागरिक संदेश प्रारूप बनाएं")
                        }
                      </button>
                    </div>

                    {draftReply && (
                      <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-2 shadow-3xs">
                        <p className="text-[10.5px] text-slate-700 leading-relaxed whitespace-pre-wrap font-semibold border-l-2 border-indigo-400 pl-2">
                          {draftReply}
                        </p>
                        <div className="flex justify-end gap-1.5 pt-1.5 border-t border-slate-100">
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(draftReply);
                              setCopiedId("reply-draft");
                              setTimeout(() => setCopiedId(null), 2000);
                            }}
                            className="bg-slate-100 hover:bg-slate-200 text-slate-600 text-[9px] font-bold py-1 px-2 rounded-md transition-all flex items-center gap-1 cursor-pointer"
                          >
                            {copiedId === "reply-draft" ? (
                              <>
                                <Check className="w-3 h-3 text-emerald-600" />
                                <span className="text-emerald-700 font-extrabold">{language === "en" ? "Copied!" : "कॉपी हुआ!"}</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>{language === "en" ? "Copy Update Message" : "संदेश कॉपी करें"}</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Status Dropdown Controller (Interactive Action) */}
                <div className="bg-indigo-50/50 border border-indigo-100 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="block text-[10px] font-black text-indigo-900 uppercase tracking-widest leading-none">
                      {language === "en" ? "Official Ticket Status Action" : "कार्यालयीन शिकायत स्थिति कार्रवाई"}
                    </span>
                    <span className="text-[10px] font-bold text-slate-500">
                      {language === "en" ? "Current State: " : "वर्तमान स्थिति: "} {getStatusBadge(activeReport.status)}
                    </span>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 items-center">
                    <span className="text-xs font-bold text-slate-600 sm:w-28 flex-shrink-0">{language === "en" ? "Modify Status:" : "स्थिति बदलें:"}</span>
                    <select
                      value={modalStatus}
                      onChange={(e) => {
                        const nextVal = e.target.value as any;
                        setModalStatus(nextVal);
                        if (nextVal !== "resolved") {
                          onUpdateStatus(activeReport.id, nextVal);
                        }
                      }}
                      className="flex-1 h-9 px-3 bg-white border border-indigo-200 rounded-lg text-xs font-black focus:outline-none focus:border-indigo-600 focus:ring-1 focus:ring-indigo-500 text-slate-800 cursor-pointer"
                    >
                      <option value="pending">{d.loggedPending}</option>
                      <option value="awaiting_verification">{d.awaitingVerification}</option>
                      <option value="in_progress">{d.dispatchedActive}</option>
                      <option value="resolved">{d.resolvedClosed}</option>
                    </select>
                  </div>

                  {/* If resolved selected or already resolved */}
                  {modalStatus === "resolved" && (
                    <div className="border-t border-indigo-100 pt-3 space-y-2">
                      <span className="block text-[9px] font-black text-slate-400 uppercase tracking-wider">
                        {language === "en" ? "Proof of Fix Photo (Required for Resolution)" : "निवारण प्रमाण चित्र (समाधान हेतु अनिवार्य)"}
                      </span>
                      
                      {activeReport.proofOfFix || proofOfFixPhoto ? (
                        <div className="space-y-2">
                          <img
                            src={activeReport.proofOfFix || proofOfFixPhoto}
                            alt="Proof of fix"
                            className="w-full h-32 object-cover rounded-lg border border-emerald-200 shadow-2xs"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex items-center gap-1.5 text-emerald-800 bg-emerald-50 border border-emerald-100 rounded-lg p-2 font-semibold text-[10.5px]">
                            <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                            <span>
                              {language === "en" 
                                ? "Resolution Confirmed! All citizen reporters and upvoters have been awarded leaderboard points."
                                : "समाधान की पुष्टि हुई! सभी शिकायतकर्ताओं और समर्थकों को लीडरबोर्ड अंक प्रदान कर दिए गए हैं।"
                              }
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {/* File Drag Drop Zone */}
                          <div
                            onDragOver={handleDragOver}
                            onDrop={handleDropProof}
                            className="border-2 border-dashed border-indigo-200 hover:border-indigo-500 bg-white rounded-lg p-4 text-center cursor-pointer transition-all space-y-1.5"
                          >
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleFileChangeProof}
                              className="hidden"
                              id="proof-of-fix-upload"
                            />
                            <label htmlFor="proof-of-fix-upload" className="cursor-pointer block space-y-1">
                              <FileImage className="w-6 h-6 text-indigo-400 mx-auto" />
                              <span className="block font-black text-indigo-950 text-[10px]">
                                {language === "en" ? "Drag & Drop or Click to Upload Proof of Fix Photo" : "निवारण चित्र खींचें और छोड़ें या अपलोड करने के लिए क्लिक करें"}
                              </span>
                              <span className="block text-[9px] text-slate-400">
                                {language === "en" ? "Supported formats: PNG, JPG (Max 5MB)" : "समर्थित प्रारूप: PNG, JPG (अधिकतम 5MB)"}
                              </span>
                            </label>
                          </div>

                          {uploadingProof && (
                            <div className="text-center text-xs text-indigo-600">
                              {language === "en" ? "Uploading and processing image..." : "छवि अपलोड और संसाधित की जा रही है..."}
                            </div>
                          )}

                          {proofOfFixPhoto && (
                            <div className="space-y-2">
                              <img
                                src={proofOfFixPhoto}
                                alt="Preview"
                                className="w-full h-32 object-cover rounded-lg border border-indigo-200 shadow-2xs"
                                referrerPolicy="no-referrer"
                              />
                              <button
                                onClick={() => {
                                  onUpdateStatus(activeReport.id, "resolved", proofOfFixPhoto);
                                }}
                                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-2 rounded-lg transition-all shadow-sm text-xs cursor-pointer flex items-center justify-center gap-1.5"
                              >
                                <CheckCircle className="w-4 h-4" />
                                {language === "en" ? "Submit Resolution & Credit Citizen Points" : "समाधान सबमिट करें और नागरिक अंक प्रदान करें"}
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="bg-slate-50 border-t border-slate-200 p-3 flex justify-end gap-2">
                <button
                  onClick={() => setSelectedReportId(null)}
                  className="bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] font-extrabold py-1.5 px-4 rounded-lg transition-all shadow-3xs cursor-pointer"
                >
                  {language === "en" ? "Close Preview" : "पूर्वावलोकन बंद करें"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 3. FOOTER */}
      <footer className="h-8 bg-slate-900 flex-shrink-0 px-6 flex items-center justify-between text-[10px] font-bold text-slate-400 border-t border-slate-800 z-50">
        <div>
          <span>{language === "en" ? "NIC Server: Active" : "एनआईसी सर्वर: सक्रिय"}</span>
          <span className="mx-2 text-slate-700">|</span>
          <span>{language === "en" ? "Officer Access Node: officer_chw" : "अधिकारी पहुंच नोड: officer_chw"}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          <span>{language === "en" ? "Secure Encrypted Session (AES-256)" : "सुरक्षित एन्क्रिप्टेड सत्र (AES-256)"}</span>
        </div>
      </footer>

    </div>
  );
}
