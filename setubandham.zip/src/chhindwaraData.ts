import { Report } from "./types";

export const CHHINDWARA_MOCK_REPORTS: Report[] = [
  {
    id: "MP-CHW-001",
    category: "pothole",
    severity: 4,
    location: "Main Coal Mine Approach Road, Parasia / मुख्य कोयला खदान पहुंच मार्ग, परासिया",
    description: "Deep potholes on the main coal mine approach road causing heavy traffic delays. / मुख्य कोयला खदान पहुंच मार्ग पर गहरे गड्ढे, जिससे भारी जाम लग रहा है।",
    lat: 35,
    lng: 30,
    media: "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=400&q=80",
    status: "awaiting_verification",
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(), // 2 hours ago
    reporter: "Arjun Singh",
    district: "Chhindwara",
    tehsil: "Parasia",
    verificationVotes: ["Vijay Dubey", "Renu Soni"],
    aiTriage: {
      primary_issue_type: "Infrastructure - Roadway Potholes",
      severity_score: 4,
      technical_summary: "Severe stripping of bitumen binder on the coal transport corridor. Heavy axle loads from dumper trucks have caused deep sub-base failures resulting in 15-20cm deep potholes across a 150m stretch.",
      required_materials: "WMM (Wet Mix Macadam) base coarse, asphalt tack coat emulsion, hot-mix bituminous concrete, mechanical static roller, pneumatic rammer."
    },
    agentWorkflowLogs: [
      "[Agent 1: Intake Router] Citizen report registered for Parasia Road.",
      "[Agent 2: Geolocation Verification] Coordinates confirmed near Parasia Coal belt (Lat 35, Lng 30).",
      "[Agent 3: Category Classifier] Categorized under 'pothole' maintenance network.",
      "[Agent 4: Authority Matcher] Identified recipient: Public Works Department (PWD) Parasia Sub-division.",
      "[Agent 5: Letter Draftsman] Formulated formal civic petition in bilateral language."
    ],
    complaintLetters: {
      english: `To,
The Sub-Divisional Officer,
Public Works Department (PWD),
Parasia Sub-Division, Chhindwara, MP.

Subject: Urgent Repair of Potholes on Coal Mine Approach Road, Parasia.

Respected Sir,

I am writing to draw your attention to the extremely hazardous condition of the main approach road leading to the coal mine colony in Parasia. Deep potholes have formed over a stretch of 150 meters, causing severe vehicle damage and traffic blockages.

Given the heavy load of coal dumpers, these craters pose immediate safety hazards to commuters and schoolchildren.

We request immediate patch repairs and bitumen overlay.

Yours sincerely,
Arjun Singh & Residents of Parasia

--- APPENDIX: SECTOR TRIAGE DATA ---
- District: Chhindwara
- Tehsil: Parasia
- Coordinates: Lat 35, Lng 30
- System Audit ID: MP-CHW-001`,
      hindi: `सेवा में,
अनुविभागीय अधिकारी,
लोक निर्माण विभाग (PWD),
परासिया उप-संभाग, छिंदवाड़ा, म.प्र.।

विषय: मुख्य कोयला खदान पहुंच मार्ग पर गहरे गड्ढों की तत्काल मरम्मत।

महोदय,

मैं परासिया कोयला खदान कॉलोनी की ओर जाने वाले मुख्य पहुंच मार्ग पर अत्यधिक खतरनाक गड्ढों की ओर आपका ध्यान आकर्षित करना चाहता हूँ। लगभग 150 मीटर के क्षेत्र में गहरे गड्ढे हो गए हैं, जिससे यातायात बाधित हो रहा है।

डम्परों के भारी भार को देखते हुए, ये गड्ढे राहगीरों और स्कूली बच्चों के लिए अत्यधिक असुरक्षित हैं। कृपया तत्काल पैच मरम्मत करवाएं।

भवदीय,
अर्जुन सिंह एवं परासिया के नागरिक

--- परिशिष्ट: सेक्टर डेटा ---
- जिला: छिंदवाड़ा
- तहसील: परासिया
- निर्देशांक: अक्षांश 35, देशांतर 30
- सिस्टम ऑडिट आईडी: MP-CHW-001`,
      recipientAgency: "PWD Parasia Sub-Division"
    }
  },
  {
    id: "MP-CHW-002",
    category: "water_leak",
    severity: 5,
    location: "Valley Viewpoint Area, Tamia / घाटी व्यूपॉइंट क्षेत्र के पास, तामिया",
    description: "Main drinking water pipeline burst near the valley viewpoint area. Significant water loss. / घाटी व्यूपॉइंट क्षेत्र के पास मुख्य पेयजल पाइपलाइन फट गई है। भारी जल हानि।",
    lat: 42,
    lng: 20,
    media: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=400&q=80",
    status: "in_progress", // Escalated to Municipality -> in_progress
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(), // 5 hours ago
    reporter: "Suresh Bharati",
    district: "Chhindwara",
    tehsil: "Tamia",
    verificationVotes: ["Anita Dhurve", "Devendra Kakodiya", "Ramesh Chandel"],
    aiTriage: {
      primary_issue_type: "Utility - Water Pipeline Burst",
      severity_score: 5,
      technical_summary: "Rupture of 300mm diameter cast-iron main distribution pipe near the Tamia Ghat road viewpoint. High pressure discharge is eroding the roadside soil slope, creating risk of a major landslide if not sealed.",
      required_materials: "300mm cast iron sleeve clamp, rubber joint gasket, pneumatic excavation spade, water-pump for dewatering."
    },
    agentWorkflowLogs: [
      "[Agent 1: Intake Router] Received water leakage emergency alert for Tamia.",
      "[Agent 2: GIS Geolocation] Pinpointed near Tamia Viewpoint (Lat 42, Lng 20).",
      "[Agent 3: Critical Classifier] Escalated to level 5 due to massive water loss and soil erosion risk.",
      "[Agent 4: Department Linker] Agency matched: Public Health Engineering (PHE) Division Chhindwara.",
      "[Agent 5: Escalator] Automated system logged complaints. Crew dispatched to site."
    ],
    complaintLetters: {
      english: `To,
The Executive Engineer,
Public Health Engineering Department (PHED),
Chhindwara Division, Madhya Pradesh.

Subject: Immediate Intervention for Main Drinking Water Pipeline Burst at Tamia Viewpoint.

Respected Sir,

We wish to report a critical failure in the main drinking water pipeline feeding the Tamia cluster, located right beside the main Valley Viewpoint.

The 300mm cast iron main line has suffered a high-pressure burst. Thousands of gallons of treated drinking water are being wasted hourly, and the rapid discharge is washing away the highway shoulder slope.

Kindly deploy your maintenance emergency team to shut off the valve and seal the burst joint.

Yours faithfully,
Suresh Bharati & Tamia Citizens

--- APPENDIX: SECTOR TRIAGE DATA ---
- District: Chhindwara
- Tehsil: Tamia
- Coordinates: Lat 42, Lng 20
- System Audit ID: MP-CHW-002`,
      hindi: `सेवा में,
कार्यपालन यंत्री,
लोक स्वास्थ्य यांत्रिकी विभाग (PHED),
छिंदवाड़ा संभाग, मध्य प्रदेश।

विषय: तामिया व्यूपॉइंट के पास मुख्य पेयजल पाइपलाइन फटने के संबंध में तत्काल कार्रवाई।

महोदय,

हम तामिया व्यूप्वाइंट के ठीक बगल में स्थित मुख्य पेयजल पाइपलाइन में हुए गंभीर विफलता की रिपोर्ट कर रहे हैं।

300 मिमी व्यास की मुख्य पाइपलाइन उच्च दबाव के कारण फट गई है। हजारों लीटर स्वच्छ पेयजल नष्ट हो रहा है और घाटी की ढलान वाली सड़क की मिट्टी बह रही है।

कृपया आपातकालीन तकनीकी दल को वाल्व बंद कर पाइपलाइन ठीक करने हेतु निर्देशित करें।

भवदीय,
सुरेश भारती एवं तामिया के निवासी

--- परिशिष्ट: सेक्टर डेटा ---
- जिला: छिंदवाड़ा
- तहसील: तामिया
- निर्देशांक: अक्षांश 42, देशांतर 20
- सिस्टम ऑडिट आईडी: MP-CHW-002`,
      recipientAgency: "PHED Chhindwara Division"
    }
  },
  {
    id: "MP-CHW-003",
    category: "streetlight",
    severity: 3,
    location: "Primary School Road, Amarwara / प्राथमिक विद्यालय मार्ग, अमरवाड़ा",
    description: "Three streetlights broken near the primary school, area is completely dark at night. / प्राथमिक विद्यालय के पास तीन स्ट्रीट लाइटें टूटी हुई हैं, रात में क्षेत्र में पूरी तरह अंधेरा रहता है।",
    lat: 30,
    lng: 48,
    media: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=400&q=80",
    status: "resolved", // Resolved
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(), // 1 day ago
    reporter: "Karan Kakodiya",
    district: "Chhindwara",
    tehsil: "Amarwara",
    verificationVotes: ["Shyam Sahu", "Pratima Patel"],
    aiTriage: {
      primary_issue_type: "Municipal - Streetlight Failure",
      severity_score: 3,
      technical_summary: "Three consecutive 50W LED street fixtures are non-operational. Circuit inspection reveals burned capacitor boards due to high-voltage surge in the local transformer line.",
      required_materials: "50W LED driver cards (3 units), insulation tapes, replacement fuses, crane boom truck for installation."
    },
    agentWorkflowLogs: [
      "[Agent 1: Intake Router] Received streetlight failure notification near primary school Amarwara.",
      "[Agent 2: GIS Geolocation] Resolved to Ward 5, School Road, Amarwara Council.",
      "[Agent 3: Classification] Streetlight grid failure. Medium priority.",
      "[Agent 4: Agency Director] Assigned to Amarwara Municipal Council Electrical Dept.",
      "[Agent 5: Audit Verification] Completed. Municipal team replaced all three LED bulbs. Status: Resolved."
    ],
    complaintLetters: {
      english: `To,
The Chief Municipal Officer,
Amarwara Municipal Council,
District Chhindwara, Madhya Pradesh.

Subject: Resolution Confirmation: Replacement of 3 Streetlights on Primary School Road.

Respected Sir,

We express our gratitude to the Amarwara Municipal Council for the swift action in repairing the streetlights near the primary school.

The installation of new high-efficiency LED lights has restored safety for children and residents walking down this street at night.

Thank you for utilizing the digital Setubandham integration portal.

Yours sincerely,
Karan Kakodiya

--- APPENDIX: SECTOR TRIAGE DATA ---
- District: Chhindwara
- Tehsil: Amarwara
- Coordinates: Lat 30, Lng 48
- System Audit ID: MP-CHW-003`,
      hindi: `सेवा में,
मुख्य नगर पालिका अधिकारी,
नगर पालिका परिषद अमरवाड़ा,
जिला छिंदवाड़ा, मध्य प्रदेश।

विषय: प्राथमिक स्कूल रोड पर 3 स्ट्रीट लाइटों की सफल मरम्मत हेतु धन्यवाद।

महोदय,

हम प्राथमिक स्कूल के पास स्ट्रीट लाइटों को बदलने की त्वरित कार्रवाई के लिए अमरवाड़ा नगर पालिका को धन्यवाद देते हैं।

नई कुशल एलईडी लाइटों से बच्चों और राहगीरों के लिए रात्रि में सुरक्षा बहाल हो गई है। त्वरित सुधार के लिए आभार।

भवदीय,
करण ककोड़िया

--- परिशिष्ट: सेक्टर डेटा ---
- जिला: छिंदवाड़ा
- तहसील: अमरवाड़ा
- निर्देशांक: अक्षांश 30, देशांतर 48
- सिस्टम ऑडिट आईडी: MP-CHW-003`,
      recipientAgency: "Amarwara Municipal Council"
    }
  },
  {
    id: "MP-CHW-004",
    category: "garbage",
    severity: 2,
    location: "Central Market Area, Chhindwara Town / केंद्रीय बाजार क्षेत्र, छिंदवाड़ा शहर",
    description: "Overflowing public waste bin near the central market. / मुख्य बाजार के पास सार्वजनिक कचरा पात्र भर कर बह रहा है।",
    lat: 40,
    lng: 42,
    media: "https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=400&q=80",
    status: "awaiting_verification",
    createdAt: new Date(Date.now() - 3600000 * 36).toISOString(), // 36 hours ago
    reporter: "Nilesh Mandloi",
    district: "Chhindwara",
    tehsil: "Chhindwara", // Mapped to Chhindwara
    verificationVotes: ["Amit Verma"],
    aiTriage: {
      primary_issue_type: "Municipal Sanitation - Overfilled Garbage Bin",
      severity_score: 2,
      technical_summary: "Municipal smart bin capacity exceeded. Accumulation of organic market refuse has overflowed onto the footpath, causing mild pedestrian obstruction and high odor dispersion.",
      required_materials: "Standard compactor garbage collection truck, bio-sanitization spray, Replacement heavy-duty liner bags."
    },
    agentWorkflowLogs: [
      "[Agent 1: Intake Router] Received garbage complaint in high-density Chhindwara Central market.",
      "[Agent 2: Geolocation Lookup] Central Chowk Market, Chhindwara Corporation.",
      "[Agent 3: Classification] Sanitation - Waste Overfill. Priority: Normal.",
      "[Agent 4: Routing Agent] Recipient Agency: Chhindwara Municipal Corporation (CMC) Sanitation Division.",
      "[Agent 5: Task Queue] Added to daily municipal clearing manifest."
    ],
    complaintLetters: {
      english: `To,
The Commissioner,
Chhindwara Municipal Corporation,
Chhindwara, Madhya Pradesh.

Subject: Cleansing of Overflowing Public Dustbin at Central Market.

Respected Sir,

I want to alert your team about a large public trash dumpster near the Central Market entrance that has overflowed onto the pedestrian path.

The raw waste is attracting stray animals and generating foul odors, making it difficult for citizens visiting the market. We request a waste collection truck to clear and sanitize the spot.

Sincerely,
Nilesh Mandloi

--- APPENDIX: SECTOR TRIAGE DATA ---
- District: Chhindwara
- Tehsil: Chhindwara
- Coordinates: Lat 40, Lng 42
- System Audit ID: MP-CHW-004`,
      hindi: `सेवा में,
आयुक्त महोदय,
नगर पालिक निगम छिंदवाड़ा,
छिंदवाड़ा, मध्य प्रदेश।

विषय: मुख्य बाजार क्षेत्र में कचरा पात्र की सफाई के संबंध में।

महोदय,

मैं मुख्य बाजार प्रवेश द्वार के पास रखे बड़े सार्वजनिक कूड़ेदान के अतिप्रवाह की ओर आपका ध्यान आकर्षित करना चाहता हूँ। कचरा बाहर फैल चुका है जिससे दुर्गंध आ रही है और राहगीरों को भारी असुविधा हो रही है।

कृपया कचरा संग्रहण वाहन भेजकर इसकी त्वरित सफाई सुनिश्चित करें।

भवदीय,
नीलेश मंडलोई

--- परिशिष्ट: सेक्टर डेटा ---
- जिला: छिंदवाड़ा
- तहसील: छिंदवाड़ा
- निर्देशांक: अक्षांश 40, देशांतर 42
- सिस्टम ऑडिट आईडी: MP-CHW-004`,
      recipientAgency: "Chhindwara Municipal Corporation"
    }
  }
];
