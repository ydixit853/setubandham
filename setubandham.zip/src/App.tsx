import React, { useState, useEffect, useRef } from "react";
import {
  MapPin,
  Plus,
  Image,
  Upload,
  CheckCircle,
  AlertOctagon,
  Clock,
  User,
  MapPinOff,
  Filter,
  BarChart3,
  ListFilter,
  Layers,
  ChevronRight,
  Info,
  Sparkles,
  X,
  FileImage,
  UserCheck,
  Trophy,
  Medal,
  Award,
  Edit2,
  Check,
  Zap,
  Activity,
  ShieldCheck,
  Sparkle,
  Lock,
  Building,
  LogOut,
  Copy,
  FileText
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Language, Report, Translations } from "./types";
import LiveMapDashboard from "./components/LiveMapDashboard";
import LoginLandingPage from "./components/LoginLandingPage";
import AdminDashboard from "./components/AdminDashboard";
import localesData from "./locales.json";
import { CHHINDWARA_MOCK_REPORTS } from "./chhindwaraData";

// Quick mock photos for civic reporting that users can instantly pick as presets,
// alongside supporting real local image uploads (base64).
const PRESET_CIVIC_IMAGES = [
  {
    name: "Pothole",
    url: "https://images.unsplash.com/photo-1515162305285-0293e4767cc2?auto=format&fit=crop&w=400&q=80",
    label_en: "Pothole Preset",
    label_hi: "पॉटहोल पूर्व-निर्धारित"
  },
  {
    name: "Broken Light",
    url: "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=400&q=80",
    label_en: "Streetlight Preset",
    label_hi: "स्ट्रीटलाइट पूर्व-निर्धारित"
  },
  {
    name: "Garbage Pile",
    url: "https://images.unsplash.com/photo-1611284446314-60a58ac0deb9?auto=format&fit=crop&w=400&q=80",
    label_en: "Garbage Preset",
    label_hi: "कचरा पूर्व-निर्धारित"
  },
  {
    name: "Water Leak",
    url: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=400&q=80",
    label_en: "Leakage Preset",
    label_hi: "लीकेज पूर्व-निर्धारित"
  }
];

const MP_DISTRICTS = [
  { id: "Chhindwara", name_en: "Chhindwara", name_hi: "छिंदवाड़ा" },
  { id: "Bhopal", name_en: "Bhopal", name_hi: "भोपाल" },
  { id: "Indore", name_en: "Indore", name_hi: "इन्दौर" },
  { id: "Jabalpur", name_en: "Jabalpur", name_hi: "जबलपुर" },
  { id: "Gwalior", name_en: "Gwalior", name_hi: "ग्वालियर" }
];

const MP_TEHSILS: Record<string, { id: string; name_en: string; name_hi: string }[]> = {
  Chhindwara: [
    { id: "Chhindwara", name_en: "Chhindwara", name_hi: "छिंदवाड़ा" },
    { id: "Parasia", name_en: "Parasia", name_hi: "परासिया" },
    { id: "Jamai (Junnardeo)", name_en: "Jamai (Junnardeo)", name_hi: "जामई (जुन्नारदेव)" },
    { id: "Amarwara", name_en: "Amarwara", name_hi: "अमरवाड़ा" },
    { id: "Chourai", name_en: "Chourai", name_hi: "चौरई" },
    { id: "Sausar", name_en: "Sausar", name_hi: "सौसर" },
    { id: "Mohkhed", name_en: "Mohkhed", name_hi: "मोहखेड़" },
    { id: "Harrai", name_en: "Harrai", name_hi: "हर्रई" },
    { id: "Tamia", name_en: "Tamia", name_hi: "तामिया" },
    { id: "Bichhua", name_en: "Bichhua", name_hi: "बिछुआ" },
    { id: "Umreth", name_en: "Umreth", name_hi: "उमरेठ" },
    { id: "Chand", name_en: "Chand", name_hi: "चांद" }
  ],
  Bhopal: [
    { id: "Huzur", name_en: "Huzur", name_hi: "हुजूर" },
    { id: "Berasia", name_en: "Berasia", name_hi: "बैरासिया" }
  ],
  Indore: [
    { id: "Indore", name_en: "Indore", name_hi: "इन्दौर" },
    { id: "Depalpur", name_en: "Depalpur", name_hi: "देपालपुर" },
    { id: "Sanwer", name_en: "Sanwer", name_hi: "सांवेर" },
    { id: "Mhow", name_en: "Mhow (Dr. Ambedkar Nagar)", name_hi: "महू (डॉ. अम्बेडकर नगर)" }
  ],
  Jabalpur: [
    { id: "Jabalpur", name_en: "Jabalpur", name_hi: "जबलपुर" },
    { id: "Sihora", name_en: "Sihora", name_hi: "सिहोरा" },
    { id: "Patan", name_en: "Patan", name_hi: "पाटन" },
    { id: "Kundam", name_en: "Kundam", name_hi: "कुण्डम" }
  ],
  Gwalior: [
    { id: "Gwalior", name_en: "Gwalior", name_hi: "ग्वालियर" },
    { id: "Dabra", name_en: "Dabra", name_hi: "डबरा" },
    { id: "Bhitarwar", name_en: "Bhitarwar", name_hi: "भितरवार" }
  ]
};

export default function App() {
  // Routing and Auth states
  const [currentPath, setCurrentPath] = useState<string>(window.location.pathname);
  const [userRole, setUserRole] = useState<"Citizen" | "Municipal_Officer" | "citizen" | "officer" | null>(() => {
    const saved = localStorage.getItem("setubandham_role");
    return (saved as any) || null;
  });
  const [userJurisdiction, setUserJurisdiction] = useState<string>(() => {
    return localStorage.getItem("setubandham_jurisdiction") || "";
  });

  const isCitizen = userRole === "Citizen" || userRole === "citizen";
  const isOfficer = userRole === "Municipal_Officer" || userRole === "officer";

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
    };
    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, "", path);
    setCurrentPath(path);
  };

  // 1. Core Language Context State
  const [language, setLanguage] = useState<Language>("en");
  
  // 2. Fetch Translations (with synchronous local import fallback to ensure instant load)
  const [t, setT] = useState<Translations>(localesData[language] as Translations);

  useEffect(() => {
    // Sync translated strings when language state changes
    setT(localesData[language] as Translations);
  }, [language]);

  // 3. Reports State
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  
  // 4. Filter State
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>("all");
  const [activeSeverityFilter, setActiveSeverityFilter] = useState<string>("all");
  const [isDemoMode, setIsDemoMode] = useState<boolean>(false);
  const [activeTehsilFilter, setActiveTehsilFilter] = useState<string>("all");

  // Sync Demo Mode for Official login to load Chhindwara data instantly
  useEffect(() => {
    if (isOfficer) {
      setIsDemoMode(true);
    }
  }, [isOfficer]);

  // Computed reports representing standard database reports
  const displayedReports = reports;
  
  // 5. Sidebar/Modal Open States
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);
  
  // 6. Form Field States
  const [formCategory, setFormCategory] = useState<string>("pothole");
  const [formSeverity, setFormSeverity] = useState<number>(3);
  const [formDistrict, setFormDistrict] = useState<string>("");
  const [formTehsil, setFormTehsil] = useState<string>("");
  const [formSpecificAddress, setFormSpecificAddress] = useState<string>("");

  const formLocation = React.useMemo(() => {
    if (!formDistrict) return "";
    const englishLocation = [
      formSpecificAddress.trim(),
      formTehsil ? `Tehsil ${formTehsil}` : "",
      `District ${formDistrict}`,
      "Madhya Pradesh"
    ].filter(Boolean).join(", ");

    const hindiLocation = [
      formSpecificAddress.trim(),
      formTehsil ? `तहसील ${MP_TEHSILS[formDistrict]?.find(t => t.id === formTehsil)?.name_hi || formTehsil}` : "",
      `ज़िला ${MP_DISTRICTS.find(d => d.id === formDistrict)?.name_hi || formDistrict}`,
      "मध्य प्रदेश"
    ].filter(Boolean).join(", ");

    return `${englishLocation} / ${hindiLocation}`;
  }, [formDistrict, formTehsil, formSpecificAddress]);

  const [formDescription, setFormDescription] = useState<string>("");
  const [formLat, setFormLat] = useState<number>(45);
  const [formLng, setFormLng] = useState<number>(45);
  const [formMedia, setFormMedia] = useState<string>("");
  const [formReporter, setFormReporter] = useState<string>(() => localStorage.getItem("setubandham_username") || "Aditya Kumar");
  const [activeTab, setActiveTab] = useState<"dashboard" | "leaderboard">("dashboard");
  const [leaderboard, setLeaderboard] = useState<any[]>([]);

  // Dynamic calculated leaderboard to sync points in real-time
  const computedLeaderboard = React.useMemo(() => {
    const championsMap: { 
      [name: string]: { 
        reportsVerified: number; 
        upvotesGiven: number; 
        resolvedCount: number; 
        points: number;
      } 
    } = {
      "Sanjay Dixit": { reportsVerified: 3, upvotesGiven: 12, resolvedCount: 2, points: 154 },
      "Rahul Sharma": { reportsVerified: 2, upvotesGiven: 8, resolvedCount: 1, points: 86 },
      "Priya Patel": { reportsVerified: 4, upvotesGiven: 5, resolvedCount: 1, points: 100 },
      "Amit Verma": { reportsVerified: 2, upvotesGiven: 15, resolvedCount: 0, points: 50 },
      "Neha Gupta": { reportsVerified: 3, upvotesGiven: 9, resolvedCount: 1, points: 98 },
      "Ananya Sen": { reportsVerified: 1, upvotesGiven: 20, resolvedCount: 0, points: 60 }
    };

    if (formReporter && !championsMap[formReporter]) {
      championsMap[formReporter] = { reportsVerified: 0, upvotesGiven: 0, resolvedCount: 0, points: 0 };
    }

    displayedReports.forEach((report) => {
      const reporter = report.reporter || "Anonymous Citizen";
      
      if (!championsMap[reporter]) {
        championsMap[reporter] = { reportsVerified: 0, upvotesGiven: 0, resolvedCount: 0, points: 0 };
      }

      const isVerified = report.status !== "awaiting_verification" || (report.verificationVotes && report.verificationVotes.length > 0);
      if (isVerified) {
        championsMap[reporter].reportsVerified += 1;
        championsMap[reporter].points += 10;
      }

      if (report.status === "resolved") {
        championsMap[reporter].resolvedCount += 1;
        if (report.proofOfFix) {
          championsMap[reporter].points += 100; // 100 points for resolved with proof of fix!
        } else {
          championsMap[reporter].points += 50; // 50 points standard resolved
        }
      }

      if (report.verificationVotes) {
        report.verificationVotes.forEach((voter) => {
          if (!championsMap[voter]) {
            championsMap[voter] = { reportsVerified: 0, upvotesGiven: 0, resolvedCount: 0, points: 0 };
          }
          championsMap[voter].upvotesGiven += 1;
          
          if (report.status === "resolved" && report.proofOfFix) {
            championsMap[voter].points += 25; // 25 bonus points to upvoters of resolved issue with proof of fix!
          } else {
            championsMap[voter].points += 2; // Standard upvote points
          }
        });
      }
    });

    return Object.keys(championsMap).map((name) => ({
      name,
      ...championsMap[name]
    })).sort((a, b) => b.points - a.points);
  }, [displayedReports, formReporter]);

  useEffect(() => {
    setLeaderboard(computedLeaderboard);
  }, [computedLeaderboard]);

  const [leaderboardLoading, setLeaderboardLoading] = useState<boolean>(false);
  const [isEditingName, setIsEditingName] = useState<boolean>(false);
  const [tempName, setTempName] = useState<string>("Aditya Kumar");
  const [leaderboardSearch, setLeaderboardSearch] = useState<string>("");
  
  // Feedback Messages
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 7. AI Triage Assessment States
  const [triageResults, setTriageResults] = useState<{
    primary_issue_type: string;
    severity_score: number;
    technical_summary: string;
    required_materials: string;
    recipientAgency?: string;
    complaintLetters?: {
      english: string;
      hindi: string;
      recipientAgency: string;
    };
    agentWorkflowLogs?: string[];
  } | null>(null);
  const [isTriaging, setIsTriaging] = useState<boolean>(false);
  const [letterLangTab, setLetterLangTab] = useState<"en" | "hi">("en");

  // Trigger automatic Gemini AI Triage & Multi-Agent workflow when media, category, or location is available
  useEffect(() => {
    if (!formMedia || !formDistrict) {
      setTriageResults(null);
      return;
    }

    const runTriage = async () => {
      setIsTriaging(true);
      setTriageResults(null);
      try {
        const res = await fetch("/api/triage", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            media: formMedia,
            location: formLocation,
            lat: formLat,
            lng: formLng,
            category: formCategory,
            district: formDistrict,
            tehsil: formTehsil
          })
        });
        if (res.ok) {
          const data = await res.json();
          setTriageResults(data);
          
          // Autofill severity and suggest classification mapping where possible
          if (data.severity_score) {
            setFormSeverity(data.severity_score);
          }
        } else {
          console.warn("AI Triage failed or was not configured");
        }
      } catch (err) {
        console.error("Error calling AI Triage:", err);
      } finally {
        setIsTriaging(false);
      }
    };

    const debounceTimer = setTimeout(() => {
      runTriage();
    }, 1000); // 1-second debounce to prevent spamming server/API on keystrokes

    return () => {
      clearTimeout(debounceTimer);
    };
  }, [formMedia, formLocation, formLat, formLng, formCategory, formDistrict, formTehsil]);

  // Fetch leaderboard data from the backend
  const fetchLeaderboard = async () => {
    try {
      setLeaderboardLoading(true);
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const ct = res.headers.get("content-type");
        if (ct && ct.includes("application/json")) {
          const data = await res.json();
          setLeaderboard(data);
        }
      }
    } catch (err) {
      console.error("Error fetching leaderboard:", err);
    } finally {
      setLeaderboardLoading(false);
    }
  };

  // Fetch reports from the API backend
  const fetchReports = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/reports");
      if (res.ok) {
        const ct = res.headers.get("content-type");
        if (ct && ct.includes("application/json")) {
          const data = await res.json();
          const normalized = data.map((r: any) => {
            let s = r.status;
            if (s === "Resolved / समाधान हो गया") s = "resolved";
            if (s === "Awaiting Verification") s = "awaiting_verification";
            return { ...r, status: s };
          });
          setReports(normalized);
        }
      }
    } catch (err) {
      console.error("Error fetching reports:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyReport = async (reportId: string) => {
    try {
      const res = await fetch(`/api/reports/${reportId}/verify`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ voterName: formReporter })
      });
      if (res.ok) {
        const ct = res.headers.get("content-type");
        if (ct && ct.includes("application/json")) {
          const updatedReport = await res.json();
          const normalized = {
            ...updatedReport,
            status: updatedReport.status === "Resolved / समाधान हो गया" ? "resolved" : 
                    updatedReport.status === "Awaiting Verification" ? "awaiting_verification" : 
                    updatedReport.status
          };
          setReports(prev => prev.map(r => r.id === reportId ? normalized : r));
          setSuccessMsg(language === "en" ? t.verificationSuccess : "सत्यापन वोट दर्ज! अंक प्रदान किए गए।");
          setTimeout(() => setSuccessMsg(null), 4000);
          // Refresh leaderboard points dynamically
          fetchLeaderboard();
        }
      }
    } catch (err) {
      console.error("Error verifing/upvoting report:", err);
    }
  };

  // Silent refetch to sync Citizen and Officer views seamlessly in real-time
  const fetchReportsSilent = async () => {
    try {
      const res = await fetch("/api/reports");
      if (res.ok) {
        const ct = res.headers.get("content-type");
        if (ct && ct.includes("application/json")) {
          const data = await res.json();
          const normalized = data.map((r: any) => {
            let s = r.status;
            if (s === "Resolved / समाधान हो गया") s = "resolved";
            if (s === "Awaiting Verification") s = "awaiting_verification";
            return { ...r, status: s };
          });
          setReports(normalized);
        }
      }
    } catch (err) {
      // Fail silently for background polls
    }
  };

  // Poll for updates every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      fetchReportsSilent();
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Track resolved report IDs to prevent repeating notifications for already-resolved issues
  const [resolvedParasiaIds, setResolvedParasiaIds] = useState<Set<string>>(new Set());
  const [parasiaNotification, setParasiaNotification] = useState<{ show: boolean; msgEn: string; msgHi: string } | null>(null);
  const isFirstLoad = useRef(true);

  useEffect(() => {
    if (reports.length === 0) return;

    const currentResolvedParasiaIds = reports
      .filter(r => {
        const inParasia = r.tehsil === "Parasia" || (r.location && r.location.toLowerCase().includes("parasia"));
        const isResolved = r.status === "resolved" || r.status === "Resolved / समाधान हो गया";
        return inParasia && isResolved;
      })
      .map(r => r.id);

    if (isFirstLoad.current) {
      setResolvedParasiaIds(new Set(currentResolvedParasiaIds));
      isFirstLoad.current = false;
    } else {
      const newlyResolved = currentResolvedParasiaIds.filter(id => !resolvedParasiaIds.has(id));
      if (newlyResolved.length > 0) {
        setParasiaNotification({
          show: true,
          msgEn: "The issue in Parasia has been resolved by the Municipal Team!",
          msgHi: "परासिया में समस्या का समाधान नगर पालिका टीम द्वारा कर दिया गया है!"
        });
        
        setResolvedParasiaIds(prev => {
          const next = new Set(prev);
          newlyResolved.forEach(id => next.add(id));
          return next;
        });
      }
    }
  }, [reports, resolvedParasiaIds]);

  useEffect(() => {
    fetchReports();
    fetchLeaderboard();
  }, []);

  // Update Status of a report in the list
  const handleUpdateStatus = async (reportId: string, nextStatus: "pending" | "in_progress" | "resolved" | "awaiting_verification", proofOfFix?: string) => {
    try {
      const res = await fetch(`/api/reports/${reportId}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus, proofOfFix })
      });
      if (res.ok) {
        const updated = await res.json();
        const normalized = {
          ...updated,
          status: updated.status === "Resolved / समाधान हो गया" ? "resolved" : 
                  updated.status === "Awaiting Verification" ? "awaiting_verification" : 
                  updated.status
        };
        setReports(prev => prev.map(r => r.id === reportId ? normalized : r));
        setSuccessMsg(language === "en" ? "Status updated successfully!" : "स्थिति सफलतापूर्वक अपडेट की गई!");
        setTimeout(() => setSuccessMsg(null), 4000);
        fetchLeaderboard();
      }
    } catch (err) {
      console.error("Error updating status:", err);
    }
  };

  // Open form with optionally prefilled map coordinates and address
  const handleOpenForm = (prefilledCoords?: { lat: number; lng: number }, prefilledAddress?: string) => {
    if (prefilledCoords) {
      setFormLat(prefilledCoords.lat);
      setFormLng(prefilledCoords.lng);
    } else {
      // Pick random near central map coordinates if none prefilled
      setFormLat(Math.floor(Math.random() * 50) + 25);
      setFormLng(Math.floor(Math.random() * 50) + 25);
    }
    if (prefilledAddress) {
      setFormSpecificAddress(prefilledAddress);
    }
    
    // Clear previous form errors
    setErrorMsg(null);
    setIsFormOpen(true);
    setSelectedReportId(null); // Close inspect view
  };

  // Drag and drop / local file read for formMedia base64 conversion
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setFormMedia(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Handle Form Submission
  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!formDistrict) {
      setErrorMsg(language === "en" ? "Please select a District." : "कृपया एक ज़िला चुनें।");
      return;
    }

    if (!formTehsil) {
      setErrorMsg(language === "en" ? "Please select a Tehsil." : "कृपया एक तहसील चुनें।");
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        category: formCategory,
        severity: formSeverity,
        location: formLocation,
        description: formDescription,
        lat: formLat,
        lng: formLng,
        media: formMedia,
        reporter: formReporter,
        aiTriage: triageResults ? {
          primary_issue_type: triageResults.primary_issue_type,
          severity_score: triageResults.severity_score,
          technical_summary: triageResults.technical_summary,
          required_materials: triageResults.required_materials
        } : undefined,
        agentWorkflowLogs: triageResults?.agentWorkflowLogs,
        complaintLetters: triageResults?.complaintLetters,

        // Schema requirement fields
        district: formDistrict,
        tehsil: formTehsil,
        issue_type: formCategory,
        description_hi: language === "hi" ? formDescription : "",
        description_en: language === "en" ? formDescription : "",
        upvotes: 1
      };

      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const newReport = await res.json();
        setReports(prev => [newReport, ...prev]);
        setSuccessMsg(t.successMessage);
        
        // Reset form fields
        setFormDistrict("");
        setFormTehsil("");
        setFormSpecificAddress("");
        setFormDescription("");
        setFormMedia("");
        setTriageResults(null);
        setIsFormOpen(false);

        // Auto-select newly created report
        setSelectedReportId(newReport.id);
        
        // Refresh leaderboard points dynamically
        fetchLeaderboard();
        
        // Dismiss success message after 5 seconds
        setTimeout(() => {
          setSuccessMsg(null);
        }, 5000);
      } else {
        setErrorMsg(t.errorMessage);
      }
    } catch (err) {
      console.error("Error submitting report:", err);
      setErrorMsg(language === "en" ? "Server connection failed. Please retry." : "सर्वर कनेक्शन विफल रहा। कृपया पुन: प्रयास करें।");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Auto-detect stats count for the Dashboard widgets
  const stats = React.useMemo(() => {
    const total = displayedReports.length;
    const active = displayedReports.filter(r => r.status !== "resolved").length;
    const resolved = displayedReports.filter(r => r.status === "resolved").length;
    return { total, active, resolved };
  }, [displayedReports]);

  // Inspect specific report clicked from anywhere (List or Map)
  const handleReportClick = (report: Report) => {
    setSelectedReportId(report.id);
    setIsFormOpen(false); // Close form if active
  };

  const selectedReport = React.useMemo(() => {
    return displayedReports.find(r => r.id === selectedReportId) || null;
  }, [displayedReports, selectedReportId]);

  const handleLogout = () => {
    setUserRole(null);
    setUserJurisdiction("");
    localStorage.removeItem("setubandham_role");
    localStorage.removeItem("setubandham_jurisdiction");
    localStorage.removeItem("setubandham_username");
    setIsDemoMode(false);
    navigate("/");
  };

  const redirectReason = React.useMemo(() => {
    if (currentPath === "/admin-dashboard" && !isOfficer) {
      return language === "en"
        ? "Official authentication is required to access the Protected Command Board."
        : "सुरक्षित कमान बोर्ड तक पहुँचने के लिए आधिकारिक सत्यापन आवश्यक है।";
    }
    return null;
  }, [currentPath, isOfficer, language]);

  // Protected Admin route
  if (currentPath === "/admin-dashboard" && isOfficer) {
    return (
      <AdminDashboard
        language={language}
        setLanguage={setLanguage}
        reports={displayedReports}
        onUpdateStatus={handleUpdateStatus}
        onLogout={handleLogout}
        t={t}
        onVerifyReport={handleVerifyReport}
        userJurisdiction={userJurisdiction}
      />
    );
  }

  // Login landing page
  if (userRole === null || (currentPath === "/admin-dashboard" && !isOfficer)) {
    return (
      <LoginLandingPage
        language={language}
        setLanguage={setLanguage}
        onLoginSuccess={(role, username, displayName, jurisdiction) => {
          if (role === "citizen") {
            const finalName = displayName || username || "Aditya Kumar";
            setFormReporter(finalName);
            setUserRole("citizen");
            localStorage.setItem("setubandham_role", "citizen");
            localStorage.setItem("setubandham_username", finalName);
            navigate("/");
          } else {
            const finalJurisdiction = jurisdiction || "Tehsil: Parasia, District: Chhindwara";
            setUserRole("officer");
            setUserJurisdiction(finalJurisdiction);
            localStorage.setItem("setubandham_role", "officer");
            localStorage.setItem("setubandham_jurisdiction", finalJurisdiction);
            const finalName = displayName || username;
            localStorage.setItem("setubandham_username", finalName);
            setIsDemoMode(true);
            navigate("/admin-dashboard");
          }
        }}
        onCitizenEnter={(name) => {
          const finalName = name || "Aditya Kumar";
          setFormReporter(finalName);
          setUserRole("citizen");
          localStorage.setItem("setubandham_role", "citizen");
          localStorage.setItem("setubandham_username", finalName);
          navigate("/");
        }}
        onOfficialLogin={(username, password) => {
          if (username === "officer_parasia" && password === "mp_admin") {
            setUserRole("officer");
            setUserJurisdiction("Tehsil: Parasia, District: Chhindwara");
            localStorage.setItem("setubandham_role", "officer");
            localStorage.setItem("setubandham_jurisdiction", "Tehsil: Parasia, District: Chhindwara");
            localStorage.setItem("setubandham_username", "Parasia Municipal Officer");
            setIsDemoMode(true);
            navigate("/admin-dashboard");
            return true;
          }
          if (username === "officer_chw" && password === "admin") {
            setUserRole("officer");
            setUserJurisdiction("Chhindwara District");
            localStorage.setItem("setubandham_role", "officer");
            localStorage.setItem("setubandham_jurisdiction", "Chhindwara District");
            localStorage.setItem("setubandham_username", "Chhindwara District Officer");
            setIsDemoMode(true);
            navigate("/admin-dashboard");
            return true;
          }
          return false;
        }}
        redirectReason={redirectReason}
      />
    );
  }

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 font-sans text-slate-900 overflow-hidden">
      
      {/* 1. TOP NAVBAR (Professional Polish design) */}
      <nav className="h-16 flex-shrink-0 bg-white border-b border-slate-200 px-6 flex items-center justify-between z-50 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-indigo-700 rounded-lg flex items-center justify-center text-white font-bold text-xl shadow-md shadow-indigo-100">
            स
          </div>
          <div>
            <h1 className="text-lg font-extrabold leading-tight text-indigo-950 flex items-center gap-2">
              <span>{t.appName}</span>
              <span className="text-xs font-normal text-slate-400 border border-slate-200 px-1.5 py-0.5 rounded">
                v1.1
              </span>
            </h1>
            <p className="text-xs font-semibold text-slate-500">
              {language === "en" ? "सेतुबंधम" : "Setubandham"} • {t.appTagline}
            </p>
          </div>
        </div>

        {/* Navigation Tabs (Dashboard vs Leaderboard) */}
        <div className="flex bg-slate-100 rounded-lg p-1 border border-slate-200">
          <button
            type="button"
            onClick={() => setActiveTab("dashboard")}
            className={`px-3 py-1.5 text-xs font-bold rounded-md flex items-center gap-1.5 transition-all duration-200 ${
              activeTab === "dashboard"
                ? "bg-white shadow-xs text-indigo-700"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-indigo-600" />
            <span className="hidden sm:inline">{language === "en" ? "Map Dashboard" : "नक्शा डैशबोर्ड"}</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab("leaderboard");
              fetchLeaderboard();
            }}
            className={`px-3 py-1.5 text-xs font-bold rounded-md flex items-center gap-1.5 transition-all duration-200 ${
              activeTab === "leaderboard"
                ? "bg-white shadow-xs text-indigo-700"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden sm:inline">{t.leaderboardTab}</span>
          </button>
        </div>

        <div className="flex items-center gap-6">
          {/* Judges' Demo Mode Toggle */}
          <button
            type="button"
            onClick={() => {
              setIsDemoMode(prev => {
                const nextVal = !prev;
                // Clear any selection, and reset Tehsil filter to "all"
                setSelectedReportId(null);
                setActiveTehsilFilter("all");
                return nextVal;
              });
            }}
            className={`px-3.5 py-1.5 rounded-full text-[10px] sm:text-xs font-black tracking-wide flex items-center gap-1.5 transition-all duration-300 border ${
              isDemoMode
                ? "bg-rose-600 text-white border-rose-700 shadow-md shadow-rose-200 animate-pulse"
                : "bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200/80"
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isDemoMode ? "text-yellow-300 fill-yellow-300 animate-bounce" : "text-slate-500"}`} />
            <span>
              {isDemoMode
                ? (language === "en" ? "DEMO ACTIVE: CHHINDWARA" : "डेमो सक्रिय: छिंदवाड़ा")
                : (language === "en" ? "Judge Demo Mode" : "जज डेमो मोड")}
            </span>
          </button>

          {/* Language Toggle Component */}
          <div className="flex bg-slate-100 rounded-full p-1 border border-slate-200">
            <button
              onClick={() => setLanguage("en")}
              className={`px-4 py-1 text-xs font-bold rounded-full transition-all duration-200 ${
                language === "en"
                  ? "bg-white shadow-sm text-indigo-700"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              English
            </button>
            <button
              onClick={() => setLanguage("hi")}
              className={`px-4 py-1 text-xs font-bold rounded-full transition-all duration-200 ${
                language === "hi"
                  ? "bg-white shadow-sm text-indigo-700"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              हिंदी
            </button>
          </div>

          <div className="hidden sm:block h-6 w-px bg-slate-200"></div>

          {/* User Profile Info with Edit Name feature */}
          <div className="flex items-center gap-3 select-none">
            {isEditingName ? (
              <div className="flex items-center gap-1 bg-white p-1 rounded border border-slate-200 shadow-sm">
                <input
                  type="text"
                  value={tempName}
                  onChange={(e) => setTempName(e.target.value)}
                  className="w-24 text-xs bg-transparent focus:outline-none text-slate-800 font-bold"
                  placeholder="Your Name"
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && tempName.trim()) {
                      setFormReporter(tempName.trim());
                      setIsEditingName(false);
                      setTimeout(() => fetchLeaderboard(), 100);
                    }
                  }}
                />
                <button
                  onClick={() => {
                    if (tempName.trim()) {
                      setFormReporter(tempName.trim());
                      setIsEditingName(false);
                      setTimeout(() => fetchLeaderboard(), 100);
                    }
                  }}
                  className="p-1 text-emerald-600 hover:bg-slate-100 rounded"
                  title="Save Name"
                >
                  <Check className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <div 
                onClick={() => {
                  setTempName(formReporter);
                  setIsEditingName(true);
                }}
                className="text-right hidden md:block cursor-pointer hover:opacity-80 group"
                title={language === "en" ? "Click to edit your name" : "अपना नाम बदलने के लिए क्लिक करें"}
              >
                <p className="text-xs font-bold text-slate-800 flex items-center justify-end gap-1">
                  <span>{formReporter}</span>
                  <Edit2 className="w-2.5 h-2.5 text-slate-400 group-hover:text-indigo-600" />
                </p>
                <p className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                  {language === "en" ? "Ward Representative" : "वार्ड प्रतिनिधि"}
                </p>
              </div>
            )}
            <div className="w-9 h-9 rounded-full bg-indigo-100 border border-indigo-200 flex items-center justify-center text-indigo-700 shadow-sm">
              <User className="w-4 h-4" />
            </div>

            <button
              onClick={handleLogout}
              className="p-2 bg-rose-50 hover:bg-rose-100 border border-rose-200/50 rounded-lg text-rose-600 transition-all cursor-pointer flex items-center justify-center"
              title={language === "en" ? "Exit Portal" : "पोर्टल से बाहर जाएँ"}
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Parasia Resolution Success Notification Banner */}
      {parasiaNotification && parasiaNotification.show && (
        <div id="parasia-resolved-notification" className="bg-emerald-600 text-white px-6 py-3 flex items-center justify-between border-b border-emerald-700 font-sans shadow-lg animate-fadeIn z-40">
          <div className="flex items-center gap-3">
            <div className="bg-emerald-500 rounded-full p-1.5 flex items-center justify-center shadow-xs">
              <CheckCircle className="w-5 h-5 text-white" />
            </div>
            <div className="text-xs sm:text-sm font-semibold space-y-0.5">
              <p className="font-extrabold">{parasiaNotification.msgEn}</p>
              <p className="font-medium opacity-95">{parasiaNotification.msgHi}</p>
            </div>
          </div>
          <button
            onClick={() => setParasiaNotification(null)}
            className="text-white hover:text-emerald-200 transition-colors p-1.5 rounded-lg hover:bg-emerald-500 cursor-pointer flex items-center justify-center ml-4"
            title="Dismiss / बंद करें"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 2. DYNAMIC WORKSPACE BODY: Left Dashboard & Analytics Control / Right Interactive Map Canvas */}
      {activeTab === "leaderboard" ? (
        <main className="flex-1 overflow-y-auto bg-slate-50 p-6 flex flex-col gap-6">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-950 p-6 rounded-2xl border border-slate-800 text-white shadow-xl relative overflow-hidden flex-shrink-0 animate-in fade-in duration-300">
            <div className="absolute right-0 top-0 w-1/3 h-full opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-400 via-indigo-900 to-transparent"></div>
            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black tracking-widest uppercase px-2.5 py-1 rounded-full flex items-center gap-1.5 w-fit">
                  <Trophy className="w-3 h-3 text-slate-950 fill-slate-950" />
                  {language === "en" ? "Live Leaderboard" : "लाइव लीडरबोर्ड"}
                </span>
                <h2 className="text-2xl font-black mt-2 tracking-tight">
                  {language === "en" ? "Citizen Champions" : "नागरिक चैंपियंस"}
                </h2>
                <p className="text-xs text-slate-300 mt-1 max-w-xl leading-relaxed">
                  {language === "en" 
                    ? "Our neighborhood grows stronger with every voice. Earn points by reporting verified issues, verifying others' reports, and driving official actions to resolution!"
                    : "हमारा पड़ोस हर आवाज के साथ मजबूत होता है। सत्यापित मुद्दों की रिपोर्ट करके, दूसरों की रिपोर्ट सत्यापित करके और आधिकारिक कार्रवाइयों को समाधान तक ले जाकर अंक अर्जित करें!"}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveTab("dashboard");
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-4 rounded-xl text-xs transition-all flex items-center gap-1.5 shadow-md shadow-indigo-950/40 cursor-pointer"
              >
                <Layers className="w-4 h-4" />
                {language === "en" ? "Back to Map Dashboard" : "नक्शा डैशबोर्ड पर वापस"}
              </button>
            </div>
          </div>

          {/* Podium / Stats Card Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Your Contributions profile highlight card */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-extrabold uppercase text-slate-400 tracking-wider flex items-center gap-1.5 border-b border-slate-100 pb-2 mb-3">
                  <User className="w-3.5 h-3.5 text-indigo-600" />
                  {language === "en" ? "Your Civic Contributions" : "आपका नागरिक योगदान"}
                </h3>
                <div className="space-y-3">
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 text-center relative group">
                    <button
                      onClick={() => {
                        setTempName(formReporter);
                        setIsEditingName(true);
                      }}
                      className="absolute right-3 top-3 p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-200/50 rounded-full transition-all cursor-pointer"
                      title={language === "en" ? "Edit name" : "नाम बदलें"}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <div className="w-12 h-12 bg-indigo-100 border border-indigo-200 text-indigo-700 font-extrabold text-lg flex items-center justify-center rounded-full mx-auto shadow-xs">
                      {formReporter.charAt(0)}
                    </div>
                    <h4 className="text-sm font-black text-slate-800 mt-2 flex items-center justify-center gap-1">
                      {formReporter}
                    </h4>
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">
                      {language === "en" ? "Ward Representative" : "वार्ड प्रतिनिधि"}
                    </span>
                    <div className="border-t border-slate-200/80 mt-3 pt-3 grid grid-cols-2 gap-2 text-left">
                      <div>
                        <span className="text-[9px] text-slate-400 block font-bold uppercase">{language === "en" ? "Total Points" : "कुल अंक"}</span>
                        <span className="text-lg font-black text-indigo-700">
                          {leaderboard.find(x => x.name === formReporter)?.points || 0}
                        </span>
                      </div>
                      <div>
                        <span className="text-[9px] text-slate-400 block font-bold uppercase">{language === "en" ? "Current Rank" : "वर्तमान रैंक"}</span>
                        <span className="text-lg font-black text-amber-600">
                          {(() => {
                            const idx = leaderboard.findIndex(x => x.name === formReporter);
                            return idx === -1 ? "-" : `#${idx + 1}`;
                          })()}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Level Badges Progression Card */}
                  <div className="p-4 bg-amber-50/50 rounded-xl border border-amber-100 text-xs shadow-2xs">
                    <span className="text-[10px] text-amber-800 uppercase font-black tracking-wider flex items-center gap-1">
                      <Award className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                      {language === "en" ? "Sentinel Badge Progression" : "प्रहरी बैज प्रगति"}
                    </span>
                    {(() => {
                      const pts = leaderboard.find(x => x.name === formReporter)?.points || 0;
                      let tier = language === "en" ? "Bronze Sentinel" : "कांस्य प्रहरी";
                      let nextTier = language === "en" ? "Silver Guardian" : "रजत संरक्षक";
                      let nextPoints = 50;
                      if (pts >= 150) {
                        tier = language === "en" ? "Gold Savior" : "स्वर्ण रक्षक";
                        nextTier = "Max Tier reached!";
                        nextPoints = pts;
                      } else if (pts >= 50) {
                        tier = language === "en" ? "Silver Guardian" : "रजत संरक्षक";
                        nextTier = language === "en" ? "Gold Savior" : "स्वर्ण रक्षक";
                        nextPoints = 150;
                      }
                      const percent = Math.min(100, Math.round((pts / nextPoints) * 100));

                      return (
                        <div className="space-y-2 mt-2">
                          <div className="flex justify-between font-bold text-[11px]">
                            <span className="text-slate-700">{tier}</span>
                            <span className="text-slate-450">{pts} / {nextPoints} Pts</span>
                          </div>
                          <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                            <div className="bg-amber-500 h-full transition-all duration-500" style={{ width: `${percent}%` }}></div>
                          </div>
                          {pts < 150 && (
                            <p className="text-[10px] text-slate-500 italic">
                              {language === "en" 
                                ? `Need ${nextPoints - pts} more points to reach ${nextTier}!`
                                : `${nextTier} तक पहुँचने के लिए ${nextPoints - pts} और अंकों की आवश्यकता है!`}
                            </p>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>

              {/* Point Rules cheat sheet */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                <h4 className="text-[10px] uppercase font-black text-slate-400 tracking-wider mb-2 flex items-center gap-1 border-b border-slate-200 pb-1.5">
                  <Sparkles className="w-3 h-3 text-indigo-600" />
                  {language === "en" ? "How to Earn Points" : "अंक कैसे अर्जित करें"}
                </h4>
                <div className="space-y-2 text-[11px] text-slate-600">
                  <div className="flex justify-between items-center bg-white p-2 rounded border border-slate-200/60 shadow-2xs">
                    <span>{language === "en" ? "Verified report submission" : "सत्यापित रिपोर्ट जमा करना"}</span>
                    <span className="font-extrabold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded text-[10px]">+10 Pts</span>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2 rounded border border-slate-200/60 shadow-2xs">
                    <span>{language === "en" ? "Verifying other reports" : "अन्य रिपोर्ट सत्यापित करना"}</span>
                    <span className="font-extrabold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded text-[10px]">+2 Pts</span>
                  </div>
                  <div className="flex justify-between items-center bg-white p-2 rounded border border-slate-200/60 shadow-2xs">
                    <span>{language === "en" ? "Report officially RESOLVED" : "रिपोर्ट आधिकारिक तौर पर हल"}</span>
                    <span className="font-extrabold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded text-[10px]">+50 Pts</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Middle + Right: Citizen Champions ranking table */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs lg:col-span-2 flex flex-col gap-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <h3 className="text-xs font-extrabold uppercase text-slate-450 tracking-wider flex items-center gap-1.5">
                    <Trophy className="w-3.5 h-3.5 text-indigo-600" />
                    {language === "en" ? "Citizen Champions Ranking" : "नागरिक चैंपियन रैंकिंग"}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    {language === "en" ? "Updates automatically as reports are submitted and verified" : "रिपोर्ट जमा करने और सत्यापित होने पर स्वचालित रूप से अपडेट होता है"}
                  </p>
                </div>
                {/* Search Bar input */}
                <div className="relative">
                  <input
                    type="text"
                    value={leaderboardSearch}
                    onChange={(e) => setLeaderboardSearch(e.target.value)}
                    placeholder={language === "en" ? "Search citizen..." : "नागरिक खोजें..."}
                    className="w-full sm:w-48 pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500"
                  />
                  <div className="absolute left-2.5 top-2.5 text-slate-400">
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                  </div>
                </div>
              </div>

              {leaderboardLoading ? (
                <div className="flex-1 flex flex-col items-center justify-center py-12">
                  <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                  <span className="text-xs text-slate-400 mt-2 font-bold">
                    {language === "en" ? "Calculating points..." : "अंकों की गणना की जा रही है..."}
                  </span>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[9px] tracking-wider bg-slate-50/50">
                        <th className="py-3 px-4">{language === "en" ? "Rank" : "रैंक"}</th>
                        <th className="py-3 px-4">{language === "en" ? "Citizen" : "नागरिक"}</th>
                        <th className="py-3 px-2 text-center">{language === "en" ? "Reports" : "रिपोर्ट"}</th>
                        <th className="py-3 px-2 text-center">{language === "en" ? "Votes Cast" : "वोट"}</th>
                        <th className="py-3 px-2 text-center">{language === "en" ? "Resolved" : "हल"}</th>
                        <th className="py-3 px-4 text-right">{language === "en" ? "Total Points" : "कुल अंक"}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {leaderboard
                        .filter(citizen => citizen.name.toLowerCase().includes(leaderboardSearch.toLowerCase()))
                        .map((citizen, idx) => {
                          const rank = idx + 1;
                          const isSelf = citizen.name === formReporter;
                          let medal = "";
                          if (rank === 1) medal = "🥇";
                          else if (rank === 2) medal = "🥈";
                          else if (rank === 3) medal = "🥉";

                          return (
                            <tr 
                              key={citizen.name} 
                              className={`transition-colors duration-150 ${
                                isSelf 
                                  ? "bg-indigo-50/70 hover:bg-indigo-50 font-semibold text-indigo-950" 
                                  : "hover:bg-slate-50/50 text-slate-700"
                              }`}
                            >
                              <td className="py-3.5 px-4 text-slate-800 font-bold">
                                {medal ? (
                                  <span className="text-base mr-1" title={`${rank} Place`}>{medal}</span>
                                ) : (
                                  <span className="text-slate-400 font-mono pl-1.5">{`#${rank}`}</span>
                                )}
                              </td>
                              <td className="py-3.5 px-4 flex items-center gap-2.5">
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs ${
                                  rank === 1 
                                    ? "bg-amber-100 text-amber-800 border border-amber-200" 
                                    : isSelf 
                                    ? "bg-indigo-600 text-white" 
                                    : "bg-slate-100 text-slate-600 border border-slate-200"
                                }`}>
                                  {citizen.name.charAt(0)}
                                </div>
                                <div>
                                  <span className="block text-slate-800 font-bold">{citizen.name}</span>
                                  {isSelf && (
                                    <span className="bg-indigo-100 text-indigo-800 text-[8px] font-black px-1.5 py-0.5 rounded uppercase mt-0.5 inline-block">
                                      {language === "en" ? "YOU" : "आप"}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="py-3.5 px-2 text-center font-semibold text-slate-600">
                                {citizen.reportsSubmitted || 0}
                              </td>
                              <td className="py-3.5 px-2 text-center font-semibold text-slate-600">
                                {citizen.votesCast || 0}
                              </td>
                              <td className="py-3.5 px-2 text-center font-semibold text-emerald-600">
                                {citizen.issuesResolved || 0}
                              </td>
                              <td className="py-3.5 px-4 text-right font-black text-sm text-indigo-950 font-mono">
                                {citizen.points || 0}
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </main>
      ) : (
        <main className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* SIDEBAR FOR STATS & REPORT LISTING */}
        <section className="w-full lg:w-[420px] bg-white border-r border-slate-200 flex flex-col flex-shrink-0 overflow-y-auto">
          
          {/* Banner notification space */}
          {successMsg && (
            <div className="bg-emerald-50 border-b border-emerald-100 px-5 py-3.5 text-emerald-800 text-xs font-semibold flex items-start gap-2 animate-fadeIn">
              <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="bg-rose-50 border-b border-rose-100 px-5 py-3.5 text-rose-800 text-xs font-semibold flex items-start gap-2 animate-fadeIn">
              <AlertOctagon className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Civic Health Analytics Overview */}
          <div className="p-5 border-b border-slate-100 bg-slate-50/50">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <BarChart3 className="w-3.5 h-3.5 text-indigo-600" />
                {t.statsTitle}
              </h2>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${isDemoMode ? "bg-rose-100 text-rose-800" : "bg-indigo-50 text-indigo-700"}`}>
                {isDemoMode
                  ? (language === "en" ? "Chhindwara District Overview" : "छिंदवाड़ा जिला समीक्षा")
                  : (language === "en" ? "Live Ward 4" : "लाइव वार्ड ४")}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs text-center">
                <span className="block text-[10px] font-bold text-slate-500 uppercase">
                  {t.totalReports}
                </span>
                <span className="text-2xl font-black text-slate-800 block mt-1">
                  {stats.total}
                </span>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs text-center border-l-4 border-l-rose-500">
                <span className="block text-[10px] font-bold text-slate-500 uppercase">
                  {t.activeIssues}
                </span>
                <span className="text-2xl font-black text-rose-600 block mt-1">
                  {stats.active}
                </span>
              </div>
              <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs text-center border-l-4 border-l-emerald-500">
                <span className="block text-[10px] font-bold text-slate-500 uppercase">
                  {t.resolvedIssues}
                </span>
                <span className="text-2xl font-black text-emerald-600 block mt-1">
                  {stats.resolved}
                </span>
              </div>
            </div>

            {/* Municipal Response Time Metric specific to Chhindwara */}
            {isDemoMode && (
              <div className="mt-4 p-3.5 bg-gradient-to-r from-rose-500/10 to-indigo-500/10 rounded-xl border border-rose-200/40 shadow-xs flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-extrabold uppercase text-slate-500 tracking-wider flex items-center gap-1">
                    <Activity className="w-3.5 h-3.5 text-rose-500" />
                    {language === "en" ? "Municipal Response Metrics" : "नगर निगम प्रतिक्रिया मापदंड"}
                  </span>
                  <span className="text-[8px] bg-rose-500 text-white font-black px-1.5 py-0.5 rounded uppercase">
                    {language === "en" ? "Live SLA" : "लाइव एसएलए"}
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-2 mt-1">
                  <div className="bg-white/80 p-2 rounded-lg border border-slate-100 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-rose-500 flex-shrink-0" />
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">
                        {language === "en" ? "Response Time" : "प्रतिक्रिया समय"}
                      </span>
                      <span className="text-sm font-black text-slate-800">
                        14.2 Hours
                      </span>
                    </div>
                  </div>

                  <div className="bg-white/80 p-2 rounded-lg border border-slate-100 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                    <div>
                      <span className="block text-[8px] font-bold text-slate-400 uppercase tracking-wider">
                        {language === "en" ? "SLA Compliance" : "SLA अनुपालन"}
                      </span>
                      <span className="text-sm font-black text-emerald-600">
                        94.8%
                      </span>
                    </div>
                  </div>
                </div>

                <div className="text-[9px] text-slate-500 leading-normal border-t border-slate-200/50 pt-1.5 mt-0.5 font-semibold">
                  {language === "en" 
                    ? "Target agencies: Chhindwara Municipal Corporation, Parasia Council & local Gram Panchayats." 
                    : "अधीनस्थ एजेंसियां: छिंदवाड़ा नगर पालिक निगम, परासिया परिषद एवं स्थानीय ग्राम पंचायतें।"}
                </div>
              </div>
            )}
          </div>

          {/* Filtering Console & Layout Options */}
          <div className="p-5 border-b border-slate-100 space-y-3.5 bg-white">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <ListFilter className="w-3.5 h-3.5 text-indigo-600" />
                {language === "en" ? "Filter Issues" : "समस्याएं फ़िल्टर करें"}
              </span>
              {(activeCategoryFilter !== "all" || activeSeverityFilter !== "all" || activeTehsilFilter !== "all") && (
                <button
                  onClick={() => {
                    setActiveCategoryFilter("all");
                    setActiveSeverityFilter("all");
                    setActiveTehsilFilter("all");
                  }}
                  className="text-[10px] font-bold text-indigo-600 hover:underline"
                >
                  {language === "en" ? "Reset filters" : "फ़िल्टर रीसेट करें"}
                </button>
              )}
            </div>

            <div className={`grid ${isDemoMode ? "grid-cols-1 sm:grid-cols-3" : "grid-cols-2"} gap-2`}>
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">
                  {t.filterCategory}
                </label>
                <select
                  value={activeCategoryFilter}
                  onChange={(e) => setActiveCategoryFilter(e.target.value)}
                  className="w-full text-xs h-9 bg-slate-50 border border-slate-200 rounded px-2 focus:outline-none focus:border-indigo-500 font-medium"
                >
                  <option value="all">⚡ {t.allCategories}</option>
                  {Object.entries(t.categories).map(([key, label]) => (
                    <option key={key} value={key}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">
                  {t.filterSeverity}
                </label>
                <select
                  value={activeSeverityFilter}
                  onChange={(e) => setActiveSeverityFilter(e.target.value)}
                  className="w-full text-xs h-9 bg-slate-50 border border-slate-200 rounded px-2 focus:outline-none focus:border-indigo-500 font-medium"
                >
                  <option value="all">★ {t.allSeverities}</option>
                  <option value="5">5 ★ (Critical)</option>
                  <option value="4">4 ★ (High)</option>
                  <option value="3">3 ★ (Moderate)</option>
                  <option value="2">2 ★ (Mild)</option>
                  <option value="1">1 ★ (Minimal)</option>
                </select>
              </div>

              {isDemoMode && (
                <div className="animate-fadeIn">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">
                    {language === "en" ? "Tehsil" : "तहसील"}
                  </label>
                  <select
                    value={activeTehsilFilter}
                    onChange={(e) => setActiveTehsilFilter(e.target.value)}
                    className="w-full text-xs h-9 bg-indigo-50/50 text-indigo-950 border border-indigo-200 rounded px-2 focus:outline-none focus:border-indigo-500 font-semibold"
                  >
                    <option value="all">📍 {language === "en" ? "All Tehsils" : "सभी तहसीलें"}</option>
                    {MP_TEHSILS.Chhindwara.map((teh) => (
                      <option key={teh.id} value={teh.id}>
                        {language === "en" ? teh.name_en : teh.name_hi}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>

          {/* RECENT ACTIVITY TICKER / INCIDENT LISTING */}
          <div className="flex-1 flex flex-col min-h-[300px]">
            <div className="px-5 py-4 bg-slate-50/70 border-b border-slate-100 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-indigo-600" />
                {t.recentActivity}
              </span>
              <span className="text-[10px] text-slate-400 font-bold">
                {displayedReports.length} {language === "en" ? "Reports" : "रिपोर्ट"}
              </span>
            </div>

            {loading && !isDemoMode ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <div className="w-8 h-8 rounded-full border-2 border-indigo-600 border-t-transparent animate-spin mb-3"></div>
                <p className="text-xs">{language === "en" ? "Loading registered reports..." : "पंजीकृत रिपोर्ट लोड की जा रही हैं..."}</p>
              </div>
            ) : displayedReports.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-400">
                <MapPinOff className="w-10 h-10 text-slate-300 mb-2" />
                <p className="text-xs font-semibold">{language === "en" ? "No Reports Logged Yet" : "अभी तक कोई रिपोर्ट दर्ज नहीं की गई है"}</p>
                <p className="text-[11px] mt-1 text-slate-400">{language === "en" ? "Be the first to click Report Issue!" : "रिपोर्ट समस्या पर क्लिक करने वाले पहले व्यक्ति बनें!"}</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {displayedReports
                  .filter(r => {
                    const matchCat = activeCategoryFilter === "all" || r.category === activeCategoryFilter;
                    const matchSev = activeSeverityFilter === "all" || r.severity.toString() === activeSeverityFilter;
                    const matchTehsil = activeTehsilFilter === "all" || r.tehsil === activeTehsilFilter;
                    return matchCat && matchSev && matchTehsil;
                  })
                  .map((report) => {
                    const isSelected = report.id === selectedReportId;
                    const cleanLoc = report.location.split("/")[language === "en" ? 0 : 1]?.trim() || report.location;
                    const cleanDesc = report.description.split("/")[language === "en" ? 0 : 1]?.trim() || report.description;

                    return (
                      <div
                        key={report.id}
                        onClick={() => handleReportClick(report)}
                        className={`p-4 transition-all duration-150 cursor-pointer flex gap-3 items-start text-left ${
                          isSelected
                            ? "bg-indigo-50/80 border-l-4 border-l-indigo-600"
                            : "hover:bg-slate-50 bg-white"
                        }`}
                      >
                        <img
                          src={report.media}
                          alt={report.category}
                          className="w-14 h-14 rounded-lg object-cover flex-shrink-0 border border-slate-200"
                          referrerPolicy="no-referrer"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1">
                            <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider truncate">
                              {t.categories[report.category as keyof typeof t.categories] || report.category}
                            </span>
                            <span className="text-[10px] text-slate-400 font-semibold flex-shrink-0">
                              {new Date(report.createdAt).toLocaleDateString(language === "en" ? "en-US" : "hi-IN", {
                                month: "short",
                                day: "numeric"
                              })}
                            </span>
                          </div>

                          <h4 className="text-xs font-bold text-slate-800 truncate mt-0.5">
                            {cleanLoc}
                          </h4>

                          <p className="text-[11px] text-slate-500 truncate mt-0.5">
                            {cleanDesc || "No additional description"}
                          </p>

                          <div className="flex items-center justify-between mt-2 pt-1 border-t border-slate-100">
                            <div className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-slate-400 block"></span>
                              <span className="text-[10px] text-slate-400 font-medium truncate max-w-[110px]">
                                {report.reporter}
                              </span>
                            </div>

                            <div className="flex items-center gap-2">
                              {/* Verification Upvote Button */}
                              <button
                                type="button"
                                disabled={report.verificationVotes?.includes(formReporter) || report.status === "resolved"}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleVerifyReport(report.id);
                                }}
                                className={`flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded border transition-all ${
                                  report.verificationVotes?.includes(formReporter)
                                    ? "bg-emerald-50 text-emerald-700 border-emerald-100"
                                    : "bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border-indigo-100 active:scale-95"
                                }`}
                                title={language === "en" ? "Verify / Upvote" : "सत्यापित करें / अपवोट"}
                              >
                                <Sparkles className="w-2.5 h-2.5 text-amber-500" />
                                <span>{report.verificationVotes?.length || 0}</span>
                              </button>

                              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                                report.severity >= 4
                                  ? "bg-rose-50 text-rose-700 border border-rose-100"
                                  : report.severity >= 3
                                  ? "bg-amber-50 text-amber-700 border border-amber-100"
                                  : "bg-slate-100 text-slate-600"
                              }`}>
                                {report.severity} ★
                              </span>
                              
                              <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                                report.status === "resolved"
                                  ? "bg-emerald-100 text-emerald-800"
                                  : report.status === "in_progress"
                                  ? "bg-amber-100 text-amber-800"
                                  : report.status === "awaiting_verification"
                                  ? "bg-indigo-100 text-indigo-800 border border-indigo-200"
                                  : "bg-rose-100 text-rose-800"
                              }`}>
                                {report.status === "resolved" 
                                  ? t.statusResolved 
                                  : report.status === "in_progress" 
                                  ? t.statusInProgress 
                                  : report.status === "awaiting_verification"
                                  ? (language === "en" ? "Awaiting Verification" : "सत्यापन की प्रतीक्षा")
                                  : t.statusPending}
                              </span>
                            </div>
                          </div>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-300 mt-4 flex-shrink-0" />
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </section>

        {/* 3. INTERACTIVE MAP SECTION WITH OVERLAY FOR REPORT FORM */}
        <section className="flex-1 h-full relative bg-slate-200">
          
          {/* Main Map Component */}
          <div className="w-full h-full">
            <LiveMapDashboard
              reports={displayedReports}
              selectedLanguage={language}
              t={t}
              onReportClick={handleReportClick}
              onOpenReportForm={handleOpenForm}
              selectedReportId={selectedReportId}
              onSelectReportId={setSelectedReportId}
              activeCategoryFilter={activeCategoryFilter}
              activeSeverityFilter={activeSeverityFilter}
              currentUser={formReporter}
              onVerifyReport={handleVerifyReport}
              isDemoMode={isDemoMode}
              activeTehsilFilter={activeTehsilFilter}
              setFormLat={setFormLat}
              setFormLng={setFormLng}
              setFormSpecificAddress={setFormSpecificAddress}
            />
          </div>

          {/* 4. SIDEBAR REPORTING FORM (Triggers when FAB or map clicked) */}
          {isFormOpen && (
            <div className="absolute top-6 left-6 w-full max-w-[360px] max-h-[90%] bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden z-30 animate-in slide-in-from-left duration-300">
              {/* Form Title banner */}
              <div className="p-4 bg-indigo-50 border-b border-indigo-100 flex items-center justify-between flex-shrink-0">
                <div>
                  <h2 className="text-sm font-bold text-indigo-950 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-600" />
                    {t.formTitle}
                  </h2>
                  <p className="text-[10px] text-indigo-700 font-semibold opacity-90 mt-0.5 truncate max-w-[270px]">
                    {t.formSubtitle}
                  </p>
                </div>
                <button
                  onClick={() => setIsFormOpen(false)}
                  className="w-7 h-7 rounded-full bg-indigo-100/60 hover:bg-indigo-100 text-indigo-900 flex items-center justify-center transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Scrollable form controls */}
              <form onSubmit={handleSubmitReport} className="p-5 overflow-y-auto flex-1 space-y-4">
                
                {/* Image/Video Upload Section */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                    {t.fieldMedia} <span className="text-rose-500">*</span>
                  </label>
                  
                  {formMedia ? (
                    <div className="relative w-full h-24 rounded-lg overflow-hidden border border-indigo-200">
                      <img src={formMedia} alt="Submitting preview" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setFormMedia("")}
                        className="absolute top-1.5 right-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"
                      >
                        ×
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="relative w-full h-20 border-2 border-dashed border-slate-200 hover:border-indigo-400 rounded-lg flex flex-col items-center justify-center bg-slate-50 hover:bg-indigo-50/40 transition-colors cursor-pointer p-2">
                        <input
                          type="file"
                          accept="image/*,video/*"
                          onChange={handleFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                        <Upload className="w-5 h-5 text-slate-400" />
                        <span className="text-[10px] text-slate-400 mt-1 text-center font-medium">
                          {t.fieldMediaHint}
                        </span>
                      </div>

                      {/* Presets Grid */}
                      <div>
                        <span className="block text-[9px] font-bold text-slate-400 uppercase mb-1">
                          {language === "en" ? "Or pick a sample photo instantly:" : "या तुरंत एक नमूना फोटो चुनें:"}
                        </span>
                        <div className="grid grid-cols-4 gap-1.5">
                          {PRESET_CIVIC_IMAGES.map((img, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => setFormMedia(img.url)}
                              title={language === "en" ? img.label_en : img.label_hi}
                              className="h-10 rounded overflow-hidden border border-slate-200 hover:border-indigo-500 active:scale-95 transition-all relative group"
                            >
                              <img src={img.url} alt={img.name} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-indigo-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center">
                                <FileImage className="w-3 h-3 text-white" />
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* AI Triage Details Section */}
                {(isTriaging || triageResults) && (
                  <div className="bg-indigo-950 text-slate-100 rounded-lg p-3.5 border border-indigo-700/60 shadow-inner space-y-2.5">
                    <div className="flex items-center justify-between border-b border-indigo-800/80 pb-2">
                      <span className="text-[11px] font-extrabold uppercase tracking-widest text-indigo-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                        {language === "en" ? "AI Triage & Agent Workflow" : "एआई ट्राइएज और एजेंट वर्कफ़्लो"}
                      </span>
                      {isTriaging && (
                        <span className="w-2.5 h-2.5 rounded-full border-2 border-amber-400 border-t-transparent animate-spin"></span>
                      )}
                    </div>

                    {isTriaging && (
                      <div className="py-2 text-center text-xs text-slate-300 animate-pulse font-medium">
                        {language === "en" ? "Gemini is inspecting visual cues & orchestrating workflow agents..." : "जेमिनी दृश्य संकेतों का निरीक्षण कर रहा है और वर्कफ़्लो एजेंटों को व्यवस्थित कर रहा है..."}
                      </div>
                    )}

                    {triageResults && (
                      <div className="space-y-3.5 text-xs">
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <span className="text-[9px] font-semibold text-indigo-300 uppercase block leading-none">
                              {language === "en" ? "Primary Issue Type" : "प्राथमिक समस्या प्रकार"}
                            </span>
                            <span className="font-extrabold text-white text-xs mt-1 block">
                              {triageResults.primary_issue_type}
                            </span>
                          </div>
                          <div>
                            <span className="text-[9px] font-semibold text-indigo-300 uppercase block leading-none">
                              {language === "en" ? "Assigned Recipient" : "निर्धारित प्राप्तकर्ता"}
                            </span>
                            <span className="font-extrabold text-white text-xs mt-1 block truncate" title={triageResults.recipientAgency}>
                              {triageResults.recipientAgency || "Resolving jurisdiction..."}
                            </span>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <span className="text-[9px] font-semibold text-indigo-300 uppercase block leading-none">
                              {language === "en" ? "AI Severity Score" : "एआई गंभीरता स्कोर"}
                            </span>
                            <span className="font-extrabold text-amber-400 text-xs mt-1 block flex items-center gap-1">
                              {triageResults.severity_score} / 5
                              <span className="text-[9px] text-indigo-300 font-normal">
                                ({language === "en" ? "Auto-applied" : "स्वचालित लागू"})
                              </span>
                            </span>
                          </div>
                          <div>
                            <span className="text-[9px] font-semibold text-indigo-300 uppercase block leading-none">
                              {language === "en" ? "Required Materials" : "आवश्यक सामग्रियां"}
                            </span>
                            <span className="font-bold text-slate-200 text-[11px] mt-1 block truncate" title={triageResults.required_materials}>
                              {triageResults.required_materials}
                            </span>
                          </div>
                        </div>

                        <div className="bg-indigo-900/40 p-2.5 rounded border border-indigo-800/80 text-[11px] text-slate-300 leading-relaxed">
                          <span className="font-extrabold text-[9px] text-indigo-300 uppercase block mb-0.5">
                            {language === "en" ? "Technical Summary" : "तकनीकी सारांश"}
                          </span>
                          {triageResults.technical_summary}
                        </div>

                        {/* Agent Workflow Execution Logs (Real-time logs showing Agentic Depth) */}
                        {triageResults.agentWorkflowLogs && triageResults.agentWorkflowLogs.length > 0 && (
                          <div className="space-y-1">
                            <span className="text-[9px] font-semibold text-indigo-300 uppercase block leading-none">
                              {language === "en" ? "Autonomous Agent Workflow Logs" : "स्वायत्त एजेंट वर्कफ़्लो लॉग"}
                            </span>
                            <div className="bg-indigo-950 p-2 rounded border border-indigo-900 max-h-24 overflow-y-auto font-mono text-[9px] text-emerald-400 space-y-1 shadow-inner scrollbar-thin">
                              {triageResults.agentWorkflowLogs.map((log, idx) => (
                                <div key={idx} className="leading-tight">
                                  <span className="text-indigo-400 font-semibold">{`>`}</span> {log}
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Bilingual Drafted Complaint Letter Previews */}
                        {triageResults.complaintLetters && (
                          <div className="space-y-1.5 border-t border-indigo-800/60 pt-2.5">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] font-semibold text-indigo-300 uppercase block">
                                {language === "en" ? "Drafted Complaint Letters" : "तैयार किए गए शिकायत पत्र"}
                              </span>
                              <div className="flex items-center gap-1.5 bg-indigo-900/50 p-0.5 rounded border border-indigo-800">
                                <button
                                  type="button"
                                  onClick={() => setLetterLangTab("en")}
                                  className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase transition-all ${
                                    letterLangTab === "en"
                                      ? "bg-indigo-600 text-white shadow-sm"
                                      : "text-indigo-300 hover:text-white"
                                  }`}
                                >
                                  English
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setLetterLangTab("hi")}
                                  className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase transition-all ${
                                    letterLangTab === "hi"
                                      ? "bg-indigo-600 text-white shadow-sm"
                                      : "text-indigo-300 hover:text-white"
                                  }`}
                                >
                                  हिन्दी
                                </button>
                              </div>
                            </div>
                            <div className="bg-indigo-950/80 p-2.5 rounded border border-indigo-900/80 font-mono text-[10px] text-slate-200 leading-relaxed whitespace-pre-wrap max-h-36 overflow-y-auto scrollbar-thin shadow-inner select-all">
                              {letterLangTab === "en"
                                ? triageResults.complaintLetters.english
                                : triageResults.complaintLetters.hindi}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Problem Category Select */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                    {t.fieldCategory} <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full h-10 px-3 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  >
                    {Object.entries(t.categories).map(([key, label]) => (
                      <option key={key} value={key}>
                        {label}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Severity Slider Level */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                      {t.fieldSeverity}
                    </label>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      formSeverity >= 4 
                        ? "bg-rose-50 text-rose-700" 
                        : formSeverity >= 3 
                        ? "bg-amber-50 text-amber-700" 
                        : "bg-emerald-50 text-emerald-700"
                    }`}>
                      Lvl {formSeverity}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={formSeverity}
                    onChange={(e) => setFormSeverity(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
                  />
                  <p className="text-[10px] text-indigo-700 font-semibold mt-1">
                    {formSeverity === 1 && t.severity1}
                    {formSeverity === 2 && t.severity2}
                    {formSeverity === 3 && t.severity3}
                    {formSeverity === 4 && t.severity4}
                    {formSeverity === 5 && t.severity5}
                  </p>
                </div>

                {/* Cascading Location Dropdowns */}
                <div className="space-y-3">
                  {/* District Dropdown */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                      {language === "en" ? "District" : "ज़िला"} <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <select
                        value={formDistrict}
                        onChange={(e) => {
                          setFormDistrict(e.target.value);
                          setFormTehsil(""); // Reset Tehsil cascading state when District changes
                        }}
                        className="w-full h-10 pl-9 pr-3 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                      >
                        <option value="">-- {language === "en" ? "Select District" : "ज़िला चुनें"} --</option>
                        {MP_DISTRICTS.map((d) => (
                          <option key={d.id} value={d.id}>
                            {language === "en" ? d.name_en : d.name_hi}
                          </option>
                        ))}
                      </select>
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-indigo-500" />
                    </div>
                  </div>

                  {/* Tehsil Dropdown */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                      {language === "en" ? "Tehsil" : "तहसील"} <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <select
                        value={formTehsil}
                        onChange={(e) => setFormTehsil(e.target.value)}
                        disabled={!formDistrict}
                        className="w-full h-10 pl-9 pr-3 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 disabled:bg-slate-100 disabled:text-slate-400 disabled:cursor-not-allowed"
                      >
                        <option value="">-- {language === "en" ? "Select Tehsil" : "तहसील चुनें"} --</option>
                        {formDistrict &&
                          MP_TEHSILS[formDistrict]?.map((t) => (
                            <option key={t.id} value={t.id}>
                              {language === "en" ? t.name_en : t.name_hi}
                            </option>
                          ))}
                      </select>
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-indigo-400" />
                    </div>
                  </div>

                  {/* Specific Locality / Landmark Address */}
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                      {language === "en" ? "Specific Area / Landmark / Ward" : "विशिष्ट क्षेत्र / लैंडमार्क / वार्ड"}
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={formSpecificAddress}
                        onChange={(e) => setFormSpecificAddress(e.target.value)}
                        placeholder={t.fieldLocationPlaceholder}
                        className="w-full h-10 pl-9 pr-3 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                      />
                      <MapPin className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
                    </div>
                  </div>

                  {/* Pin coordinates helper display */}
                  <div className="flex items-center justify-between mt-1 px-1 text-[9px] text-slate-400 font-semibold">
                    <span>
                      {t.coordinates}: Lat {formLat}, Lng {formLng}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        if (navigator.geolocation) {
                          navigator.geolocation.getCurrentPosition(
                            (position) => {
                              const { latitude, longitude } = position.coords;
                              setFormLat(latitude);
                              setFormLng(longitude);
                              
                              const fallbackAddress = `Chhindwara Area (Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)})`;
                              setFormSpecificAddress(fallbackAddress);

                              // Reverse geocode the location
                              if (typeof window !== "undefined" && window.google && window.google.maps) {
                                try {
                                  const geocoder = new window.google.maps.Geocoder();
                                  geocoder.geocode({ location: { lat: latitude, lng: longitude } }, (results, status) => {
                                    if (status === "OK" && results && results[0]) {
                                      setFormSpecificAddress(results[0].formatted_address);
                                    } else {
                                      console.warn("Geocoder did not return OK status:", status);
                                    }
                                  });
                                } catch (err) {
                                  console.warn("Geocoder error:", err);
                                }
                              }
                            },
                            (error) => {
                              console.warn("Geolocation error in form:", error);
                              // Fallback coordinates (Chhindwara center) + small random offset for interactivity
                              const fallbackLat = 22.0574 + (Math.random() - 0.5) * 0.05;
                              const fallbackLng = 78.9382 + (Math.random() - 0.5) * 0.05;
                              setFormLat(fallbackLat);
                              setFormLng(fallbackLng);
                              setFormSpecificAddress(`Chhindwara Area (Lat: ${fallbackLat.toFixed(4)}, Lng: ${fallbackLng.toFixed(4)})`);
                              alert(language === "en" ? "Unable to retrieve your location automatically. Set to Chhindwara." : "स्वचालित रूप से आपका स्थान खोजने में असमर्थ। छिंदवाड़ा पर सेट किया गया।");
                            },
                            { enableHighAccuracy: false, timeout: 5000, maximumAge: 60000 }
                          );
                        } else {
                          // Geolocation not supported fallback
                          const fallbackLat = 22.0574 + (Math.random() - 0.5) * 0.05;
                          const fallbackLng = 78.9382 + (Math.random() - 0.5) * 0.05;
                          setFormLat(fallbackLat);
                          setFormLng(fallbackLng);
                          setFormSpecificAddress(`Chhindwara Area (Lat: ${fallbackLat.toFixed(4)}, Lng: ${fallbackLng.toFixed(4)})`);
                          alert("Geolocation is not supported by your browser. Set to Chhindwara.");
                        }
                      }}
                      className="text-indigo-600 hover:underline"
                    >
                      {t.useCurrentLocation}
                    </button>
                  </div>
                </div>

                {/* Description & Impact Text Area */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                    {t.fieldDescription}
                  </label>
                  <textarea
                    rows={2}
                    value={formDescription}
                    onChange={(e) => setFormDescription(e.target.value)}
                    placeholder={t.fieldDescriptionPlaceholder}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                {/* Citizen Name Field */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">
                    {language === "en" ? "Your Name (Reporter)" : "आपका नाम (रिपोर्टर)"}
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={formReporter}
                      onChange={(e) => setFormReporter(e.target.value)}
                      placeholder="e.g. Aditya Kumar"
                      className="w-full h-9 pl-9 pr-3 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                    />
                    <UserCheck className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                  </div>
                </div>

                {/* Action Submit Buttons */}
                <div className="flex gap-2 pt-1 flex-shrink-0">
                  <button
                    type="button"
                    onClick={() => setIsFormOpen(false)}
                    className="flex-1 h-10 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-xs transition-all"
                  >
                    {t.btnCancel}
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-[2] h-10 bg-indigo-600 text-white font-bold rounded-lg shadow-lg shadow-indigo-200 hover:bg-indigo-700 flex items-center justify-center gap-1 text-xs transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? t.submitting : t.btnSubmit}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* 5. SIDEBAR INSPECT PANEL (When a report is being examined closely) */}
          {selectedReport && (
            <div className="absolute top-6 right-6 w-full max-w-[350px] max-h-[90%] bg-white rounded-xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden z-30 animate-in slide-in-from-right duration-300">
              <div className="relative h-44 bg-slate-900 flex-shrink-0">
                <img
                  src={selectedReport.media}
                  alt={selectedReport.category}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <button
                  onClick={() => setSelectedReportId(null)}
                  className="absolute top-3 right-3 w-7 h-7 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white text-sm font-bold shadow"
                >
                  ×
                </button>
                <div className="absolute top-3 left-3 px-2 py-0.5 rounded-full bg-slate-950/70 backdrop-blur-sm text-[10px] font-bold text-slate-200">
                  ID: {selectedReport.id}
                </div>
              </div>

              {/* Scrollable details and actions */}
              <div className="p-5 overflow-y-auto flex-1 space-y-4">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">
                    {t.categories[selectedReport.category as keyof typeof t.categories] || selectedReport.category}
                  </span>
                  <h3 className="font-extrabold text-slate-900 text-base leading-tight mt-0.5">
                    {selectedReport.location.split("/")[language === "en" ? 0 : 1]?.trim() || selectedReport.location}
                  </h3>
                </div>

                <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs text-slate-700 leading-relaxed">
                  <div className="font-bold text-slate-500 mb-1 text-[10px] uppercase">
                    {language === "en" ? "Issue Description" : "समस्या का विवरण"}
                  </div>
                  {selectedReport.description.split("/")[language === "en" ? 0 : 1]?.trim() || selectedReport.description || "No description provided / कोई विवरण नहीं दिया गया"}
                </div>

                <div className="border-t border-slate-100 pt-3 flex flex-col gap-2 text-xs text-slate-600">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-400">{t.reporter}:</span>
                    <span className="font-bold text-slate-800">{selectedReport.reporter}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-400">{t.reportedOn}:</span>
                    <span className="font-semibold text-slate-700">
                      {new Date(selectedReport.createdAt).toLocaleDateString(language === "en" ? "en-US" : "hi-IN", {
                        weekday: "short",
                        month: "long",
                        day: "numeric",
                        year: "numeric"
                      })}
                    </span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-400">{t.coordinates}:</span>
                    <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-600">
                      Lat {selectedReport.lat}, Lng {selectedReport.lng}
                    </span>
                  </div>

                  {/* Severity Stars visualization */}
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-slate-400">{t.fieldSeverity}:</span>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <span
                          key={star}
                          className={`text-sm ${
                            star <= selectedReport.severity
                              ? "text-amber-500 font-bold"
                              : "text-slate-200"
                          }`}
                        >
                          ★
                        </span>
                      ))}
                      <span className="text-[10px] text-slate-400 font-semibold ml-1">
                        ({selectedReport.severity}/5)
                      </span>
                    </div>
                  </div>

                  {/* Status Indicator Bar */}
                  <div className="flex justify-between items-center border-t border-slate-100 pt-3 mt-1">
                    <span className="font-semibold text-slate-700">
                      {language === "en" ? "Current Status:" : "वर्तमान स्थिति:"}
                    </span>
                    <span className={`text-xs font-bold px-2 py-1 rounded-full ${
                      selectedReport.status === "resolved"
                        ? "bg-emerald-100 text-emerald-800 border border-emerald-200"
                        : selectedReport.status === "in_progress"
                        ? "bg-amber-100 text-amber-800 border border-amber-200 animate-pulse"
                        : selectedReport.status === "awaiting_verification"
                        ? "bg-indigo-100 text-indigo-800 border border-indigo-200"
                        : "bg-rose-100 text-rose-800 border border-rose-200"
                    }`}>
                      {selectedReport.status === "resolved" 
                        ? t.statusResolved 
                        : selectedReport.status === "in_progress" 
                        ? t.statusInProgress 
                        : selectedReport.status === "awaiting_verification"
                        ? (language === "en" ? "Awaiting Verification" : "सत्यापन की प्रतीक्षा")
                        : t.statusPending}
                    </span>
                  </div>
                </div>

                {/* Verified AI Triage Details (if present) */}
                {selectedReport.aiTriage && (
                  <div className="bg-indigo-950 text-slate-100 rounded-lg p-3.5 border border-indigo-700/50 space-y-2.5 shadow-inner">
                    <div className="flex items-center gap-1.5 border-b border-indigo-800/85 pb-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-300">
                        {language === "en" ? "Verified AI Triage & Agents" : "सत्यापित एआई ट्राइएज और एजेंट्स"}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs leading-tight text-slate-300">
                      <div>
                        <span className="text-[9px] text-indigo-400 block uppercase font-bold">{language === "en" ? "AI Classification" : "एआई वर्गीकरण"}</span>
                        <span className="font-extrabold text-white block mt-0.5">{selectedReport.aiTriage.primary_issue_type}</span>
                      </div>
                      <div>
                        <span className="text-[9px] text-indigo-400 block uppercase font-bold">{language === "en" ? "Assessed Severity" : "निर्धारित गंभीरता"}</span>
                        <span className="font-extrabold text-amber-400 block mt-0.5">{selectedReport.aiTriage.severity_score} / 5</span>
                      </div>
                    </div>
                    <div className="text-xs text-slate-300">
                      <span className="text-[9px] text-indigo-400 block uppercase font-bold">{language === "en" ? "Required Materials" : "आवश्यक सामग्रियां"}</span>
                      <span className="font-bold text-slate-100 block mt-0.5">{selectedReport.aiTriage.required_materials}</span>
                    </div>
                    <div className="bg-indigo-900/60 p-2.5 rounded border border-indigo-850 text-xs text-slate-300 leading-relaxed">
                      <span className="text-[9px] text-indigo-400 block uppercase font-extrabold mb-0.5">{language === "en" ? "Technical Summary" : "तकनीकी सारांश"}</span>
                      {selectedReport.aiTriage.technical_summary}
                    </div>

                    {/* Report Agent Workflow logs */}
                    {selectedReport.agentWorkflowLogs && selectedReport.agentWorkflowLogs.length > 0 && (
                      <div className="space-y-1 pt-1.5 border-t border-indigo-800/50">
                        <span className="text-[9px] text-indigo-400 block uppercase font-bold">
                          {language === "en" ? "Agent Execution Logs" : "एजेंट निष्पादन लॉग"}
                        </span>
                        <div className="bg-indigo-950 p-2 rounded border border-indigo-900 max-h-24 overflow-y-auto font-mono text-[9px] text-emerald-400 space-y-1 scrollbar-thin leading-tight">
                          {selectedReport.agentWorkflowLogs.map((log, idx) => (
                            <div key={idx}>
                              <span className="text-indigo-400 font-semibold">{`>`}</span> {log}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Report Draft Complaint Letters */}
                    {selectedReport.complaintLetters && (
                      <div className="space-y-1.5 pt-1.5 border-t border-indigo-800/50">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] text-indigo-400 block uppercase font-bold">
                            {language === "en" ? "Official Complaint Drafts" : "आधिकारिक शिकायत ड्राफ्ट"}
                          </span>
                          <div className="flex items-center gap-1 bg-indigo-900/50 p-0.5 rounded border border-indigo-800">
                            <button
                              type="button"
                              onClick={() => setLetterLangTab("en")}
                              className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase transition-all ${
                                letterLangTab === "en"
                                  ? "bg-indigo-600 text-white shadow-sm"
                                  : "text-indigo-300 hover:text-white"
                              }`}
                            >
                              EN
                            </button>
                            <button
                              type="button"
                              onClick={() => setLetterLangTab("hi")}
                              className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase transition-all ${
                                letterLangTab === "hi"
                                  ? "bg-indigo-600 text-white shadow-sm"
                                  : "text-indigo-300 hover:text-white"
                              }`}
                            >
                              HI
                            </button>
                          </div>
                        </div>
                        <div className="bg-indigo-950/80 p-2 rounded border border-indigo-900/80 font-mono text-[9px] text-slate-200 leading-relaxed whitespace-pre-wrap max-h-28 overflow-y-auto scrollbar-thin select-all">
                          {letterLangTab === "en"
                            ? selectedReport.complaintLetters.english
                            : selectedReport.complaintLetters.hindi}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* 6. ADMINISTRATIVE CONTROLS / UPDATE STATUS AT THE BOTTOM */}
                <div className="border-t border-slate-200 pt-4 space-y-2">
                  <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    {language === "en" ? "Administrative Actions" : "प्रशासनिक कार्रवाई"}
                  </span>
                  <div className="grid grid-cols-2 gap-1.5 mb-1.5">
                    <button
                      onClick={() => handleUpdateStatus(selectedReport.id, "awaiting_verification")}
                      disabled={selectedReport.status === "awaiting_verification"}
                      className="bg-indigo-50 hover:bg-indigo-100 disabled:opacity-45 text-[10px] text-indigo-700 font-bold py-1.5 rounded transition-all"
                    >
                      {language === "en" ? "Set Verifying" : "सत्यापन पर सेट करें"}
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(selectedReport.id, "pending")}
                      disabled={selectedReport.status === "pending"}
                      className="bg-slate-100 hover:bg-slate-200 disabled:opacity-45 text-[10px] text-slate-700 font-bold py-1.5 rounded transition-all"
                    >
                      {language === "en" ? "Reset Pending" : "लंबित करें"}
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5">
                    <button
                      onClick={() => handleUpdateStatus(selectedReport.id, "in_progress")}
                      disabled={selectedReport.status === "in_progress"}
                      className="bg-amber-500 hover:bg-amber-400 text-slate-950 disabled:opacity-45 text-[10px] font-black py-1.5 rounded transition-all"
                    >
                      {language === "en" ? "Work Active" : "सक्रिय कार्य"}
                    </button>
                    <button
                      onClick={() => handleUpdateStatus(selectedReport.id, "resolved")}
                      disabled={selectedReport.status === "resolved"}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-45 text-[10px] font-bold py-1.5 rounded transition-all"
                    >
                      {language === "en" ? "Set Resolved" : "समाधान करें"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </main>
    )}

      {/* 5. BOTTOM STATUS BAR (Professional Polish design) */}
      <footer className="h-8 bg-slate-950 flex-shrink-0 px-6 flex items-center justify-between text-[10px] font-semibold text-slate-400 border-t border-slate-800 z-50">
        <div className="flex gap-4">
          <span>{language === "en" ? "Local Authorities: Online" : "स्थानीय अधिकारी: ऑनलाइन"}</span>
          <span className="hidden sm:inline text-slate-500">|</span>
          <span>{language === "en" ? "Connected to Varanasi Municipal Corp (VMC)" : "वाराणसी नगर निगम (VMC) से जुड़े हैं"}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
          <span>{language === "en" ? "Live Updates Active" : "लाइव अपडेट सक्रिय"}</span>
        </div>
      </footer>
    </div>
  );
}
