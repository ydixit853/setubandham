export type Language = "en" | "hi";

export interface AITriageDetails {
  primary_issue_type: string;
  severity_score: number;
  technical_summary: string;
  required_materials: string;
}

export interface Report {
  id: string;
  category: string;
  severity: number;
  location: string;
  description: string;
  lat: number;
  lng: number;
  media: string;
  status: "awaiting_verification" | "pending" | "in_progress" | "resolved";
  createdAt: string;
  reporter: string;
  aiTriage?: AITriageDetails;
  agentWorkflowLogs?: string[];
  complaintLetters?: {
    english: string;
    hindi: string;
    recipientAgency: string;
  };
  verificationVotes?: string[];
  district?: string;
  tehsil?: string;
  estimatedResources?: string;
  draftCitizenUpdate?: string;
  proofOfFix?: string;
}

export interface Translations {
  appName: string;
  appTagline: string;
  reportIssueButton: string;
  langToggleLabel: string;
  searchPlaceholder: string;
  filterCategory: string;
  filterSeverity: string;
  allCategories: string;
  allSeverities: string;
  totalReports: string;
  activeIssues: string;
  resolvedIssues: string;
  recentActivity: string;
  statsTitle: string;
  formTitle: string;
  formSubtitle: string;
  fieldCategory: string;
  fieldSeverity: string;
  fieldLocation: string;
  fieldLocationPlaceholder: string;
  fieldDescription: string;
  fieldDescriptionPlaceholder: string;
  fieldMedia: string;
  fieldMediaHint: string;
  btnCancel: string;
  btnSubmit: string;
  submitting: string;
  successMessage: string;
  errorMessage: string;
  severity1: string;
  severity2: string;
  severity3: string;
  severity4: string;
  severity5: string;
  statusPending: string;
  statusInProgress: string;
  statusResolved: string;
  categories: {
    pothole: string;
    streetlight: string;
    garbage: string;
    water_leak: string;
    drainage: string;
    pavement: string;
    other: string;
  };
  viewOnMap: string;
  coordinates: string;
  reporter: string;
  reportedOn: string;
  pinnedLocation: string;
  useCurrentLocation: string;
  clickToPin: string;
  mockWard1: string;
  mockWard2: string;
  mockWard3: string;
  mockWard4: string;
}
